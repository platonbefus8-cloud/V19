import logging
import socket
import time
import os
import json
import sys
import traceback
import sqlite3
from threading import Thread, Lock
from collections import defaultdict, deque, OrderedDict
from colorama import init, Fore, Back, Style
from Logic.Device import Device
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Utils.Config import Config
from Database.DatabaseManager import DataBase

init(autoreset=True)

logging.basicConfig(filename="errors.log", level=logging.INFO, filemode="w")

def _(message, color=Fore.WHITE):
    print(color + '[INFO]', message)

def print_banner(clear_screen=True):
    if clear_screen:
        os.system('cls' if os.name == 'nt' else 'clear')
    print(Fore.YELLOW + "            Angel Private Server" + Style.RESET_ALL)
    print(Fore.GREEN + "          Version: 18.104 | Brawl Stars" + Style.RESET_ALL)
    print("\n")

def update_config_online(count):
    try:
        with open('config.json', 'r+', encoding='utf-8') as f:
            config = json.load(f)
            config['Online'] = count
            f.seek(0)
            json.dump(config, f, indent=4, ensure_ascii=False)
            f.truncate()
    except Exception as e:
        _(f"Ошибка при обновлении config.json: {e}", Fore.RED)

def reset_all_online_status():
    try:
        _(f"Сброс онлайн статуса всех игроков...", Fore.YELLOW)
        
        DataBase.createDatabaseFolders()
        
        conn = sqlite3.connect('Database/Player/data.db')
        cursor = conn.cursor()
        
        cursor.execute("SELECT token, info FROM players")
        updated_count = 0
        
        for row in cursor.fetchall():
            token, info_json = row
            try:
                user_data = json.loads(info_json, object_pairs_hook=OrderedDict)
                if 'online' in user_data and user_data['online'] == 1:
                    user_data['online'] = 0
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(user_data), token))
                    updated_count += 1
            except:
                continue
        
        conn.commit()
        conn.close()
        
        _(f"Сброшен онлайн статус у {updated_count} игроков", Fore.GREEN)
        
    except Exception as e:
        _(f"Ошибка при сбросе онлайн статуса: {e}", Fore.RED)
        import traceback
        traceback.print_exc()

def run_script_directly(script_name, function_name=None, capture_output=True):
    try:
        if not os.path.exists(script_name):
            _(f"Файл {script_name} не найден", Fore.RED)
            return False
            
        current_dir = os.path.dirname(os.path.abspath(__file__))
        if current_dir not in sys.path:
            sys.path.insert(0, current_dir)
        
        original_stdout = sys.stdout
        original_stderr = sys.stderr
        captured_output = ""
        
        try:
            if capture_output:
                import io
                output_buffer = io.StringIO()
                sys.stdout = TeeOutput(original_stdout, output_buffer)
                sys.stderr = TeeOutput(original_stderr, output_buffer)
            
            import importlib.util
            module_name = script_name.replace('.py', '')
            spec = importlib.util.spec_from_file_location(module_name, script_name)
            script_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(script_module)
            
            if function_name and hasattr(script_module, function_name):
                getattr(script_module, function_name)()
                success_message = f"{script_name} выполнен успешно (функция {function_name})"
            elif hasattr(script_module, 'main'):
                script_module.main()
                success_message = f"{script_name} выполнен успешно (функция main)"
            else:
                with open(script_name, 'r', encoding='utf-8') as f:
                    exec(f.read(), {'__name__': '__main__'})
                success_message = f"{script_name} выполнен успешно (прямое выполнение)"
            
            if capture_output:
                captured_output = output_buffer.getvalue()
                output_buffer.close()
            
            _(success_message, Fore.GREEN)
            
            if captured_output and capture_output:
                print("\n" + "="*50)
                print(f"ВЫВОД {script_name}:")
                print("="*50)
                print(Fore.CYAN + captured_output + Fore.RESET)
                print("="*50 + "\n")
            
            return True
                
        except Exception as e:
            error_msg = f"Ошибка при импорте {script_name}: {e}"
            _(error_msg, Fore.RED)
            
            try:
                if capture_output:
                    output_buffer = io.StringIO()
                    sys.stdout = TeeOutput(original_stdout, output_buffer)
                    sys.stderr = TeeOutput(original_stderr, output_buffer)
                
                with open(script_name, 'r', encoding='utf-8') as f:
                    script_content = f.read()
                script_content = script_content.replace('python ', 'python3 ').replace('"python"', '"python3"')
                exec(script_content, {'__name__': '__main__'})
                
                if capture_output:
                    captured_output = output_buffer.getvalue()
                    output_buffer.close()
                
                success_message = f"{script_name} выполнен успешно (через exec)"
                _(success_message, Fore.GREEN)
                
                if captured_output and capture_output:
                    print("\n" + "="*50)
                    print(f"ВЫВОД {script_name}:")
                    print("="*50)
                    print(Fore.CYAN + captured_output + Fore.RESET)
                    print("="*50 + "\n")
                
                return True
                
            except Exception as e2:
                _(f"Ошибка при выполнении {script_name} через exec: {e2}", Fore.RED)
                return False
                
        finally:
            sys.stdout = original_stdout
            sys.stderr = original_stderr
                
    except Exception as e:
        _(f"Критическая ошибка при запуске {script_name}: {e}", Fore.RED)
        return False

class TeeOutput:
    def __init__(self, *streams):
        self.streams = streams
    
    def write(self, data):
        for stream in self.streams:
            stream.write(data)
    
    def flush(self):
        for stream in self.streams:
            stream.flush()

def run_autoshop_periodically(hours):
    def autoshop_worker():
        while True:
            _(f"Запуск autoshop.py...", Fore.CYAN)
            run_script_directly('autoshop.py', 'main', capture_output=False)
            _(f"Ожидание {hours} часов до следующего запуска autoshop.py...", Fore.YELLOW)
            time.sleep(hours * 3600)
    
    thread = Thread(target=autoshop_worker, daemon=True)
    thread.start()

def run_bot_in_background():
    import subprocess
    bot_process = subprocess.Popen(
        [sys.executable, 'bot.py'],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        bufsize=1
    )
    def _bot_output_reader():
        for line in bot_process.stdout:
            print(Fore.MAGENTA + "[BOT] " + Fore.RESET + line.rstrip())
    t = Thread(target=_bot_output_reader, daemon=True)
    t.start()
    _(f"bot.py запущен в фоне (PID: {bot_process.pid})", Fore.MAGENTA)

def show_menu():
    print(Fore.CYAN + "=" * 50)
    print(Fore.YELLOW + "          МЕНЮ ЗАПУСКА СЕРВЕРА")
    print(Fore.CYAN + "=" * 50)
    print(Fore.WHITE + "1 - Запустить только main.py")
    print(Fore.WHITE + "2 - Запустить autoshop.py И main.py")
    print(Fore.WHITE + "3 - Запустить sbros.py И main.py")
    print(Fore.WHITE + "4 - Запустить sbros.py И autoshop.py И main.py")
    print(Fore.WHITE + "5 - Запустить bot.py И main.py")
    print(Fore.CYAN + "=" * 50)
    
    while True:
        try:
            choice = input(Fore.GREEN + "Выберите вариант (1-5): ").strip()
            if choice in ['1', '2', '3', '4', '5']:
                return choice
            else:
                print(Fore.RED + "Неверный выбор! Введите число от 1 до 5.")
        except KeyboardInterrupt:
            print(Fore.RED + "\nПрервано пользователем")
            exit()
        except EOFError:
            print(Fore.RED + "\nОшибка ввода")
            exit()

class AntiDDoS:
    def __init__(self):
        self.connection_attempts = defaultdict(deque)
        self.suspected_ips = defaultdict(int)
        self.banned_ips = set()
        self.lock = Lock()
        
        self.settings = {
            'max_connections_per_interval': 3,
            'interval_seconds': 3,
            'temp_ban_duration': 300,
            'max_suspicions': 3
        }
        
        self.temp_bans = {}
    
    def is_banned(self, ip):
        current_time = time.time()
        
        if ip in self.banned_ips:
            return True
        
        if ip in self.temp_bans:
            if current_time < self.temp_bans[ip]:
                return True
            else:
                with self.lock:
                    del self.temp_bans[ip]
                return False
        return False
    
    def check_connection(self, ip):
        current_time = time.time()
        
        if self.is_banned(ip):
            return False
        
        with self.lock:
            while self.connection_attempts[ip] and current_time - self.connection_attempts[ip][0] > self.settings['interval_seconds']:
                self.connection_attempts[ip].popleft()
            
            self.connection_attempts[ip].append(current_time)
            
            if len(self.connection_attempts[ip]) > self.settings['max_connections_per_interval']:
                self.suspected_ips[ip] += 1
                
                if self.suspected_ips[ip] >= self.settings['max_suspicions']:
                    self.banned_ips.add(ip)
                    _(f"IP {ip} забанен до перезагрузки сервера за многократные подозрительные подключения", Fore.RED)
                else:
                    ban_until = current_time + self.settings['temp_ban_duration']
                    self.temp_bans[ip] = ban_until
                    _(f"IP {ip} временно заблокирован на {self.settings['temp_ban_duration']} секунд. Подозрение #{self.suspected_ips[ip]}", Fore.RED)
                
                return False
            
            return True
    
    def clear_all_bans(self):
        with self.lock:
            self.connection_attempts.clear()
            self.suspected_ips.clear()
            self.banned_ips.clear()
            self.temp_bans.clear()

class Server:
    Clients = {"ClientCounts": 0, "Clients": {}, "Online": 0}
    ThreadCount = 0
    ConnectedIPs = set()
    anti_ddos = AntiDDoS()

    def __init__(self, ip: str, port: int):
        self.server = socket.socket()
        self.port = port
        self.ip = ip
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.settimeout(None)

    def start(self):
        print_banner()
        
        reset_all_online_status()
        
        Server.Online = 0
        Server.ConnectedIPs.clear()
        Server.anti_ddos.clear_all_bans()
        update_config_online(0)
        
        if not os.path.exists('./config.json'):
            _(Fore.YELLOW + "Создание config.json...", Fore.YELLOW)
            Config.create_config(self)

        DataBase.createDatabaseFolders()
        DataBase.startCleanupScheduler()
        _("Планировщик очистки невалидных аккаунтов запущен", Fore.GREEN)

        self.server.bind((self.ip, self.port))
        _(f'Сервер запущен! {Fore.GREEN}IP: {self.ip}, Port: {self.port}', Fore.CYAN)
        _(f'{Fore.MAGENTA}CREATOR: {Fore.YELLOW}FREAK | KISAWWR', Fore.MAGENTA)
        _(f'{Fore.BLUE}Текущий онлайн: {Fore.GREEN}{Server.Online}', Fore.BLUE)
        print("\n")
        
        while True:
            try:
                self.server.listen()
                client, address = self.server.accept()
                ip = address[0]
                
                if not Server.anti_ddos.check_connection(ip):
                    client.close()
                    _(f"Отклонено подключение от {ip} (анти-DDoS защита)", Fore.YELLOW)
                    continue
                
                if ip not in Server.ConnectedIPs:
                    Server.Online += 1
                    Server.ConnectedIPs.add(ip)
                    update_config_online(Server.Online)
                
                _(f'Новое подключение! IP: {ip}', Fore.GREEN)
                _(f'Текущий онлайн: {Server.Online}', Fore.BLUE)
                ClientThread(client, address).start()
                Server.ThreadCount += 1
                
            except Exception as e:
                _(f"Ошибка при accept: {str(e)}", Fore.RED)

class ClientThread(Thread):
    def __init__(self, client, address):
        super().__init__()
        self.client = client
        self.address = address
        self.device = Device(self.client)
        self.player = Players(self.device)
        self.client.settimeout(None)
        self.ip = address[0]
        self.player_authenticated = False
        self.player_low_id = None
        self.player_name = None
        self.player_token = None

    def update_player_online_status(self, online_status):
        try:
            if not self.player_low_id:
                _(f"Ошибка: player_low_id не установлен, пропускаем обновление статуса", Fore.RED)
                return False
            
            from Database.DatabaseManager import DataBase
            
            db = DataBase()
            db.updatePlayerOnlineStatus(self.player_low_id, online_status)
            
            status_text = "ONLINE" if online_status == 1 else "OFFLINE"
            _(f"Статус игрока {self.player_name} (ID: {self.player_low_id}) обновлен: {status_text}", 
              Fore.GREEN if online_status == 1 else Fore.YELLOW)
            return True
                
        except Exception as e:
            _(f"Ошибка при обновлении статуса online: {e}", Fore.RED)
            return False

    def recvall(self, length: int):
        data = b''
        while len(data) < length:
            try:
                s = self.client.recv(length - len(data))
                if not s:
                    raise ConnectionError("Соединение закрыто клиентом")
                data += s
            except:
                raise ConnectionError("Ошибка при получении данных")
        return data

    def run(self):
        try:
            while True:
                header = self.client.recv(7)
                if not header:
                    break
                    
                packet_id = int.from_bytes(header[:2], 'big')
                length = int.from_bytes(header[2:5], 'big')
                print(f"[PKT] id={packet_id} len={length}")
                
                if length > 1000000:
                    raise ConnectionError("Слишком большой пакет")
                
                data = self.recvall(length)

                if packet_id in packets:
                    message = packets[packet_id](self.client, self.player, data)
                    message.decode()
                    message.process()

                    if packet_id == 10101:
                        if hasattr(self.player, 'low_id') and self.player.low_id:
                            self.player_low_id = self.player.low_id
                            self.player_name = getattr(self.player, 'name', f'Player_{self.player_low_id}')
                            self.player_token = getattr(self.player, 'token', None)
                            
                            if not self.player_authenticated:
                                self.player_authenticated = True
                                _(f'Авторизован игрок {self.player_name} | (ID: {self.player.low_id}) (TOKEN: {self.player_token})', Fore.GREEN)
                                
                                self.update_player_online_status(1)

        except (ConnectionAbortedError, ConnectionResetError, ConnectionError) as e:
            _(f"IP: {self.address[0]} отключился! Причина: {str(e)}", Fore.RED)
        except Exception as e:
            _(f"Ошибка с IP {self.address[0]}: {str(e)}", Fore.RED)
        finally:
            if self.player_low_id:
                self.update_player_online_status(0)
            
            if self.ip in Server.ConnectedIPs:
                Server.Online -= 1
                Server.ConnectedIPs.remove(self.ip)
                update_config_online(Server.Online)
                _(f'Текущий онлайн: {Server.Online}', Fore.BLUE)
            
            self.client.close()

if __name__ == '__main__':
    try:
        python_version = sys.version_info.major
        _(f"Запуск на Python {python_version}.x", Fore.CYAN)
        
        choice = show_menu()
        
        hours = None
        
        if choice in ['2', '4']:
            while True:
                try:
                    hours_input = input(Fore.GREEN + "Как часто обновлять магазин? (1-24 часа): ").strip()
                    hours = int(hours_input)
                    if 1 <= hours <= 24:
                        break
                    else:
                        print(Fore.RED + "Неверное значение! Введите число от 1 до 24.")
                except ValueError:
                    print(Fore.RED + "Неверный формат! Введите число от 1 до 24.")
                except KeyboardInterrupt:
                    print(Fore.RED + "\nПрервано пользователем")
                    exit()

        if choice == '5':
            if os.path.exists('bot.py'):
                run_bot_in_background()
            else:
                _(f"bot.py не найден, запускаем только сервер...", Fore.YELLOW)
        
        if choice in ['3', '4']:
            _(f"Запуск sbros.py...", Fore.CYAN)
            
            print(Fore.CYAN + "\n" + "="*60)
            print("НАЧАЛО ВЫПОЛНЕНИЯ sbros.py")
            print("="*60 + Fore.RESET + "\n")
            
            success = run_script_directly('sbros.py', 'reset_trophy_season', capture_output=True)
            
            print(Fore.CYAN + "\n" + "="*60)
            print("ЗАВЕРШЕНИЕ ВЫПОЛНЕНИЯ sbros.py")
            print("="*60 + Fore.RESET + "\n")
            
            if success:
                _(f"sbros.py выполнен успешно", Fore.GREEN)
            else:
                _(f"Продолжаем запуск сервера несмотря на ошибку sbros.py...", Fore.YELLOW)
        
        if choice in ['2', '4']:
            _(f"Запуск autoshop.py с интервалом {hours} часов...", Fore.CYAN)
            
            print(Fore.CYAN + "\n" + "="*60)
            print("НАЧАЛО ВЫПОЛНЕНИЯ autoshop.py")
            print("="*60 + Fore.RESET + "\n")
            
            run_script_directly('autoshop.py', 'main', capture_output=True)
            
            print(Fore.CYAN + "\n" + "="*60)
            print("ЗАВЕРШЕНИЕ ВЫПОЛНЕНИЯ autoshop.py")
            print("="*60 + Fore.RESET + "\n")
            
            run_autoshop_periodically(hours)
        
        print(Fore.YELLOW + "\n" + "="*60)
        print("ЗАПУСК ОСНОВНОГО СЕРВЕРА...")
        print("Нажмите Ctrl+C для остановки сервера")
        print("="*60 + Fore.RESET + "\n")
        time.sleep(2)
        
        _(f"Запуск основного сервера...", Fore.CYAN)
        port = 9339
        ip = '0.0.0.0'
        
        server = Server(ip, port)
        server.start()
        
    except KeyboardInterrupt:
        _(f"\n{Fore.RED}Сервер остановлен администратором", Fore.RED)
        update_config_online(0)
    except Exception as e:
        _(f"\n{Fore.RED}Критическая ошибка: {str(e)}", Fore.RED)
        _(f"\n{Fore.YELLOW}Подробности:", Fore.YELLOW)
        traceback.print_exc()
        update_config_online(0)