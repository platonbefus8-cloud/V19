from Utils.Helpers import Helpers
import json
import time
from Database.DatabaseManager import DataBase

class Shop:
    """
    << Shop Offers IDs List >>

    0 = Free Brawl Box
    1 = Gold
    2 = Random Brawler
    3 = Brawler
    4 = Skin
    5 = StarPower
    6 = Brawl Box
    7 = Tickets
    8 = Power Points (for a specific brawler)
    9 = Token Doubler
    10 = Mega Box
    12 = Power Points
    14 = Big Box
    16 = Gems
    """

    offers = "шайлушай"

    def loadOffers(self):
        self.offers = []        
        try:
            with open("JSON/offers.json", "r", encoding='utf-8') as f:
                data = json.load(f)
                if data and isinstance(data, dict):
                    for i in data.values():
                        if isinstance(i, dict):  # Проверяем что это валидный объект
                            self.offers.append(i)
                else:
                    print("offers.json is empty or invalid format, skipping...")
        except FileNotFoundError:
            print("offers.json not found, skipping...")
        except json.JSONDecodeError as e:
            print(f"Error parsing offers.json: {e}, skipping...")
        except Exception as e:
            print(f"Unexpected error with offers.json: {e}, skipping...")
        
        try:
            with open("JSON/autoshop.json", "r", encoding='utf-8') as f:
                data = json.load(f)
                if data and isinstance(data, dict):
                    for i in data.values():
                        if isinstance(i, dict):  # Проверяем что это валидный объект
                            self.offers.append(i)
                else:
                    print("autoshop.json is empty or invalid format, skipping...")
        except FileNotFoundError:
            print("autoshop.json not found, skipping...")
        except json.JSONDecodeError as e:
            print(f"Error parsing autoshop.json: {e}, skipping...")
        except Exception as e:
            print(f"Unexpected error with autoshop.json: {e}, skipping...")

    def UpdateOfferData(self, i):
        try:
            with open("JSON/offers.json", "r", encoding='utf-8') as f:
                data = json.load(f)
            if data and isinstance(data, dict) and str(i) in data:
                if "WhoBuyed" not in data[str(i)]:
                    data[str(i)]["WhoBuyed"] = []
                if int(self.player.low_id) not in data[str(i)]["WhoBuyed"]:
                    data[str(i)]["WhoBuyed"].append(int(self.player.low_id))
                with open("JSON/offers.json", "w", encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False)
                return True
        except (FileNotFoundError, json.JSONDecodeError, KeyError, Exception) as e:
            print(f"Error updating offer in offers.json: {e}")
        
        try:
            with open("JSON/autoshop.json", "r", encoding='utf-8') as f:
                data = json.load(f)
            if data and isinstance(data, dict) and str(i) in data:
                if "WhoBuyed" not in data[str(i)]:
                    data[str(i)]["WhoBuyed"] = []
                if int(self.player.low_id) not in data[str(i)]["WhoBuyed"]:
                    data[str(i)]["WhoBuyed"].append(int(self.player.low_id))
                with open("JSON/autoshop.json", "w", encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False)
                return True
        except (FileNotFoundError, json.JSONDecodeError, KeyError, Exception) as e:
            print(f"Error updating offer in autoshop.json: {e}")
        
        return False

    def RemoveOffer(self, i):
        try:
            with open("JSON/offers.json", "r", encoding='utf-8') as f:
                data = json.load(f)
            if data and isinstance(data, dict) and str(i) in data:
                data.pop(str(i))
                with open("JSON/offers.json", "w", encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False)
                return True
        except (FileNotFoundError, json.JSONDecodeError, KeyError, Exception) as e:
            print(f"Error removing offer from offers.json: {e}")
        return False

    gold = [
        {
            'Cost': 20,
            'Amount': 150
        },

        {
            'Cost': 50,
            'Amount': 400
        },

        {
            'Cost': 140,
            'Amount': 1200
        }

    ]

    boxes = [
        {
            'Name': 'Big Box',
            'Cost': 30,
            'Multiplier': 1
        },

        {
            'Name': 'Mega Box',
            'Cost': 80,
            'Multiplier': 1
        }

    ]

    token_doubler = {

        'Cost': 50,
        'Amount': 1000
    }
    
    def Timer(self):
        result = time.localtime(int(time.time()))
        current_seconds = result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600)
        target_seconds = 12 * 3600  # 12:00 МСК
        
        if current_seconds < target_seconds:
            return target_seconds - current_seconds
        else:
            return (86400 - current_seconds) + target_seconds

    def encodeShopOffers(self):
        Shop.loadOffers(self)
        wow = self.offers
        count = len(wow)
        self.writeVint(count)
        
        for i in range(count):
            item = wow[i]
            
            if not isinstance(item, dict):
                continue
                
            is_buyed = False
            if "WhoBuyed" in item and self.player.low_id in item["WhoBuyed"]:
                is_buyed = True
            
            if all(key in item for key in ['ID', 'Multiplier', 'BrawlerID', 'SkinID']):
                if item['ID'][0] != 0 and item['ID'][1] != 0 and item['ID'][2] != 0:
                    self.writeVint(3)
                    self.writeVint(item['ID'][0]) # ItemID
                    self.writeVint(item['Multiplier'][0]) # Amount
                    self.writeScId(16, item['BrawlerID'][0])
                    self.writeVint(item['SkinID'][0]) # ItemID                
                    self.writeVint(item['ID'][1]) # ItemID
                    self.writeVint(item['Multiplier'][1]) # Amount
                    self.writeScId(16, item['BrawlerID'][1])
                    self.writeVint(item['SkinID'][1]) # ItemID
                    
                    self.writeVint(item['ID'][2]) # ItemID
                    self.writeVint(item['Multiplier'][2]) # Amount
                    self.writeScId(16, item['BrawlerID'][2])
                    self.writeVint(item['SkinID'][2]) # ItemID
                    
                elif item['ID'][0] != 0 and item['ID'][1] != 0:
                    self.writeVint(2)
                    self.writeVint(item['ID'][0]) # ItemID
                    self.writeVint(item['Multiplier'][0]) # Amount
                    self.writeScId(16, item['BrawlerID'][0])
                    self.writeVint(item['SkinID'][0]) # ItemID
                    
                    self.writeVint(item['ID'][1]) # ItemID
                    self.writeVint(item['Multiplier'][1]) # Amount
                    self.writeScId(16, item['BrawlerID'][1])
                    self.writeVint(item['SkinID'][1]) # ItemID
                    
                else:
                    self.writeVint(1)
                    self.writeVint(item['ID'][0]) # ItemID
                    self.writeVint(item['Multiplier'][0]) # Amount
                    self.writeScId(16, item['BrawlerID'][0])
                    self.writeVint(item['SkinID'][0]) # ItemID
            else:
                continue
            
            self.writeVint(item.get('ShopType', 0))  # [0 = Offer, 1 = Gold, 2 = Skins 3 = Star Shop]
            
            cost = item.get('Cost', 0)
            shop_type = item.get('ShopType', 0)
            
            if self.player.low_id in item.get("WhoBuyedDonat", []) and item.get("ShopDonat", 0) == 1:
                self.writeVint(0)  # Бесплатно после покупки донат
            elif self.player.vip > 0 and item.get("ShopDonat", 0) != 1 and cost > 0:
                # Применяем скидку VIP
                self.writeVint(int(cost * 0.9))
            else:
                self.writeVint(cost)  # Оригинальная цена

            timer_value = Helpers.ShopTimer(self)
            self.writeVint(timer_value) # Timer

            self.writeVint(2) # 2-убирает new 0-ничего 1-new
            self.writeVint(100)
            
            if is_buyed:
                self.writeBoolean(True)
            else:
                self.writeBoolean(False)

            self.writeBoolean(False)
            self.writeBoolean(item.get('ShopDisplay', False))  # [0 = Normal, 1 = Daily Deals]
            self.writeVint(item.get('OldCost', 0))
            self.writeVint(0)

            self.writeInt(0)
            if self.player.low_id in item.get("WhoBuyedDonat", []) and item.get("ShopDonat", 0) == 1:
                self.write_string_reference("<c3>СПАСИБО ЗА ПОКУПКУ!</c>") # Item name
            else:
                self.write_string_reference(item.get('OfferTitle', '')) # Item name

            self.writeBoolean(False)