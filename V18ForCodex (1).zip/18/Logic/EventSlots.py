import time, json, random

class EventSlots:

    def loadEvents(self):
    	with open("JSON/events.json", "r") as f:
    		data=json.load(f)
    		return data

    def updateEventData(self, i, new):
    	with open("JSON/events.json", "r") as f:
    		data=json.load(f)
    	try:
    		data[str(i)]["ID"]=new
    	except:
    		data[str(i)]={}
    		data[str(i)]["ID"]=new
    	with open("JSON/events.json", "w") as f:
    		json.dump(data,f)

    def updateEventClaimed(self, i, new):
      with open("JSON/events.json", "r") as f:
        data=json.load(f)
      try:
        data[str(i)]["Collected"]=[new]
      except:
        data[str(i)]={}
        data[str(i)]["Collected"]=[new]
      with open("JSON/events.json", "w") as f:
        json.dump(data,f)

    def SetEventClaimed(self):
      TokenNew = 0
      EventSlots.updateEventClaimed(self, 0, TokenNew)
      EventSlots.updateEventClaimed(self, 1, TokenNew)
      EventSlots.updateEventClaimed(self, 2, TokenNew)
      EventSlots.updateEventClaimed(self, 3, TokenNew)
      EventSlots.updateEventClaimed(self, 4, TokenNew)
      EventSlots.updateEventClaimed(self, 5, TokenNew)
      EventSlots.updateEventClaimed(self, 6, TokenNew)

    def SetEventSlotsData(self):
      # Случайные карты для каждого слота
      bb_maps = [24, 25, 50, 51, 54]
      sd_maps = [13, 14, 15, 43, 16]
      heist_maps = [17, 18, 19, 49, 55]
      gems_maps = [7, 8, 9, 10, 11, 12, 124]
      star_maps = [21, 30, 39, 57, 67, 66]
      robowars_maps = [110, 111]
      
      # Выбираем случайные карты
      bb = random.choice(bb_maps)
      sd = random.choice(sd_maps)
      heist = random.choice(heist_maps)
      gems = random.choice(gems_maps)
      star = random.choice(star_maps)
      robowars = random.choice(robowars_maps)
      
      EventSlots.updateEventData(self, 0, bb)
      EventSlots.updateEventData(self, 1, sd)
      EventSlots.updateEventData(self, 2, heist)
      EventSlots.updateEventData(self, 3, gems)
      EventSlots.updateEventData(self, 4, star)
      EventSlots.updateEventData(self, 5, robowars)
        #Maps
        
        #                        ticketi
        #21 biggame
        #30 biggame vzbuchka
        #39 raid beregi i beregis
        #57 boss savasi - machine zone
        #67 boss metalolom
        #66 big game pogrom

    def Timer(self):
        result = time.localtime(int(time.time()))

        return (86400 - (result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600)))

    def offset(self):
        events = EventSlots.loadEvents(self)
        Timer = EventSlots.Timer(self)

        count = len(events)
        self.writeVint(count)

        maps = events.values()

        for event in maps:

            self.writeVint(list(maps).index(event) + 1)
            self.writeVint(list(maps).index(event) + 1)
            self.writeVint(event['Ended'])  # IsActive | 0 = Active, 1 = Disabled
            self.writeVint(Timer)  # Timer

            self.writeVint(event['Tokens'])
            self.writeScId(15, event["ID"])

            if self.player.low_id in event['Collected']:
                self.writeVint(2)
            else:
                self.writeVint(1)

            self.writeString() # "Double Experience Event" Text
            self.writeVint(0)

            bb_maps_ids = [24, 25, 50, 51, 54]            
            if event["ID"] in bb_maps_ids:
                modifier = random.choice([1, 3, 4, 5])
            else:
                modifier = random.randint(1, 5)
                
            if event['Modifier'] == 0:
                self.writeBoolean(True)
                self.writeVint(modifier)
            elif event['Modifier'] > 0 and event['Modifier'] < 6:
                self.writeBoolean(True)
                self.writeVint(event['Modifier'])
            else:
            	self.writeBoolean(False)

            self.writeVint(0)