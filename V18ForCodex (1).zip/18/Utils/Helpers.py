import string
import random
import time
from Utils.Writer import Writer

class Helpers(Writer):

    def randomStringDigits(self):
        length = random.randint(15, 25)
        result = []
        for i in range(length):
            if i % 2 == 0:
                result.append(random.choice(string.ascii_uppercase))
            else:
                result.append(str(random.randint(1, 9)))
        return ''.join(result)

    def randomID(self):
        length = 9
        return int(''.join([str(random.randint(0, 9)) for _ in range(length)]))

    def randomClubID(self):
        length = 9
        return int(''.join([str(random.randint(0, 9)) for _ in range(length)]))
    
    def LeaderboardTimer(self):
        result = time.localtime(int(time.time()))
        day = (result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600) + (result.tm_mday * 86400))
        month = result.tm_mon
        if month == 1:
        	seconds = 2764800
        elif month == 2:
        	seconds = 2505600
        elif month == 3:
        	seconds = 2764800
        elif month == 4:
        	seconds = 2678400
        elif month == 5:
        	seconds = 2764800
        elif month == 6:
        	seconds = 2678400
        elif month == 7:
        	seconds = 2764800
        elif month == 8:
        	seconds = 2764800
        elif month == 9:
        	seconds = 2678400
        elif month == 10:
        	seconds = 2764800
        elif month == 11:
        	seconds = 2678400
        elif month == 12:
        	seconds = 2764800

        return (seconds - day)
        
    def NickTimer(self):
        result = time.localtime(int(time.time()))
        
        return (86400 - (result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600)))
        
    def TimerBattle(self):
    	if self.player.time == 7:
    	   		self.player.pon = False
    	   		
        		self.player.time = 1
        		while self.player.pon:
        			print(self.player.time)
        			time.sleep(1)
        			self.player.time += 1
        
    def ShopTimer(self):
        result = time.localtime(int(time.time()))
        current_seconds = result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600)
        target_seconds = 12 * 3600  # 12:00 МСК
        
        if current_seconds < target_seconds:
            return target_seconds - current_seconds
        else:
            return (86400 - current_seconds) + target_seconds
        
    def ShopTimer4bibi(self):
        result = time.localtime(int(time.time()))
        
        return (604800 - (result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 500)))
        
    def EventTimer(self):
        result = time.localtime(int(time.time()))

        return (86400 - (result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600)))