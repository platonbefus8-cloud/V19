import json
import random
import os
import time
from pathlib import Path
from tinydb import TinyDB, Query
import threading

RANDOM_JSON_PATH = "JSON/random.json"
OFFERS_JSON_PATH = "JSON/autoshop.json"
MIN_OFFERS =  8 # Минимум 8
MAX_OFFERS = 8 # Максимум 8

os.makedirs(os.path.dirname(RANDOM_JSON_PATH), exist_ok=True)
os.makedirs(os.path.dirname(OFFERS_JSON_PATH), exist_ok=True)

DEFAULT_RANDOM_DATA = {
    "offers": {
        "0": [
            {"ID": [1, 7, 16], "OfferTitle": "РЕСУРСЫ | <c3>300₽</c>", "Cost": 300, "OldCost": 0, "Multiplier": [1000, 50, 100], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [6, 14, 0], "OfferTitle": "ЯЩИКИ | <c3>250₽</c>", "Cost": 250, "OldCost": 0, "Multiplier": [10, 5, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [1, 14, 0], "OfferTitle": "АКЦИЯ | <c3>600₽</c>", "Cost": 600, "OldCost": 0, "Multiplier": [5000, 10, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [1, 16, 14], "OfferTitle": "РЕСУРСЫ | <c3>500₽</c>", "Cost": 500, "OldCost": 0, "Multiplier": [2000, 200, 10], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "МАКС. УРОВЕРЬ | <c3>250₽</c>", "Cost": 250, "OldCost": 0, "Multiplier": [1410, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [7, 9, 16], "OfferTitle": "ВКУС ПОБЕДЫ | <c3>400₽</c>", "Cost": 400, "OldCost": 0, "Multiplier": [50, 1000, 100], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [1, 16, 0], "OfferTitle": "СУПЕР СКИДКА | <c3>700₽</c>", "Cost": 700, "OldCost": 0, "Multiplier": [10000, 2000, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "ОЧКИ СИЛЫ | <c3>100₽</c>", "Cost": 100, "OldCost": 0, "Multiplier": [500, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [5, 0, 0], "OfferTitle": "ЗВЁЗДНАЯ СИЛА | <c3>200₽</c>", "Cost": 200, "OldCost": 0, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [3, 0, 0], "OfferTitle": "БОЕЦ | <c3>35-500₽</c>", "Cost": 0, "OldCost": 0, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []},
            {"ID": [4, 0, 0], "OfferTitle": "СКИН | <c3>35-215₽</c>", "Cost": 0, "OldCost": 0, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 3, "ShopDisplay": False, "ShopDonat": 1, "WhoBuyedDonat": []}
        ],
        "1": [                        
            {"ID": [1, 7, 0], "OfferTitle": "ВКУС ПОБЕДЫ", "Cost": 150, "OldCost": 250, "Multiplier": [2000, 10, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 9, 0], "OfferTitle": "ДЛЯ ЯЩИКОВ", "Cost": 150, "OldCost": 265, "Multiplier": [500, 250, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 12, 0], "OfferTitle": "К ПОВЫШЕНИЮ", "Cost": 250, "OldCost": 350, "Multiplier": [1000, 500, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 7, 9], "OfferTitle": "ВКУС ПОБЕДЫ", "Cost": 150, "OldCost": 300, "Multiplier": [1500, 25, 500], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 14, 0], "OfferTitle": "БОЛЬШЕ ЯЩИКОВ", "Cost": 550, "OldCost": 1100, "Multiplier": [5000, 20, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 7, 9], "OfferTitle": "РЕСУРСЫ", "Cost": 200, "OldCost": 400, "Multiplier": [1000, 50, 1000], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [6, 14, 0], "OfferTitle": "ЯЩИКИ", "Cost": 100, "OldCost": 250, "Multiplier": [10, 5, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 14, 0], "OfferTitle": "АКЦИЯ", "Cost": 400, "OldCost": 800, "Multiplier": [5000, 10, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "МАКС. УРОВЕРЬ", "Cost": 150, "OldCost": 300, "Multiplier": [1410, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "ОЧКИ СИЛЫ", "Cost": 75, "OldCost": 150, "Multiplier": [500, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
        ],
        "2": [                        
            {"ID": [1, 7, 0], "OfferTitle": "ВКУС ПОБЕДЫ", "Cost": 150, "OldCost": 250, "Multiplier": [2000, 10, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 9, 0], "OfferTitle": "ДЛЯ ЯЩИКОВ", "Cost": 150, "OldCost": 265, "Multiplier": [500, 250, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 12, 0], "OfferTitle": "К ПОВЫШЕНИЮ", "Cost": 250, "OldCost": 350, "Multiplier": [1000, 500, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 7, 9], "OfferTitle": "ВКУС ПОБЕДЫ", "Cost": 150, "OldCost": 300, "Multiplier": [1500, 25, 500], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 14, 0], "OfferTitle": "БОЛЬШЕ ЯЩИКОВ", "Cost": 550, "OldCost": 1100, "Multiplier": [5000, 20, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 7, 9], "OfferTitle": "РЕСУРСЫ", "Cost": 200, "OldCost": 400, "Multiplier": [1000, 50, 1000], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [6, 14, 0], "OfferTitle": "ЯЩИКИ", "Cost": 100, "OldCost": 250, "Multiplier": [10, 5, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [1, 14, 0], "OfferTitle": "АКЦИЯ", "Cost": 400, "OldCost": 800, "Multiplier": [5000, 10, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "МАКС. УРОВЕРЬ", "Cost": 150, "OldCost": 300, "Multiplier": [1410, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "ОЧКИ СИЛЫ", "Cost": 75, "OldCost": 150, "Multiplier": [500, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
        ],
        "3": [
            {"ID": [6, 0, 0], "OfferTitle": "МАЛЕНЬКИЕ ЯЩИКИ", "Cost": 20, "OldCost": 30, "Multiplier": [3, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [14, 0, 0], "OfferTitle": "БОЛЬЩИЕ ЯЩИКИ", "Cost": 45, "OldCost": 90, "Multiplier": [3, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [10, 0, 0], "OfferTitle": "МЕГАЯЩИК", "Cost": 40, "OldCost": 80, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "25 ОЧКОВ СИЛ", "Cost": 50, "OldCost": 0, "Multiplier": [25, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "50 ОЧКОВ СИЛ", "Cost": 100, "OldCost": 0, "Multiplier": [50, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "75 ОЧКОВ СИЛ", "Cost": 150, "OldCost": 0, "Multiplier": [75, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "100 ОЧКОВ СИЛ", "Cost": 200, "OldCost": 0, "Multiplier": [100, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "125 ОЧКОВ СИЛ", "Cost": 250, "OldCost": 0, "Multiplier": [125, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "150 ОЧКОВ СИЛ", "Cost": 300, "OldCost": 0, "Multiplier": [150, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []}
        ],
        "4": [
            {"ID": [6, 0, 0], "OfferTitle": "МАЛЕНЬКИЕ ЯЩИКИ", "Cost": 20, "OldCost": 30, "Multiplier": [3, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [14, 0, 0], "OfferTitle": "БОЛЬЩИЕ ЯЩИКИ", "Cost": 45, "OldCost": 90, "Multiplier": [3, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [10, 0, 0], "OfferTitle": "МЕГАЯЩИК", "Cost": 40, "OldCost": 80, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "25 ОЧКОВ СИЛ", "Cost": 50, "OldCost": 0, "Multiplier": [25, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "50 ОЧКОВ СИЛ", "Cost": 100, "OldCost": 0, "Multiplier": [50, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "75 ОЧКОВ СИЛ", "Cost": 150, "OldCost": 0, "Multiplier": [75, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "100 ОЧКОВ СИЛ", "Cost": 200, "OldCost": 0, "Multiplier": [100, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "125 ОЧКОВ СИЛ", "Cost": 250, "OldCost": 0, "Multiplier": [125, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "150 ОЧКОВ СИЛ", "Cost": 300, "OldCost": 0, "Multiplier": [150, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []}
        ],
        "5": [
            {"ID": [6, 0, 0], "OfferTitle": "МАЛЕНЬКИЕ ЯЩИКИ", "Cost": 20, "OldCost": 30, "Multiplier": [3, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [14, 0, 0], "OfferTitle": "БОЛЬЩИЕ ЯЩИКИ", "Cost": 45, "OldCost": 90, "Multiplier": [3, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [10, 0, 0], "OfferTitle": "МЕГАЯЩИК", "Cost": 40, "OldCost": 80, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "25 ОЧКОВ СИЛ", "Cost": 50, "OldCost": 0, "Multiplier": [25, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "50 ОЧКОВ СИЛ", "Cost": 100, "OldCost": 0, "Multiplier": [50, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "75 ОЧКОВ СИЛ", "Cost": 150, "OldCost": 0, "Multiplier": [75, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "100 ОЧКОВ СИЛ", "Cost": 200, "OldCost": 0, "Multiplier": [100, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "125 ОЧКОВ СИЛ", "Cost": 250, "OldCost": 0, "Multiplier": [125, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [12, 0, 0], "OfferTitle": "150 ОЧКОВ СИЛ", "Cost": 300, "OldCost": 0, "Multiplier": [150, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": True, "ShopDonat": 0, "WhoBuyedDonat": []}
        ],
        "6": [
            {"ID": [3, 0, 0], "OfferTitle": "АКЦИЯ БОЕЦ | <c3>20% СКИДКА</c>", "Cost": 999, "OldCost": 0, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []},
            {"ID": [4, 0, 0], "OfferTitle": "АКЦИЯ СКИН | <c3>20% СКИДКА</c>", "Cost": 999, "OldCost": 0, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 0, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []}
        ],
        "7": [
            {"ID": [5, 0, 0], "OfferTitle": "ЗВЁЗДНАЯ СИЛА | <c3>НУЖЕН 9 УР. СИЛЫ</c>", "Cost": 2000, "OldCost": 0, "Multiplier": [1, 0, 0], "BrawlerID": [0, 0, 0], "SkinID": [0, 0, 0], "WhoBuyed": [], "ShopType": 1, "ShopDisplay": False, "ShopDonat": 0, "WhoBuyedDonat": []}
        ]
    },
    "brawler_costs": {
        "40": [6, 10, 13, 24],
        "65": [4, 18, 19, 25],
        "135": [15, 16, 20, 26],
        "280": [11, 17, 21],
        "560": [5, 12, 23]
    },
    "brawler_oldcosts": {
        "50": [6, 10, 13, 24],
        "80": [4, 18, 19, 25],
        "170": [15, 16, 20, 26],
        "350": [11, 17, 21],
        "700": [5, 12, 23]
    },
    "skin_costs": {
        "40": [15, 27, 29, 94, 117],
        "65": [5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93],
        "80": [95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115],
        "120": [26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91],
        "200": [96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116],
        "240": [49]
    },
    "skin_oldcosts": {
        "50": [15, 27, 29, 94, 117],
        "80": [5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93],
        "100": [95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115],
        "150": [26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91],
        "250": [96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116],
        "300": [49]
    },
    "brawler_costs_donat": {
        "35": [6, 10, 13, 24],
        "60": [4, 18, 19, 25],
        "125": [15, 16, 20, 26],
        "250": [11, 17, 21],
        "500": [5, 12, 23]
    },
    "skin_costs_donat": {
        "35": [15, 27, 29, 94, 117],
        "60": [5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93],
        "110": [26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91],
        "270": [49]
    }
}

def load_or_create_random_json():
    try:
        with open(RANDOM_JSON_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        with open(RANDOM_JSON_PATH, 'w', encoding='utf-8') as f:
            json.dump(DEFAULT_RANDOM_DATA, f, ensure_ascii=False)
        return DEFAULT_RANDOM_DATA

def get_cost_for_brawler(brawler_id, random_data, is_donat=False):
    cost_dict = random_data.get('brawler_costs_donat', {}) if is_donat else random_data.get('brawler_costs', {})
    for cost, ids in cost_dict.items():
        if brawler_id in ids:
            return int(cost)
    return None

def get_oldcost_for_brawler(brawler_id, random_data):
    cost_dict = random_data.get('brawler_oldcosts', {})
    for cost, ids in cost_dict.items():
        if brawler_id in ids:
            return int(cost)
    return None

def get_cost_for_skin(skin_id, random_data, is_donat=False):
    cost_dict = random_data.get('skin_costs_donat', {}) if is_donat else random_data.get('skin_costs', {})
    for cost, ids in cost_dict.items():
        if skin_id in ids:
            return int(cost)
    return None

def get_oldcost_for_skin(skin_id, random_data):
    cost_dict = random_data.get('skin_oldcosts', {})
    for cost, ids in cost_dict.items():
        if skin_id in ids:
            return int(cost)
    return None

def generate_starpower_offer(random_data):
    # Используем базовое предложение из категории 0
    base_offer = random.choice([offer for offer in random_data['offers']['0'] if offer['ID'][0] == 5])
    
    # Фиксированный список ID бойцов для звёздной силы
    brawler_ids = [4, 5, 6, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26]
    
    selected_brawler = random.choice(brawler_ids)
    
    special_offer = base_offer.copy()
    special_offer['BrawlerID'] = [selected_brawler, 0, 0]
    
    return special_offer

def generate_brawler_offer(random_data):
    # Используем базовое предложение из категории 0
    base_offer = random.choice([offer for offer in random_data['offers']['0'] if offer['ID'][0] == 3])
    
    # Фиксированный список ID бойцов
    all_brawlers = [4, 5, 6, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26]
    
    selected_brawler = random.choice(all_brawlers)
    cost = get_cost_for_brawler(selected_brawler, random_data, is_donat=True)
    
    # Если стоимость не найдена, используем минимальную
    if cost is None:
        cost = 35
    
    special_offer = base_offer.copy()
    special_offer['BrawlerID'] = [selected_brawler, 0, 0]
    special_offer['Cost'] = cost
    special_offer['OfferTitle'] = f"БОЕЦ | <c3>{cost}₽</c>"
    
    return special_offer

def generate_skin_offer(random_data):
    # Используем базовое предложение из категории 0
    base_offer = random.choice([offer for offer in random_data['offers']['0'] if offer['ID'][0] == 4])
    
    # Фиксированный список ID скинов
    all_skins = [29, 52, 97, 98, 2, 69, 95, 96, 25, 64, 103, 104, 5, 58, 72, 91, 26, 68, 105, 106, 11, 101, 102, 27, 59, 90, 92, 44, 47, 15, 60, 79, 56, 57, 113, 114, 28, 30, 50, 63, 75, 20, 49, 71, 107, 108, 99, 100, 94, 70, 61, 88, 45, 111, 112, 117, 109, 110, 93, 115, 116]
    
    selected_skin = random.choice(all_skins)
    cost = get_cost_for_skin(selected_skin, random_data, is_donat=True)
    
    # Если стоимость не найдена, используем минимальную
    if cost is None:
        cost = 35
    
    special_offer = base_offer.copy()
    special_offer['SkinID'] = [selected_skin, 0, 0]
    special_offer['Cost'] = cost
    special_offer['OfferTitle'] = f"СКИН | <c3>{cost}₽</c>"
    
    return special_offer

def generate_special_offer(random_data):
    base_offer = random.choice(random_data['offers']['6'])
    
    special_offer = base_offer.copy()
    
    if base_offer['ID'][0] == 3:
        # Для бойца
        all_brawlers = [4, 5, 6, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26]
        
        selected_brawler = random.choice(all_brawlers)
        cost = get_cost_for_brawler(selected_brawler, random_data)
        old_cost = get_oldcost_for_brawler(selected_brawler, random_data)
        
        if cost is None:
            cost = 40
        if old_cost is None:
            old_cost = 50
        
        special_offer['BrawlerID'] = [selected_brawler, 0, 0]
        special_offer['Cost'] = cost
        special_offer['OldCost'] = old_cost
    
    elif base_offer['ID'][0] == 4:
        # Для скина
        all_skins = [29, 52, 97, 98, 2, 69, 95, 96, 25, 64, 103, 104, 5, 58, 72, 91, 26, 68, 105, 106, 11, 101, 102, 27, 59, 90, 92, 44, 47, 15, 60, 79, 56, 57, 113, 114, 28, 30, 50, 63, 75, 20, 49, 71, 107, 108, 99, 100, 94, 70, 61, 88, 45, 111, 112, 117, 109, 110, 93, 115, 116]
        
        selected_skin = random.choice(all_skins)
        cost = get_cost_for_skin(selected_skin, random_data)
        old_cost = get_oldcost_for_skin(selected_skin, random_data)
        
        if cost is None:
            cost = 40
        if old_cost is None:
            old_cost = 50
        
        special_offer['SkinID'] = [selected_skin, 0, 0]
        special_offer['Cost'] = cost
        special_offer['OldCost'] = old_cost
    
    return special_offer

def generate_premium_offer(random_data):
    base_offer = random.choice(random_data['offers']['7'])
    
    # Фиксированный список ID бойцов
    brawler_ids = [4, 5, 6, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26]
    
    selected_brawler = random.choice(brawler_ids)
    
    special_offer = base_offer.copy()
    special_offer['BrawlerID'] = [selected_brawler, 0, 0]
    
    return special_offer

def get_all_possible_offers(random_data):
    all_offers = []
    
    for category_id, offers_list in random_data['offers'].items():
        if category_id == '1':
            continue
            
        all_offers.extend(offers_list)
    
    return all_offers

def generate_daily_offers():
    random_data = load_or_create_random_json()
    offers_data = random_data.get('offers', {})
    
    num_offers = random.randint(MIN_OFFERS, MAX_OFFERS)
    
    selected_categories = [str(i) for i in range(min(num_offers, 8))]
    
    if selected_categories and random.random() < 0.1:
        selected_categories[-1] = '6'
    
    result = {}
    used_titles = set()
    
    for i, category in enumerate(selected_categories):
        if category == '6':
            selected_offer = generate_special_offer(random_data)
        elif category == '7':
            selected_offer = generate_premium_offer(random_data)
        else:
            possible_offers = offers_data.get(category, [])
            
            if not possible_offers:
                continue
                
            if random.random() < 0.3:
                special_types = []
                if any(offer['ID'][0] == 5 for offer in possible_offers):
                    special_types.append('starpower')
                if any(offer['ID'][0] == 3 for offer in possible_offers):
                    special_types.append('brawler')
                if any(offer['ID'][0] == 4 for offer in possible_offers):
                    special_types.append('skin')
                
                if special_types:
                    selected_type = random.choice(special_types)
                    if selected_type == 'starpower':
                        selected_offer = generate_starpower_offer(random_data)
                    elif selected_type == 'brawler':
                        selected_offer = generate_brawler_offer(random_data)
                    elif selected_type == 'skin':
                        selected_offer = generate_skin_offer(random_data)
                else:
                    filtered_offers = [offer for offer in possible_offers if offer['OfferTitle'] not in used_titles]
                    selected_offer = random.choice(filtered_offers) if filtered_offers else random.choice(possible_offers)
            else:
                filtered_offers = [offer for offer in possible_offers if offer['OfferTitle'] not in used_titles]
                selected_offer = random.choice(filtered_offers) if filtered_offers else random.choice(possible_offers)
        
        if selected_offer['ID'][0] == 3 and selected_offer['BrawlerID'][0] == 0:
            selected_offer = generate_brawler_offer(random_data)
        elif selected_offer['ID'][0] == 4 and selected_offer['SkinID'][0] == 0:
            selected_offer = generate_skin_offer(random_data)
        elif selected_offer['ID'][0] == 5 and selected_offer['BrawlerID'][0] == 0:
            selected_offer = generate_starpower_offer(random_data)
        
        used_titles.add(selected_offer['OfferTitle'])
        result[str(i)] = selected_offer
    
    if num_offers > 8:
        additional_offers_count = num_offers - 8
        all_possible_offers = get_all_possible_offers(random_data)
        
        for i in range(additional_offers_count):
            offer_index = 8 + i
            
            available_offers = [offer for offer in all_possible_offers if offer['OfferTitle'] not in used_titles]
            
            if available_offers:
                selected_offer = random.choice(available_offers).copy()
            else:
                selected_offer = random.choice(all_possible_offers).copy()
            
            if selected_offer['ID'][0] == 3 and selected_offer['BrawlerID'][0] == 0:
                selected_offer = generate_brawler_offer(random_data)
            elif selected_offer['ID'][0] == 4 and selected_offer['SkinID'][0] == 0:
                selected_offer = generate_skin_offer(random_data)
            elif selected_offer['ID'][0] == 5 and selected_offer['BrawlerID'][0] == 0:
                selected_offer = generate_starpower_offer(random_data)
            
            used_titles.add(selected_offer['OfferTitle'])
            result[str(offer_index)] = selected_offer
    
    return result

def save_offers(offers):
    with open(OFFERS_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(offers, f, ensure_ascii=False)

def main():
    offers = generate_daily_offers()
    save_offers(offers)
    print(f"Сгенерировано {len(offers)} акций:\n")
    for i, offer in offers.items():
        brawler_info = f" (Боец: {offer['BrawlerID'][0]})" if offer['BrawlerID'][0] > 0 else ""
        skin_info = f" (Скин: {offer['SkinID'][0]})" if offer['SkinID'][0] > 0 else ""
        print(f"Акция {i}: {offer['OfferTitle']} (Стоимость: {offer['Cost']}){brawler_info}{skin_info}")
    print("\nПредложения магазина успешно обновлены!")

if __name__ == "__main__":
    main()