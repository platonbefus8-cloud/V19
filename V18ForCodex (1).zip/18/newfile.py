import sqlite3
import json
from collections import OrderedDict

def reset_all_players_club_data():
    """
    Устанавливает clubID и clubRole в 0 для всех игроков в базе данных
    """
    try:
        # Подключаемся к базе данных игроков
        conn = sqlite3.connect('Database/Player/data.db')
        cursor = conn.cursor()
        
        # Проверяем существование таблицы
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='players'")
        if not cursor.fetchone():
            print("[ОШИБКА] Таблица players не существует!")
            conn.close()
            return
        
        # Получаем всех игроков
        cursor.execute("SELECT token, info FROM players")
        players = cursor.fetchall()
        
        updated_count = 0
        
        for token, info_json in players:
            try:
                # Загружаем данные игрока
                player_data = json.loads(info_json, object_pairs_hook=OrderedDict)
                
                # Устанавливаем clubID и clubRole в 0
                player_data['clubID'] = 0
                player_data['clubRole'] = 0
                
                # Обновляем запись в базе данных
                cursor.execute("UPDATE players SET info=? WHERE token=?", 
                             (json.dumps(player_data), token))
                
                updated_count += 1
                print(f"[УСПЕХ] Обновлен игрок {token}: clubID=0, clubRole=0")
                
            except Exception as e:
                print(f"[ОШИБКА] Ошибка при обработке игрока {token}: {e}")
                continue
        
        # Применяем изменения
        conn.commit()
        conn.close()
        
        print(f"\n[РЕЗУЛЬТАТ] Успешно обновлено {updated_count} игроков")
        
    except Exception as e:
        print(f"[ОШИБКА] Критическая ошибка: {e}")

def validate_reset():
    """
    Проверяет, что все игроки имеют clubID=0 и clubRole=0
    """
    try:
        conn = sqlite3.connect('Database/Player/data.db')
        cursor = conn.cursor()
        
        cursor.execute("SELECT token, info FROM players")
        players = cursor.fetchall()
        
        players_with_club = 0
        total_players = 0
        
        for token, info_json in players:
            try:
                player_data = json.loads(info_json, object_pairs_hook=OrderedDict)
                total_players += 1
                
                if player_data.get('clubID', 0) != 0 or player_data.get('clubRole', 0) != 0:
                    players_with_club += 1
                    print(f"[ПРОВЕРКА] Игрок {token} все еще в клубе: clubID={player_data.get('clubID')}, clubRole={player_data.get('clubRole')}")
                    
            except Exception as e:
                print(f"[ОШИБКА] Ошибка при проверке игрока {token}: {e}")
                continue
        
        conn.close()
        
        print(f"\n[ПРОВЕРКА ЗАВЕРШЕНА]")
        print(f"Всего игроков: {total_players}")
        print(f"Игроков в клубах: {players_with_club}")
        print(f"Игроков без клуба: {total_players - players_with_club}")
        
    except Exception as e:
        print(f"[ОШИБКА] Ошибка при проверке: {e}")

if __name__ == "__main__":
    print("=== СБРОС ДАННЫХ КЛУБОВ ДЛЯ ВСЕХ ИГРОКОВ ===")
    
    # Запрашиваем подтверждение
    confirmation = input("Вы уверены, что хотите установить clubID=0 и clubRole=0 для ВСЕХ игроков? (y/N): ")
    
    if confirmation.lower() in ['y', 'yes', 'д', 'да']:
        print("\nЗапуск сброса...")
        reset_all_players_club_data()
        
        print("\nПроверка результатов...")
        validate_reset()
    else:
        print("Операция отменена.")