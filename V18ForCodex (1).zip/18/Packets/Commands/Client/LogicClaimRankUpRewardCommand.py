from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicBrawlerDataCommand import LogicBrawlerDataCommand
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.Commands.Server.ShopResponse import ShopResponse
from Packets.Commands.Server.LogicTicketsDataCommand import LogicTicketsDataCommand

from Utils.Reader import BSMessageReader

class LogicClaimRankUpRewardCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.brawlerID = self.read_Vint()

    def process(self):
        # Создаем экземпляр DatabaseManager
        db = DataBase(self.player)
        
        # Маленькие ящики (box_id = 0)
        if self.player.trophy_road in [1, 3, 5, 11, 14, 20, 27, 33, 37, 40, 42, 49, 52, 62, 67, 77, 87, 92, 107]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            self.player.box_id = 0
            LogicBoxDataCommand(self.client, self.player, 1, 1).send()
        
        # Большие ящики (box_id = 1)
        elif self.player.trophy_road in [18, 31, 58, 73, 98]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            self.player.box_id = 1
            LogicBoxDataCommand(self.client, self.player, 1, 1).send()
        
        # Мегаящики (box_id = 3)
        elif self.player.trophy_road in [55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 105, 110]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            self.player.box_id = 3
            LogicBoxDataCommand(self.client, self.player, 1, 1).send()
        
        # 50 монет
        elif self.player.trophy_road in [16, 19, 23, 26, 29, 32, 36, 39, 46, 50, 57, 66, 71, 81]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            count = 50
            ShopResponse(self.client, self.player, 1, {"id": 7}, count).send()
            self.player.gold += count
            db.replaceValue('gold', self.player.gold)
        
        # 150 монет
        elif self.player.trophy_road in [41, 63, 78, 83, 86, 88, 91, 96, 98, 101, 103, 106, 108]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            count = 150
            ShopResponse(self.client, self.player, 1, {"id": 7}, count).send()
            self.player.gold += count
            db.replaceValue('gold', self.player.gold)
        
        # 300 монет
        elif self.player.trophy_road in [48]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            count = 300
            ShopResponse(self.client, self.player, 1, {"id": 7}, count).send()
            self.player.gold += count
            db.replaceValue('gold', self.player.gold)
                
        # 5 билетов
        elif self.player.trophy_road in [24, 34, 44, 54, 59, 64, 69, 74, 79, 84, 89, 94, 99, 104, 109]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            count = 5
            LogicTicketsDataCommand(self.client, self.player, count).send()
            self.player.tickets += count
            db.replaceValue("tickets", self.player.tickets)
        
        # 25 очков сил 
        elif self.player.trophy_road in [9, 13, 17, 22, 30, 43, 47, 53, 56, 61, 72, 76, 82, 97, 102]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            count = 25
            ShopResponse(self.client, self.player, 1, {"id": 6, "scid": self.brawlerID}, count).send()
            self.player.brawlers_upgradium[str(self.brawlerID)] += count
            db.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
        
        # 75 очков сил
        elif self.player.trophy_road in [28, 68, 93]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            count = 75
            ShopResponse(self.client, self.player, 1, {"id": 6, "scid": self.brawlerID}, count).send()
            self.player.brawlers_upgradium[str(self.brawlerID)] += count
            db.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
        
        # 150 очков сил
        elif self.player.trophy_road in [38]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            count = 150
            ShopResponse(self.client, self.player, 1, {"id": 6, "scid": self.brawlerID}, count).send()
            self.player.brawlers_upgradium[str(self.brawlerID)] += count
            db.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)        
        
        # 200 удвоителей жетонов
        elif self.player.trophy_road == 7:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            ShopResponse(self.client, self.player, 1, {"id": 2}, 200).send()
            self.player.tokensdoubler += 200
            db.replaceValue('tokensdoubler', self.player.tokensdoubler)
            
        # 600 удвоителей жетонов
        elif self.player.trophy_road == 51:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            ShopResponse(self.client, self.player, 1, {"id": 2}, 600).send()
            self.player.tokensdoubler += 600
            db.replaceValue('tokensdoubler', self.player.tokensdoubler)
        
        # Бойцы с проверкой наличия
        elif self.player.trophy_road == 2:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            if self.player.BrawlersUnlockedState[str(8)] == 0:
                LogicBrawlerDataCommand(self.client, self.player, 8, 1).send() # НИТА
            else:
                self.player.box_id = 0
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
                
        elif self.player.trophy_road == 6:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            if self.player.BrawlersUnlockedState[str(1)] == 0:
                LogicBrawlerDataCommand(self.client, self.player, 1, 1).send() # КОЛЬТ
            else:
                self.player.box_id = 0
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
                
        elif self.player.trophy_road == 10:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            if self.player.BrawlersUnlockedState[str(2)] == 0:
                LogicBrawlerDataCommand(self.client, self.player, 2, 1).send() # БУЛЛ
            else:
                self.player.box_id = 0
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
                
        elif self.player.trophy_road == 15:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            if self.player.BrawlersUnlockedState[str(7)] == 0:
                LogicBrawlerDataCommand(self.client, self.player, 7, 1).send() # ДЖЕССИ
            else:
                self.player.box_id = 0
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
                
        elif self.player.trophy_road == 25:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            if self.player.BrawlersUnlockedState[str(3)] == 0:
                LogicBrawlerDataCommand(self.client, self.player, 3, 1).send() # БРОК
            else:
                self.player.box_id = 0
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
                
        elif self.player.trophy_road == 35:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            if self.player.BrawlersUnlockedState[str(9)] == 0:
                LogicBrawlerDataCommand(self.client, self.player, 9, 1).send() # ДИНОМАЙК
            else:
                self.player.box_id = 0
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
                
        elif self.player.trophy_road == 45:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
            if self.player.BrawlersUnlockedState[str(14)] == 0:
                LogicBrawlerDataCommand(self.client, self.player, 14, 1).send() # БО
            else:
                self.player.box_id = 0
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
                
        elif self.player.trophy_road in [4, 8, 12, 21]:
            db.replaceValue("leagueReward", self.player.trophy_road + 1)
            db.loadAccount()
        
        else:
            info_trophy_road = self.player.trophy_road         
            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, f"Данная награда временно не доступна.\n\nID награды: {info_trophy_road}").send()