from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicBuyItem import LogicBuyItem
from Packets.Commands.Server.ShopResponse import ShopResponse
from Database.DatabaseManager import DataBase
from Logic.Shop import Shop

from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Gameroom.DoNotDistrubOkMessage import DoNotDistrubOkMessage
from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage

import random
import time
import re
import os
import json
from Utils.Reader import BSMessageReader

class LogicPurchaseOfferCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.offer_index = self.read_Vint()
        self.read_Vint()
        self.brawlerID = self.read_Vint()

    def process(self):
        shop_instance = Shop()
        shop_instance.player = self.player
        shop_instance.loadOffers()
        offers = shop_instance.offers
        
        if self.offer_index >= len(offers):
            return
            
        offer = offers[self.offer_index]
        
        id1 = offer['ID'][0]
        id2 = offer['ID'][1]
        id3 = offer['ID'][2]
        multi1 = offer['Multiplier'][0]
        multi2 = offer['Multiplier'][1]
        multi3 = offer['Multiplier'][2]
        skin1 = offer['SkinID'][0]
        skin2 = offer['SkinID'][1]
        skin3 = offer['SkinID'][2]
        brawler1 = offer['BrawlerID'][0]
        brawler2 = offer['BrawlerID'][1]
        brawler3 = offer['BrawlerID'][2]
        count1 = offer['Multiplier'][0]
        count2 = offer['Multiplier'][1]
        count3 = offer['Multiplier'][2]
        donat = offer.get('ShopDonat', 0)
        infoid = offer.get('WhoBuyed', [])
        brawlerID = self.brawlerID

        ID1 = 0
        ID2 = 0
        ID3 = 0

        db_instance = DataBase(self.player)

        shop_type = offer.get('ShopType', 0)
        cost = offer.get('Cost', 0)
        
        if shop_type == 0 and self.player.low_id not in infoid:  # Гемы
            if self.player.vip > 0:
                cost = int(cost * 0.9)
            self.player.gems -= cost
            db_instance.replaceValue('gems', self.player.gems)
            
        elif shop_type == 1 and self.player.low_id not in infoid:  # Золото
            if self.player.vip > 0:
                cost = int(cost * 0.9)
            self.player.gold -= cost
            db_instance.replaceValue('gold', self.player.gold)
            
        elif shop_type == 3 and self.player.low_id not in infoid:  # Звездные очки
            if self.player.vip > 0 and donat == 1:
                self.player.star_points = self.player.star_points + 1
            else:
                self.player.star_points = self.player.star_points - cost
            db_instance.replaceValue('starpoints', self.player.star_points)

        # Обработка билетов с префиксами и Starr Drops
        if id1 == 7:
            if skin1 == 1 or skin1 == 2 and self.player.low_id not in infoid:
                try:
                    with open(os.path.join('JSON', 'titles.json'), 'r', encoding='utf-8') as file:
                        titles_data = json.load(file)
                        title_options = [title['gradient'] for title in titles_data['titles']]
                except Exception as e:
                    self.player.err_code = 1
                    LoginFailedMessage(self.client, self.player, f"Ошибка при чтении titles.json: {e}").send()
                    title_options = ["ОТСУТСТВУЕТ"]
                
                random_title = random.choice(title_options)
                self.player.title = random_title
                DataBase.replaceValue(self, 'title', self.player.title)
                clean_title = re.sub('<.*?>', '', random_title)
                self.player.err_code = 1
                LoginFailedMessage(self.client, self.player, f"ПРЕФИКС «{clean_title}» РАЗБЛОКИРОВАН!").send()
                if skin1 == 1:
                    shop_instance.UpdateOfferData(self.offer_index)
                else:
                    return
                    
            
            elif skin1 == 3 and self.player.low_id not in infoid:  # Starr Drops
                Chances = {
                    "gold": 38,
                    "brawlersUpgradePoints": 26,
                    "tokensdoubler": 15,
                    "tickets": 7,
                    "StarPower": 5,
                    "gems": 4,
                    "skin": 3,
                    "brawler": 2
                }
                
                random_chance = random.randint(1, 100)
                reward = None
                
                if random_chance <= Chances["gold"]:
                    reward = "gold"
                elif random_chance <= Chances["gold"] + Chances["brawlersUpgradePoints"]:
                    reward = "brawlersUpgradePoints"
                elif random_chance <= Chances["gold"] + Chances["brawlersUpgradePoints"] + Chances["tokensdoubler"]:
                    reward = "tokensdoubler"
                elif random_chance <= Chances["gold"] + Chances["brawlersUpgradePoints"] + Chances["tokensdoubler"] + Chances["tickets"]:
                    reward = "tickets"
                elif random_chance <= Chances["gold"] + Chances["brawlersUpgradePoints"] + Chances["tokensdoubler"] + Chances["tickets"] + Chances["StarPower"]:
                    reward = "StarPower"
                elif random_chance <= Chances["gold"] + Chances["brawlersUpgradePoints"] + Chances["tokensdoubler"] + Chances["tickets"] + Chances["StarPower"] + Chances["gems"]:
                    reward = "gems"
                elif random_chance <= Chances["gold"] + Chances["brawlersUpgradePoints"] + Chances["tokensdoubler"] + Chances["tickets"] + Chances["StarPower"] + Chances["gems"] + Chances["skin"]:
                    reward = "skin"
                else:
                    reward = "brawler"
                
                if reward == "gold":
                    multi1 = random.randint(20, 200)
                    self.player.gold += multi1
                    db_instance.replaceValue('gold', self.player.gold)
                    ID1 = 1
                
                elif reward == "brawlersUpgradePoints":
                    valid_brawler_found = False
                    attempts = 0
                    max_attempts = 10
                    
                    while not valid_brawler_found and attempts < max_attempts:
                        multi1 = random.randint(10, 100)
                        brawler1 = random.randint(1, 25)
                        
                        if str(brawler1) in self.player.BrawlersUnlockedState and self.player.BrawlersUnlockedState[str(brawler1)] == 1:
                            if str(brawler1) in self.player.Brawler_level and self.player.Brawler_level[str(brawler1)] not in (8, 9):
                                valid_brawler_found = True
                                self.player.brawlers_upgradium[str(brawler1)] += multi1
                                db_instance.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
                                ID1 = 5
                        attempts += 1
                    
                    if not valid_brawler_found:
                        multi1 = random.randint(20, 200)
                        self.player.gold += multi1
                        db_instance.replaceValue('gold', self.player.gold)
                        ID1 = 1
                
                elif reward == "tokensdoubler":
                    multi1 = random.randint(50, 200)
                    self.player.tokensdoubler += multi1
                    db_instance.replaceValue('tokensdoubler', self.player.tokensdoubler)
                    ID1 = 4
                
                elif reward == "tickets":
                    multi1 = random.randint(1, 5)
                    self.player.tickets += multi1
                    db_instance.replaceValue('tickets', self.player.tickets)
                    ID1 = 3
                    
                elif reward == "StarPower":
                    valid_brawler_found = False
                    attempts = 0
                    max_attempts = 10
                    
                    while not valid_brawler_found and attempts < max_attempts:
                        brawler1 = random.randint(1, 25)
                        
                        if str(brawler1) in self.player.BrawlersUnlockedState and self.player.BrawlersUnlockedState[str(brawler1)] == 1:
                            if str(brawler1) in self.player.Brawler_level and self.player.Brawler_level[str(brawler1)] == 8:
                                valid_brawler_found = True
                                self.player.Brawler_starPower[str(brawler1)] = 1
                                self.player.Brawler_level[str(brawler1)] = 9
                                db_instance.replaceValue('brawlerStarPower', self.player.Brawler_starPower)
                                db_instance.replaceValue('brawlerPowerLevel', self.player.Brawler_level)
                                ID1 = 8
                        attempts += 1
                    
                    if not valid_brawler_found:
                        multi1 = random.randint(500, 2000)
                        self.player.gold += multi1
                        db_instance.replaceValue('gold', self.player.gold)
                        ID1 = 1
                
                elif reward == "gems":
                    multi1 = random.randint(1, 10)
                    self.player.gems += multi1
                    db_instance.replaceValue('gems', self.player.gems)
                    ID1 = 2
                
                elif reward == "skin":
                    rareskins = [15, 27, 29, 103] # 50%
                    superrareskins = [5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93] # 30%
                    epicskins = [26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91] # 15%
                    legendaryskins = [49] # 5%
                    
                    skin_found = False
                    attempts = 0
                    max_attempts = 10
                    
                    while not skin_found and attempts < max_attempts:
                        skin_chance = random.randint(1, 100)
                        
                        if skin_chance <= 50:
                            skin_pool = rareskins
                        elif skin_chance <= 80:
                            skin_pool = superrareskins
                        elif skin_chance <= 95:
                            skin_pool = epicskins
                        else:
                            skin_pool = legendaryskins
                        
                        if skin_pool:
                            skin1 = random.choice(skin_pool)
                            if skin1 not in self.player.UnlockedSkins:
                                skin_found = True
                                self.player.UnlockedSkins.append(skin1)
                                db_instance.replaceValue('UnlockedSkins', self.player.UnlockedSkins)
                                ID1 = 7
                        attempts += 1
                    
                    if not skin_found:
                        multi1 = random.randint(10, 30)
                        self.player.gems += multi1
                        db_instance.replaceValue('gems', self.player.gems)
                        ID1 = 2
                
                elif reward == "brawler":
                    rarebrawlers = [6, 10, 13, 24] # 50%
                    superrarebrawlers = [4, 18, 19, 25] # 20%
                    epicbrawlers = [15, 16, 20] # 15%
                    mythicbrawlers = [11, 17, 21] # 10% 
                    legendarybrawlers = [5, 12, 23] # 5%
                    
                    brawler_found = False
                    attempts = 0
                    max_attempts = 10
                    
                    while not brawler_found and attempts < max_attempts:
                        brawler_chance = random.randint(1, 100)
                        
                        if brawler_chance <= 50:
                            brawler_pool = rarebrawlers
                        elif brawler_chance <= 70:
                            brawler_pool = superrarebrawlers
                        elif brawler_chance <= 85:
                            brawler_pool = epicbrawlers
                        elif brawler_chance <= 95:
                            brawler_pool = mythicbrawlers
                        else:
                            brawler_pool = legendarybrawlers
                        
                        if brawler_pool:
                            brawler1 = random.choice(brawler_pool)
                            if str(brawler1) not in self.player.BrawlersUnlockedState or self.player.BrawlersUnlockedState[str(brawler1)] != 1:
                                brawler_found = True
                                self.player.BrawlersUnlockedState[str(brawler1)] = 1
                                db_instance.replaceValue('UnlockedBrawlers', self.player.BrawlersUnlockedState)
                                ID1 = 6
                        attempts += 1
                    
                    if not brawler_found:
                        multi1 = random.randint(10, 30)
                        self.player.gems += multi1
                        db_instance.replaceValue('gems', self.player.gems)
                        ID1 = 2
                
            else:
                # Обычные билеты
                self.player.tickets = self.player.tickets + multi1
                db_instance.replaceValue('tickets', self.player.tickets)
                ID1 = 3            

        if id1 == 1 and self.player.low_id not in infoid:
            self.player.gold = self.player.gold + multi1
            db_instance.replaceValue('gold', self.player.gold)
            ID1 = 1
        if id2 == 1 and self.player.low_id not in infoid:
            self.player.gold = self.player.gold + multi2
            db_instance.replaceValue('gold', self.player.gold)
            ID2 = 1             
        if id3 == 1 and self.player.low_id not in infoid:
            self.player.gold = self.player.gold + multi3
            db_instance.replaceValue('gold', self.player.gold)
            ID3 = 1
            
        if id1 == 16 and self.player.low_id not in infoid:
            self.player.gems = self.player.gems + multi1
            db_instance.replaceValue('gems', self.player.gems)
            ID1 = 2
        if id2 == 16 and self.player.low_id not in infoid:
            self.player.gems = self.player.gems + multi2
            db_instance.replaceValue('gems', self.player.gems)
            ID2 = 2            
        if id3 == 16 and self.player.low_id not in infoid:
            self.player.gems = self.player.gems + multi3
            db_instance.replaceValue('gems', self.player.gems)
            ID3 = 2
                
        if id2 == 7 and self.player.low_id not in infoid:
            self.player.tickets = self.player.tickets + multi2
            db_instance.replaceValue('tickets', self.player.tickets)
            ID2 = 3            
        if id3 == 7 and self.player.low_id not in infoid:
            self.player.tickets = self.player.tickets + multi3
            db_instance.replaceValue('tickets', self.player.tickets)
            ID3 = 3
            
        if id1 == 9 and self.player.low_id not in infoid:
            self.player.tokensdoubler = self.player.tokensdoubler + multi1
            db_instance.replaceValue('tokensdoubler', self.player.tokensdoubler)
            ID1 = 4
        if id2 == 9 and self.player.low_id not in infoid:
            self.player.tokensdoubler = self.player.tokensdoubler + multi2
            db_instance.replaceValue('tokensdoubler', self.player.tokensdoubler)
            ID2 = 4            
        if id3 == 9 and self.player.low_id not in infoid:
            self.player.tokensdoubler = self.player.tokensdoubler + multi3
            db_instance.replaceValue('tokensdoubler', self.player.tokensdoubler)
            ID3 = 4
            
        if id1 == 8 and self.player.low_id not in infoid:
            self.player.brawlers_upgradium[str(brawler1)] += multi1
            db_instance.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
            ID1 = 5
        if id2 == 8 and self.player.low_id not in infoid:
            self.player.brawlers_upgradium[str(brawler2)] += multi2
            db_instance.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
            ID2 = 5            
        if id3 == 8 and self.player.low_id not in infoid:
            self.player.brawlers_upgradium[str(brawler3)] += multi3
            db_instance.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
            ID3 = 5

        if id1 == 12 and self.player.low_id not in infoid:
            self.player.brawlers_upgradium[str(brawlerID)] += multi1
            db_instance.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
            ID1 = 9
        if id2 == 12 and self.player.low_id not in infoid:
            self.player.brawlers_upgradium[str(brawlerID)] += multi2
            db_instance.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
            ID2 = 9
        if id3 == 12 and self.player.low_id not in infoid:
            self.player.brawlers_upgradium[str(brawlerID)] += multi3
            db_instance.replaceValue('brawlersUpgradePoints', self.player.brawlers_upgradium)
            ID3 = 9          
                                                
        if id1 == 5 and self.player.low_id not in infoid:
            self.player.Brawler_starPower[str(brawler1)] = multi1
            self.player.Brawler_level[str(brawler1)] = 9
            db_instance.replaceValue('brawlerStarPower', self.player.Brawler_starPower)
            db_instance.replaceValue('brawlerPowerLevel', self.player.Brawler_level)
            ID1 = 8

        if id1 == 3 and self.player.low_id not in infoid:
            self.player.BrawlersUnlockedState[str(brawler1)] = 1
            db_instance.replaceValue('UnlockedBrawlers', self.player.BrawlersUnlockedState)
            ID1 = 6
        if id2 == 3 and self.player.low_id not in infoid:
            self.player.BrawlersUnlockedState[str(brawler2)] = 1
            db_instance.replaceValue('UnlockedBrawlers', self.player.BrawlersUnlockedState)
            ID2 = 6            
        if id3 == 3 and self.player.low_id not in infoid:
            self.player.BrawlersUnlockedState[str(brawler3)] = 1
            db_instance.replaceValue('UnlockedBrawlers', self.player.BrawlersUnlockedState)
            ID3 = 6
            
        if id1 == 4 and self.player.low_id not in infoid:
            self.player.UnlockedSkins.append(skin1)
            db_instance.replaceValue('UnlockedSkins', self.player.UnlockedSkins)
            ID1 = 7
        if id2 == 4 and self.player.low_id not in infoid:
            self.player.UnlockedSkins.append(skin2)
            db_instance.replaceValue('UnlockedSkins', self.player.UnlockedSkins)
            ID2 = 7            
        if id3 == 4 and self.player.low_id not in infoid:
            self.player.UnlockedSkins.append(skin3)
            db_instance.replaceValue('UnlockedSkins', self.player.UnlockedSkins)
            ID3 = 7            

        if id1 in [6, 10, 14] and self.player.low_id not in infoid:
            if id1 == 6:
                self.player.box_id = 5
                LogicBoxDataCommand(self.client, self.player, 0, count1).send()
            if id1 == 10:
                self.player.box_id = 3
                LogicBoxDataCommand(self.client, self.player, 0, count1).send()
            if id1 == 14:
                self.player.box_id = 4
                LogicBoxDataCommand(self.client, self.player, 0, count1).send()
        elif id2 in [6, 10, 14] and self.player.low_id not in infoid:
            if id2 == 6:
                self.player.box_id = 5
                LogicBoxDataCommand(self.client, self.player, 0, count2).send()
                
            if id2 == 10:
                self.player.box_id = 3
                LogicBoxDataCommand(self.client, self.player, 0, count2).send()
                
            if id2 == 14:
                self.player.box_id = 4
                LogicBoxDataCommand(self.client, self.player, 0, count2).send()
                
        elif id3 in [6, 10, 14] and self.player.low_id not in infoid:
            if id3 == 6:
                self.player.box_id = 5
                LogicBoxDataCommand(self.client, self.player, 0, count3).send()
                
            if id3 == 10:
                self.player.box_id = 3
                LogicBoxDataCommand(self.client, self.player, 0, count3).send()
                
            if id3 == 14:
                self.player.box_id = 4
                LogicBoxDataCommand(self.client, self.player, 0, count3).send()                                        
        else:
            if id1 != 0 and id2 != 0 and id3 != 0:
                LogicBuyItem(self.client, self.player, ID1, ID2, ID3, multi1, multi2, multi3, brawler1, brawler2, brawler3, skin1, skin2, skin3, brawlerID).send()
            elif id1 != 0 and id2 != 0:
                LogicBuyItem(self.client, self.player, ID1, ID2, 0, multi1, multi2, 0, brawler1, brawler2, 0, skin1, skin2, 0, brawlerID).send()
            else:
                LogicBuyItem(self.client, self.player, ID1, 0, 0, multi1, 0, 0, brawler1, 0, 0, skin1, 0, 0, brawlerID).send()

        shop_instance.UpdateOfferData(self.offer_index)