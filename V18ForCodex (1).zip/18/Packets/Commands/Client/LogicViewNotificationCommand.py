from Utils.Reader import BSMessageReader
from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicBrawlerDataCommand import LogicBrawlerDataCommand
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.Commands.Server.ShopResponse import ShopResponse
from Packets.Commands.Server.LogicTicketsDataCommand import LogicTicketsDataCommand
from datetime import datetime, timedelta
import json
import os
import random
import re

class LogicViewNotificationCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.a = self.read_Vint()
        self.b = self.read_Vint()
        self.c = self.read_Vint()
        self.d = self.read_Vint()
        self.notif = self.read_Vint()
            
    def process(self):
        try:
            with open('JSON/Notif.json', 'r', encoding='utf-8') as f:
                notif_data = json.load(f)
        except Exception as e:
            print(f"Error reading Notif.json: {e}")
            return
        
        target_notif = None
        target_key = None
        
        for notif_key, notif_info in notif_data.items():
            unique_id = hash(notif_key) % 900000 + 100000
            
            if unique_id == self.notif:
                target_notif = notif_info
                target_key = notif_key
                break
        
        if not target_notif:
            return
        
        notif_id = target_notif.get('NotifID', 0)
        notif_amount = target_notif.get('NotifAmount', 0)
        notif_brawler_id = target_notif.get('NotifBrawlerID', 0)
        notif_skin_id = target_notif.get('NotifSkinID', 0)
        notif_type = target_notif.get('NotifType', 1)
        notif_info_list = target_notif.get('NotifInfo', [])
                        
        print(f"--------------------\nОбрабатываем нотиф:\nKey: {target_key};\nNotifID: {notif_id};\nAmount: {notif_amount};\nBrawlerID: {notif_brawler_id};\nSkinID: {notif_skin_id};\nType: {notif_type}\n--------------------")
        
        if notif_type == 0:  # Для всех
            if self.player.low_id not in notif_info_list:
                if notif_id > 0:
                	notif_info_list.append(self.player.low_id)
                	target_notif['NotifInfo'] = notif_info_list
                print(f"Игрок {self.player.low_id} забрал {target_key}")
        elif notif_type == 1:  # Для особенных
            if self.player.low_id in notif_info_list:
                notif_info_list.remove(self.player.low_id)
                target_notif['NotifInfo'] = notif_info_list
                print(f"Игрок {self.player.low_id} забрал {target_key}")
        
        try:
            with open('JSON/Notif.json', 'w', encoding='utf-8') as f:
                json.dump(notif_data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"Error updating Notif.json: {e}")
        
        # Нотифы
        if notif_id == 0: # Сброс сезона       
        	ShopResponse(self.client, self.player, 0, {"id": 8}, self.player.sbroscost).send()
        	self.player.gems = self.player.gems + self.player.sbroscost
        	DataBase.replaceValue(self, 'gems', self.player.gems)
        	
        	self.player.sbros = 0
        	self.player.sbroscost = 0
        	self.player.sbrosinfo = 0
        	DataBase.replaceValue(self, 'sbros', self.player.sbros)
        	DataBase.replaceValue(self, 'sbroscost', self.player.sbroscost)
        	DataBase.replaceValue(self, 'sbrosinfo', self.player.sbrosinfo)
        	
        if notif_id == 1:  # Монеты
            ShopResponse(self.client, self.player, 0, {"id": 7}, notif_amount).send()
            self.player.gold = self.player.gold + notif_amount
            DataBase.replaceValue(self, 'gold', self.player.gold)
            
        elif notif_id == 2:  # Гемы
            ShopResponse(self.client, self.player, 0, {"id": 8}, notif_amount).send()
            self.player.gems = self.player.gems + notif_amount
            DataBase.replaceValue(self, 'gems', self.player.gems)
            
        elif notif_id == 3:  # Билеты
            LogicTicketsDataCommand(self.client, self.player, notif_amount).send()
            self.player.tickets = self.player.tickets + notif_amount
            DataBase.replaceValue(self, "tickets", self.player.tickets)
            
        elif notif_id == 4:  # Удвоители
            ShopResponse(self.client, self.player, 1, {"id": 2}, notif_amount).send()
            self.player.tokensdoubler = self.player.tokensdoubler + notif_amount
            DataBase.replaceValue(self, 'tokensdoubler', self.player.tokensdoubler)
            
        elif notif_id == 5:  # Скин
            LogicSkinDataCommand(self.client, self.player, notif_skin_id).send()
            if not hasattr(self.player, 'UnlockedSkins'):
                self.player.UnlockedSkins = []
            self.player.UnlockedSkins.append(notif_skin_id)
            DataBase.replaceValue(self, 'UnlockedSkins', self.player.UnlockedSkins)
            
        elif notif_id == 6: # Боец
            LogicBrawlerDataCommand(self.client, self.player, notif_brawler_id, 0).send()
            
        elif notif_id == 7:  # Маленький ящик
            self.player.box_id = 5
            LogicBoxDataCommand(self.client, self.player, 0, notif_amount).send()
            
        elif notif_id == 8:  # Большой ящик
            self.player.box_id = 4
            LogicBoxDataCommand(self.client, self.player, 0, notif_amount).send()
            
        elif notif_id == 9:  # Мегаящик
            self.player.box_id = 3
            LogicBoxDataCommand(self.client, self.player, 0, notif_amount).send()
            
        elif notif_id == 10:
            try:
                with open(os.path.join('JSON', 'titles.json'), 'r', encoding='utf-8') as file:
                    titles_data = json.load(file)
                    title_options = [title['gradient'] for title in titles_data['titles']]
            except Exception as e:
                self.player.err_code = 1
                LoginFailedMessage(self.client, self.player, f"Ошибка при чтении titles.json: {e}").send()
                title_options = ["ОТСУТСТВУЕТ"]
            
            random_title = random.choice(title_options)
            self.player.title = random_title
            DataBase.replaceValue(self, 'title', self.player.title)
            clean_title = re.sub('<.*?>', '', random_title)
            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, f"ПРЕФИКС «{clean_title}» РАЗБЛОКИРОВАН!").send()
        
        elif notif_id == 12:
            
            self.player.admin = 1
            DataBase.replaceValue(self, 'admin', self.player.admin)
            
            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, f"ВЫ ПОЛУЧИЛИ ПРАВА АДМИНИСТРАТОРА СЕРВЕРА!").send()
            	
            
        elif notif_id == 11:  # VIP-Статус
            current_date = datetime.now()
            multiplier = notif_amount
            if self.player.vip == 0:
                vip_end_date = (current_date + timedelta(days=multiplier)).strftime("%d.%m.%Y")
                DataBase.replaceValue(self, 'vip', 1)
                DataBase.replaceValue(self, 'viptime', vip_end_date)
            elif self.player.vip == 1:
                try:
                    vip_end_date = datetime.strptime(self.player.viptime, "%d.%m.%Y")
                    new_end_date = vip_end_date + timedelta(days=multiplier)
                    vip_end_date = new_end_date.strftime("%d.%m.%Y")
                    DataBase.replaceValue(self, 'viptime', vip_end_date)
                except:
                    vip_end_date = (current_date + timedelta(days=multiplier)).strftime("%d.%m.%Y")
                    DataBase.replaceValue(self, 'viptime', vip_end_date)
               
            self.player.vip = 1
            self.player.viptime = vip_end_date
            
            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, f"ВЫ ПОЛУЧИЛИ {multiplier} ДНЕЙ VIP-СТАТУСА! ДЕЙСТВУЕТ ДО {vip_end_date}").send()
            	