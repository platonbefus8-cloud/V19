from Database.DatabaseManager import DataBase
from Logic.Shop import Shop
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage

from Utils.Reader import BSMessageReader

class LogicPurchaseDoubleCoinsCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass


    def process(self):
        cost = 50
        value = 1000

        newGems = self.player.gems - cost
        self.player.gems = newGems
        DataBase.replaceValue(self, 'gems', newGems)

        newTokens = self.player.tokensdoubler + value
        self.player.tokensdoubler = newTokens
        DataBase.replaceValue(self, 'tokensdoubler', newTokens)

