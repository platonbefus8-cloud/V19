from random import *
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Logic.Boxes import Boxes
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class LogicSkinDataCommand(Writer):

    def __init__(self, client, player, ID):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.BoxData = Boxes.boxes
        self.skin = ID

    def encode(self):
        self.writeVint(203) # Command
        self.writeVint(0)
        self.writeVint(1) # Multipler
        self.writeVint(100)
        self.writeVint(1) # Reward Count

        self.writeVint(1) # Value
        self.writeVint(0) # ScId
        self.writeVint(9) # Reward ID
        self.writeScId(29, self.skin) # ScId        

        # Цены за скины
        if self.skin in [15, 27, 29, 94, 117, 118]:
            self.player.gems -= 50
            DataBase.replaceValue(self, "gems", self.player.gems)
            self.player.UnlockedSkins.append(self.skin)
            DataBase.replaceValue(self, "UnlockedSkins", self.player.UnlockedSkins)
        elif self.skin in [5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93]:
            self.player.gems -= 80
            DataBase.replaceValue(self, "gems", self.player.gems)
            self.player.UnlockedSkins.append(self.skin)
            DataBase.replaceValue(self, "UnlockedSkins", self.player.UnlockedSkins)
        elif self.skin in [95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115]:
            self.player.gems -= 100
            DataBase.replaceValue(self, "gems", self.player.gems)
            self.player.UnlockedSkins.append(self.skin)
            DataBase.replaceValue(self, "UnlockedSkins", self.player.UnlockedSkins)
        elif self.skin in [26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91]:
            self.player.gems -= 150
            DataBase.replaceValue(self, "gems", self.player.gems)
            self.player.UnlockedSkins.append(self.skin)
            DataBase.replaceValue(self, "UnlockedSkins", self.player.UnlockedSkins)
        elif self.skin in [96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116]:
            skin_requirements = {
                96: ("ЗОЛОТОЙ КОЛЬТ", "СЕРЕБРЯНЫЙ КОЛЬТ", 95),
                98: ("ЗОЛОТАЯ ШЕЛЛИ", "СЕРЕБРЯНАЯ ШЕЛЛИ", 97),
                100: ("ЗОЛОТОЙ БО", "СЕРЕБРЯНЫЙ БО", 99),
                102: ("ЗОЛОТОЙ СПАЙК", "СЕРЕБРЯНЫЙ СПАЙК", 101),
                104: ("ЗОЛОТОЙ БУЛЛ", "СЕРЕБРЯНЫЙ БУЛЛ", 103),
                106: ("ЗОЛОТОЙ РИКО", "СЕРЕБРЯНЫЙ РИКО", 105),
                108: ("ЗОЛОТОЙ ПОКО", "СЕРЕБРЯНЫЙ ПОКО", 107),
                110: ("ЗОЛОТОЙ ЛЕОН", "СЕРЕБРЯНЫЙ ЛЕОН", 109),
                112: ("ЗОЛОТОЙ ДЖИН", "СЕРЕБРЯНЫЙ ДЖИН", 111),
                114: ("ЗОЛОТОЙ ДИНОМАЙК", "СЕРЕБРЯНЫЙ ДИНОМАЙК", 113),
                116: ("ЗОЛОТОЙ КАРЛ", "СЕРЕБРЯНЫЙ КАРЛ", 115)
            }
            
            skin_name, required_skin_name, required_skin_id = skin_requirements.get(self.skin, ("", "", 0))
            
            if required_skin_id in self.player.UnlockedSkins:
                self.player.gems -= 250
                DataBase.replaceValue(self, "gems", self.player.gems)
                self.player.UnlockedSkins.append(self.skin)
                DataBase.replaceValue(self, "UnlockedSkins", self.player.UnlockedSkins)
            else:
                self.player.err_code = 1
                LoginFailedMessage(self.client, self.player, f"СКИН «{skin_name}» НЕДОСТУПЕН!\n\nТРЕБУЕТСЯ СНАЧАЛА РАЗБЛОКИРОВАТЬ СКИН «{required_skin_name}».").send()
        elif self.skin in [49]:
            self.player.gems -= 300
            DataBase.replaceValue(self, "gems", self.player.gems)
            self.player.UnlockedSkins.append(self.skin)
            DataBase.replaceValue(self, "UnlockedSkins", self.player.UnlockedSkins)

        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(1)
        self.writeVint(0)
        self.writeVint(0)