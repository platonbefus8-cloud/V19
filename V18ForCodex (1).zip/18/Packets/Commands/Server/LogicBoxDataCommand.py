from ast import excepthandler
from random import *
from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicBoxGenerator import Gen

from Utils.Writer import Writer


class LogicBoxDataCommand(Writer):

    def __init__(self, client, player, state, count):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.state = state
        self.count = count  # Количество ящиков

    def encode(self):
        def get_id(id):
            if id == 5:  # Brawl Box         
                return 10
            elif id == 4:  # Big Box
                return 12
            elif id == 3:  # Shop Mega Box
                return 11
            elif id == 1:  # Shop Big Box
                return 12
            elif id == 0:  # Trophy Road Brawl Box
                return 10

        self.box_skin_id = get_id(self.player.box_id)
        
        # Определяем тип ящика на основе box_id
        if self.box_skin_id == 10:  # Обычный ящик
            box_type = 1
        elif self.box_skin_id == 11:  # Мега ящик
            box_type = 10
        elif self.box_skin_id == 12:  # Большой ящик
            box_type = 3
        
        # Используем self.count как количество ящиков
        box_count = self.count if self.count > 0 else 1
        
        # Генерируем награды для каждого ящика отдельно
        all_rewards = []
        total_gold = 0
        total_points = []
        total_brawlers = []
        total_starpower = []
        total_skins = []
        total_bonuses = {
            "gems": 0,
            "doublers": 0,
            "tickets": 0
        }
        
        gen_instance = Gen(self.player)
        
        # Генерируем награды для каждого ящика
        for i in range(box_count):
            rews = gen_instance.GeneratorLoot(box_type, 1)  # Генерируем 1 ящик за раз
            
            # Собираем все награды
            total_gold += rews["Gold"]
            
            for point in rews["Points"]:
                total_points.append(point)
                
            for brawler in rews["brawlers"]:
                total_brawlers.append(brawler)
                
            for starpower in rews["starpower"]:
                total_starpower.append(starpower)
                
            for skin in rews["skins"]:
                total_skins.append(skin)
                
            # Суммируем бонусы
            total_bonuses["gems"] += rews["bonuses"][0]["multiplier"]
            total_bonuses["doublers"] += rews["bonuses"][1]["multiplier"]
            total_bonuses["tickets"] += rews["bonuses"][2]["multiplier"]
            
            # Обновляем данные игрока после каждого ящика
            self.player.gold += rews["Gold"]
            
            for point in rews["Points"]:
                self.player.brawlers_upgradium[str(point["brawler"])] += point["multiplier"]
                
            for brawler in rews["brawlers"]:
                self.player.BrawlersUnlockedState[str(brawler)] = 1
                
            for starpower in rews["starpower"]:
                self.player.Brawler_starPower[str(starpower)] = 1
                self.player.Brawler_level[str(starpower)] = 9
                
            for skin in rews["skins"]:
                if skin not in self.player.UnlockedSkins:
                    self.player.UnlockedSkins.append(skin)
            
            self.player.gems += rews["bonuses"][0]["multiplier"]
            self.player.tokensdoubler += rews["bonuses"][1]["multiplier"]
            self.player.tickets += rews["bonuses"][2]["multiplier"]

        # Сохраняем все изменения в базе данных
        DataBase.replaceValue(self, "gold", self.player.gold)
        DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)
        DataBase.replaceValue(self, 'UnlockedBrawlers', self.player.BrawlersUnlockedState)
        DataBase.replaceValue(self, 'brawlerStarPower', self.player.Brawler_starPower)
        DataBase.replaceValue(self, 'brawlerPowerLevel', self.player.Brawler_level)
        DataBase.replaceValue(self, 'UnlockedSkins', self.player.UnlockedSkins)
        DataBase.replaceValue(self, "gems", self.player.gems)
        DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
        DataBase.replaceValue(self, "tickets", self.player.tickets)

        # Подсчитываем общее количество наград
        total_rewards = 0
        if total_gold > 0:
            total_rewards += 1
        total_rewards += len(total_points)
        total_rewards += len(total_brawlers)
        total_rewards += len(total_starpower)
        total_rewards += len(total_skins)
        if total_bonuses["gems"] > 0:
            total_rewards += 1
        if total_bonuses["doublers"] > 0:
            total_rewards += 1
        if total_bonuses["tickets"] > 0:
            total_rewards += 1

        # Box info
        self.writeVint(203) # CommandID
        self.writeVint(box_count)   # Количество ящиков
        self.writeVint(1)   # Unknown
        self.writeVint(self.box_skin_id)  # BoxID
        # Box info end

        # Reward start
        self.writeVint(total_rewards) # Total reward count
        
        # Gold
        if total_gold > 0:
            self.writeVint(total_gold) # Reward amount
            self.writeVint(0) # CsvID 16
            self.writeVint(7) # Reward ID
            self.writeVint(0) # CsvID 29
            self.writeVint(0) # CsvID 52
            
        # Points
        for point in total_points:
            self.writeVint(int(point["multiplier"])) # Reward amount
            self.writeScId(16, int(point["brawler"])) # CsvID 16
            self.writeVint(6) # Reward ID
            self.writeVint(0) # CsvID 29
            self.writeVint(0) # CsvID 52
            
        # Brawlers
        for brawler in total_brawlers:
            self.writeVint(1) # Reward amount
            self.writeScId(16, int(brawler)) # CsvID 16
            self.writeVint(1) # Reward ID
            self.writeVint(0) # CsvID 29
            self.writeVint(0) # CsvID 52 
            
        # Star Powers
        for starpower in total_starpower:
            self.writeVint(1) # Reward amount
            self.writeScId(16, int(starpower)) # CsvID 16
            self.writeVint(4) # Reward ID
            self.writeVint(0) # CsvID 29
            self.writeVint(0) # CsvID 52
            
        # Skins
        for skin in total_skins:
            self.writeVint(1) # Reward amount
            self.writeVint(0) # CsvID 16
            self.writeVint(9) # Reward ID
            self.writeScId(29, int(skin)) # CsvID 29 (skin ID)
            self.writeVint(0) # CsvID 52
            
        # Gems
        if total_bonuses["gems"] > 0:
            self.writeVint(total_bonuses["gems"]) # Reward amount
            self.writeScId(0, 8) # RewardID
            self.writeVint(0)
            self.writeVint(0)
            
        # Doublers
        if total_bonuses["doublers"] > 0:
            self.writeVint(total_bonuses["doublers"]) # Reward amount
            self.writeScId(0, 2) # RewardID
            self.writeVint(0)
            self.writeVint(0)
            
        # Tickets
        if total_bonuses["tickets"] > 0:
            self.writeVint(total_bonuses["tickets"]) # Reward amount
            self.writeScId(0, 3) # RewardID
            self.writeVint(0)
            self.writeVint(0)
            
        # Box end
        if self.state == 1:
            self.writeVint(self.player.trophy_road)
        else:
            self.writeVint(0)