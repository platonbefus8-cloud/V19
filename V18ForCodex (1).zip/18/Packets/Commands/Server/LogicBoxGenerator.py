from ast import excepthandler
from random import randint, choice
import json

class Gen():
    def __init__(self, player):
        self.player = player
        self.config = self.load_config()
    
    def load_config(self):
        try:
            with open('config.json', 'r') as f:
                return json.load(f)
        except:
            return {"SkinsBox": False, "UniqueSkinsBox": False, "BrawlersBox": True}

    def GeneratorLoot(self, box_type, box_count=1):
        # box_type - тип ящика (1=обычный, 3=большой, 10=мега)
        # box_count - количество ящиков
        
        # Списки бойцов
        commonbrawlers = [0, 1, 2, 3, 7, 8, 9, 14]
        rarebrawlers = [6, 10, 13, 24]
        superrarebrawlers = [4, 18, 19, 25]
        epicbrawlers = [15, 16, 20, 26]
        mythicbrawlers = [11, 17, 21]
        legendarybrawlers = [5, 12, 23]
        
        # Списки скинов
        rareskins = [15, 27, 29, 94, 117]
        superrareskins = [5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93]
        epicskins = [26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91]
        legendaryskins = [49]
        
        # Списки серебряных и золотых скинов
        silverskins = [95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115]
        goldskins = [96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116]
        
        # Списки звёздных сил
        starpowers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26]
        commonbrawlersunlockable = []
        rarebrawlersunlockable = []
        superrarebrawlersunlockable = []
        epicbrawlersunlockable = []
        mythicbrawlersunlockable = []
        legendarybrawlersunlockable = []
        unlocked_brawlers = []
        unlockable_brawlers = []
        unlocked_starpowers = []
        starpower_unlockable = []
        unlockable_skins = []

        # Собираем список бойцов, которые можно разблокировать
        for brawlers_id in self.player.BrawlersUnlockedState:
            if self.player.BrawlersUnlockedState[brawlers_id] != 1:
                brawlers_id = int(brawlers_id)
                if brawlers_id in commonbrawlers:
                    commonbrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in rarebrawlers:
                    rarebrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in superrarebrawlers:
                    superrarebrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in epicbrawlers:
                    epicbrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in mythicbrawlers:
                    mythicbrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in legendarybrawlers:
                    legendarybrawlersunlockable.append(int(brawlers_id))
            else:
                if str(brawlers_id) in self.player.Brawler_level and self.player.Brawler_level[str(brawlers_id)] not in (8, 9):
                    if str(brawlers_id) in self.player.brawlers_upgradium and self.player.brawlers_upgradium[str(brawlers_id)] <= 1500:
                        unlocked_brawlers.append(int(brawlers_id))
        
        # Собираем список скинов, которые можно разблокировать
        for skin_id in rareskins + superrareskins + epicskins + legendaryskins:
        	if skin_id not in self.player.UnlockedSkins:
        		unlockable_skins.append(skin_id)
        if self.config.get("UniqueSkinsBox", True):
        	for skin_id in silverskins:
        	   if skin_id not in self.player.UnlockedSkins:
        	   	unlockable_skins.append(skin_id)
        	for gold_id in goldskins:
        		silver_id = gold_id - 1
        		if silver_id in self.player.UnlockedSkins and gold_id not in self.player.UnlockedSkins:
        			unlockable_skins.append(gold_id)
        
        # Собираем список звёздных сил, которые можно разблокировать
        for brawlers_id in self.player.Brawler_starPower:
            if self.player.Brawler_starPower[brawlers_id] == 0 and self.player.BrawlersUnlockedState[brawlers_id] == 1 and self.player.Brawler_level[brawlers_id] == 8:
                brawlers_id = int(brawlers_id)
                if brawlers_id in starpowers:
                    starpower_unlockable.append(int(brawlers_id))
            else:
                if self.player.Brawler_starPower[brawlers_id] == 1:
                    unlocked_starpowers.append(int(brawlers_id))
        
        # Собираем список скинов, которые можно разблокировать
        for skin_id in rareskins + superrareskins + epicskins + legendaryskins:
            if skin_id not in self.player.UnlockedSkins:
                unlockable_skins.append(skin_id)
        
        rews = {
            "Gold": 0,
            "Points": [],
            "brawlers": [],
            "starpower": [],
            "skins": [],
            "bonuses": [
                {
                    "type": "gems",
                    "multiplier": 0
                },
                {
                    "type": "doublers",
                    "multiplier": 0
                },
                {
                    "type": "tickets",
                    "multiplier": 0
                }
            ],
            "rewards": 0
        }
        cardsi = 0
        
        # Генерация наград для каждого ящика
        total_iterations = box_type * box_count  # Умножаем тип на количество
        
        for i in range(total_iterations):
            randbrawler = randint(1, 10000)
            randstarpower = randint(1, 1000)
            randskin = randint(1, 1000)
            randgold = randint(30, 60)
            randcards = randint(12, 26)
            rews["Gold"] += randgold
            cardsi += randcards
            
            # Генерация бойцов
            if self.config.get("BrawlersBox", True):
                if randbrawler <= 10: # 0.1 шанс
                    if len(legendarybrawlersunlockable) == 0:
                    	pass
                    else:
                    	rand_brawler = choice(legendarybrawlersunlockable)
                    	legendarybrawlersunlockable.remove(rand_brawler)
                    	rews["brawlers"].append(rand_brawler)
                    	rews["rewards"] += 1
                    	rews["Gold"] -= randgold
                    	cardsi -= randcards
                elif randbrawler <= 25: # 0.15 шанс
                    if len(mythicbrawlersunlockable) == 0:
                    	pass
                    else:
                    	rand_brawler = choice(mythicbrawlersunlockable)
                    	mythicbrawlersunlockable.remove(rand_brawler)
                    	rews["brawlers"].append(rand_brawler)
                    	rews["rewards"] += 1
                    	rews["Gold"] -= randgold
                    	cardsi -= randcards
                elif randbrawler <= 70: # 0.45% шанс
                    if len(epicbrawlersunlockable) == 0:
                    	pass
                    else:
                    	rand_brawler = choice(epicbrawlersunlockable)
                    	epicbrawlersunlockable.remove(rand_brawler)
                    	rews["brawlers"].append(rand_brawler)
                    	rews["rewards"] += 1
                    	rews["Gold"] -= randgold
                    	cardsi -= randcards
                elif randbrawler <= 200: # 1.3% шанс
                    if len(superrarebrawlersunlockable) == 0:
                    	pass
                    else:
                    	rand_brawler = choice(superrarebrawlersunlockable)
                    	superrarebrawlersunlockable.remove(rand_brawler)
                    	rews["brawlers"].append(rand_brawler)
                    	rews["rewards"] += 1
                    	rews["Gold"] -= randgold
                    	cardsi -= randcards
                elif randbrawler <= 400: # 2% шанс
                    if len(rarebrawlersunlockable) == 0:
                    	pass
                    else:
                    	rand_brawler = choice(rarebrawlersunlockable)
                    	rarebrawlersunlockable.remove(rand_brawler)
                    	rews["brawlers"].append(rand_brawler)
                    	rews["rewards"] += 1
                    	rews["Gold"] -= randgold
                    	cardsi -= randcards
                elif randbrawler <= -1:
                	pass
            
            # Генерация звёздных сил
            if randstarpower < 10:  # 1% шанс
                if len(starpower_unlockable) == 0:
                    pass
                else:
                    rand_brawler = choice(starpower_unlockable)
                    starpower_unlockable.remove(rand_brawler)
                    rews["starpower"].append(rand_brawler)
                    rews["rewards"] += 1
                    rews["Gold"] -= randgold
                    cardsi -= randcards
                
            # Генерация скинов
            if self.config.get("SkinsBox", True) and randskin <= 20 and len(unlockable_skins) > 0:
            	skin_chance = randint(1, 100)
            	if skin_chance <= 59: # 59% шанс
            		skin_pool = [s for s in unlockable_skins if s in rareskins]
            	elif skin_chance <= 84: # 25% шанс
            		skin_pool = [s for s in unlockable_skins if s in superrareskins]
            	elif skin_chance <= 94: # 10% шанс
            		skin_pool = [s for s in unlockable_skins if s in epicskins]
            	elif skin_chance <= 97: # 3% шанс
            		skin_pool = [s for s in unlockable_skins if s in legendaryskins]
            	elif skin_chance <= 99: # 2% шанс
            		if self.config.get("UniqueSkinsBox", True):
            			skin_pool = [s for s in unlockable_skins if s in silverskins]
            		else:
            			skin_pool = []
            	else: # 1% шанс
            		if self.config.get("UniqueSkinsBox", True):
            			skin_pool = [s for s in unlockable_skins if s in goldskins]
            		else:
            			skin_pool = []
            	
            	if skin_pool:
            		rand_skin = choice(skin_pool)
            		unlockable_skins.remove(rand_skin)
            		rews["skins"].append(rand_skin)
            		rews["rewards"] += 1
            		rews["Gold"] -= randgold
            		cardsi -= randcards

        if rews["Gold"] == 0:
            return rews
        else:
            rews["rewards"] += 1

        # Генерация очков силы (только для бойцов с уровнем силы НЕ 8 и НЕ 9 и <=1500 очков сил)
        if box_type == 1:
            cards = []
            for i in range(2):
                try:
                    if i != 4:
                        if cardsi <= 20:
                            var = randint(5, 15)
                        else:
                            var = randint(10, int(cardsi / 2))
                            cardsi -= var
                    else:
                        var = cardsi
                    cards.append(var)
                except Exception as error:
                    break
            cards.sort()
            lens = len(unlocked_brawlers)
            if lens > 2:
                lens = 2
            for i in range(lens):
                brawler = choice(unlocked_brawlers)
                unlocked_brawlers.remove(brawler)
                inf = {
                    "brawler": brawler,
                    "multiplier": cards[0]
                }
                cards.pop(0)
                rews["Points"].append(inf)
                rews["rewards"] += 1
        elif box_type == 3:
            cards = []
            for i in range(3):
                try:
                    if i != 4:
                        if cardsi <= 20:
                            var = randint(5, 15)
                        else:
                            var = randint(10, int(cardsi / 2))
                            cardsi -= var
                    else:
                        var = cardsi
                    cards.append(var)
                except Exception as error:
                    break
            cards.sort()
            lens = len(unlocked_brawlers)
            if lens > 3:
                lens = 3
            for i in range(lens):
                brawler = choice(unlocked_brawlers)
                unlocked_brawlers.remove(brawler)
                inf = {
                    "brawler": brawler,
                    "multiplier": cards[0]
                }
                cards.pop(0)
                rews["Points"].append(inf)
                rews["rewards"] += 1
        elif box_type == 10:
            cards = []
            for i in range(5):
                try:
                    if i != 4:
                        if cardsi <= 20:
                            var = randint(5, 15)
                        else:
                            var = randint(10, int(cardsi / 2))
                            cardsi -= var
                    else:
                        var = cardsi
                    cards.append(var)
                except Exception as error:
                    break
            cards.sort()
            lens = len(unlocked_brawlers)
            if lens > 5:
                lens = 5
            for i in range(lens):
                brawler = choice(unlocked_brawlers)
                unlocked_brawlers.remove(brawler)
                inf = {
                    "brawler": brawler,
                    "multiplier": cards[0]
                }
                cards.pop(0)
                rews["Points"].append(inf)
                rews["rewards"] += 1
        else:
            pass
            
        if len(cards) > 0:
            for i in range(len(cards)):
                allca = 0
                allca += cards[i]
        else:
            pass
            
        if len(rews["Points"]) != 0 and lens < 5:
            allca = 20
            caef = int(allca / len(rews["Points"]))
            for i in range(len(rews["Points"])):
                rews["Points"][i]["multiplier"] += caef
        else:
            pass

        # Генерация бонусов
        for i in range(total_iterations):
            randbonus = randint(1, 5)
            if randbonus == 1:
                randbon = randint(1, 11)
                if randbon == 10:
                    gems = randint(3, 10)
                    rews["bonuses"][0]["multiplier"] = gems
                elif randbon == 7:
                    rews["bonuses"][1]["multiplier"] = 200
                else:
                    tickets = choice([3, 5, 7, 10])
                    rews["bonuses"][2]["multiplier"] = tickets
                    
        if rews["bonuses"][0]["multiplier"] > 0:
            rews["rewards"] += 1
        if rews["bonuses"][1]["multiplier"] > 0:
            rews["rewards"] += 1
        if rews["bonuses"][2]["multiplier"] > 0:
            rews["rewards"] += 1
            
        return rews