from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Database.DatabaseManager import DataBase
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Cards import Cards

from Utils.Reader import BSMessageReader


class TeamChangeMemberSettingsMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        print("CALL: TeamChangeMemberSettingsMessage")
        self.read_Vint()
        self.read_Vint()
        self.player.skin_id = self.read_Vint()
        
        if self.player.skin_id in [0, 29, 52, 97, 98]:
            self.player.brawler_id = 0
        elif self.player.skin_id in [1, 2, 69, 95, 96]:
            self.player.brawler_id = 1
        elif self.player.skin_id in [3, 25, 64, 103, 104]:
            self.player.brawler_id = 2
        elif self.player.skin_id in [4, 5, 58, 72, 91]:
            self.player.brawler_id = 3
        elif self.player.skin_id in [9, 26, 68, 105, 106]:
            self.player.brawler_id = 4
        elif self.player.skin_id in [10, 11, 101, 102]:
            self.player.brawler_id = 5
        elif self.player.skin_id in [12, 27, 59, 90, 92]:
            self.player.brawler_id = 6
        elif self.player.skin_id in [13, 44, 47]:
            self.player.brawler_id = 7
        elif self.player.skin_id in [14, 15, 60, 79]:
            self.player.brawler_id = 8
        elif self.player.skin_id in [6, 56, 57, 113, 114]:
            self.player.brawler_id = 9
        elif self.player.skin_id in [7, 28, 30]:
            self.player.brawler_id = 10
        elif self.player.skin_id in [18, 50, 63, 75]:
            self.player.brawler_id = 11
        elif self.player.skin_id in [19, 20, 49]:
            self.player.brawler_id = 12
        elif self.player.skin_id in [21, 71, 107, 108]:
            self.player.brawler_id = 13
        elif self.player.skin_id in [22, 99, 100]:
            self.player.brawler_id = 14
        elif self.player.skin_id in [23]:
            self.player.brawler_id = 15
        elif self.player.skin_id in [24]:
            self.player.brawler_id = 16
        elif self.player.skin_id in [32, 94]:
            self.player.brawler_id = 17
        elif self.player.skin_id in [34, 70]:
            self.player.brawler_id = 18
        elif self.player.skin_id in [41, 61, 88]:
            self.player.brawler_id = 19
        elif self.player.skin_id in [42, 45]:
            self.player.brawler_id = 20
        elif self.player.skin_id in [67, 111, 112, 117]:
            self.player.brawler_id = 21
        elif self.player.skin_id in [62, 109, 110]:
            self.player.brawler_id = 23
        elif self.player.skin_id in [93, 115, 116]:
            self.player.brawler_id = 25
        else:
        	self.player.brawler_id = 26


    def process(self):
       

        DataBase.UpdateGameroomPlayerInfo(self, self.player.low_id)

        TeamGameroomDataMessage(self.client, self.player).send()