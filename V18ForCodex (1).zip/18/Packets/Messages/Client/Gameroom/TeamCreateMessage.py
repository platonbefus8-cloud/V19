from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Logic.EventSlots import EventSlots
from Database.DatabaseManager import DataBase
import random

from Utils.Reader import BSMessageReader


class TeamCreateMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        print("CALL: TeamCreateMessage")
        self.mapSlot = self.read_Vint()
        self.player.map_id = self.read_Vint()
        self.roomType = self.read_Vint()
        self.player.brawlerstate = self.read_Vint()

        if self.player.map_id == -64:
            data = EventSlots.loadEvents(self)
            self.player.map_id = data[str(4)]['ID']
        else:
            data = EventSlots.loadEvents(self)
            self.player.map_id = data[str(self.mapSlot - 1)]['ID']

    def process(self):
        self.player.room_id = random.randint(0, 2147483647)
        DataBase.createGameroomDB(self)
        TeamGameroomDataMessage(self.client, self.player).send()
