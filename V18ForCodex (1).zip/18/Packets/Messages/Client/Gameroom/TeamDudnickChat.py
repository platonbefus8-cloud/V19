from Utils.Reader import BSMessageReader
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStream

class TeamDudkaChat(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
    def decode(self):
        print("CALL: TeamDudnickChat")
		self.message = self.read_string()
    def process(self):
    	TeamStream(self.client, self.player).send()