import json
import os
import time

LOG_FILE = 'anticheat_violations.json'

def log_violation(player_name, player_id, fingerprint_sha, details=""):
    data = []
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE, 'r') as f:
                data = json.load(f)
        except:
            data = []
    
    # Проверяем что не дубликат
    for entry in data:
        if entry.get('lowID') == player_id and entry.get('fingerprint') == fingerprint_sha:
            return
    
    data.append({
        'name': player_name,
        'lowID': player_id,
        'fingerprint': fingerprint_sha,
        'details': details,
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
    })
    
    with open(LOG_FILE, 'w') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    print(f"🔴 ЧИТЕР ОБНАРУЖЕН: {player_name} (ID: {player_id}) | SHA: {fingerprint_sha}")

def check_violation(low_id):
    if not os.path.exists(LOG_FILE):
        return None
    try:
        with open(LOG_FILE, 'r') as f:
            data = json.load(f)
        for entry in data:
            if entry.get('lowID') == low_id:
                return entry
    except:
        pass
    return None

def get_server_fingerprint():
    fp_file = 'GameAssets/fingerprint.json'
    if os.path.exists(fp_file):
        try:
            with open(fp_file, 'r') as f:
                fp_data = json.load(f)
                return fp_data.get('sha', '')
        except:
            pass
    return ''
