from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Database.DatabaseManager import DataBase
from Utils.Reader import BSMessageReader
import json
import os
import random
import re
import sqlite3
from datetime import datetime, timedelta

class AllianceChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ''
        self.send_ofs = False
        self.IsAcmd = False
        
        # Список бойцов
        self.brawler_names = {
            0: "ШЕЛЛИ", 1: "КОЛЬТ", 2: "БУЛЛ", 3: "БРОК", 4: "РИКО", 5: "СПАЙК", 6: "БАРЛИ", 7: "ДЖЕССИ", 8: "НИТА", 9: "ДИНОМАЙК", 10: "ЭЛЬ ПРИМО", 11: "МОРТИС", 12: "ВОРОН", 13: "ПОКО", 14: "БО", 15: "ПАЙПЕР", 16: "ПЭМ", 17: "ТАРА", 18: "ДЭРРИЛ", 19: "ПЕННИ", 20: "ФРЭНК", 21: "ДЖИН", 23: "ЛЕОН", 24: "РОЗА", 25: "КАРЛ", 26: "БИБИ"
        }
        
        # Список скинов
        self.skin_names = {
        
            # ШЕЛЛИ
            29: "БАНДИТКА ШЕЛЛИ", 
            52: "ЗВЁЗДНАЯ ШЕЛЛИ",
            97: "СЕРЕБРЯНАЯ ШЕЛЛИ", 
            98: "ЗОЛОТАЯ ШЕЛЛИ",
            
            # КОЛЬТ
            2: "РОК-ЗВЕЗДА КОЛЬТ", 
            69: "ГВАРДЕЕЦ КОЛЬТ",
            95: "СЕРЕБРЯНЫЙ КОЛЬТ", 
            96: "ЗОЛОТОЙ КОЛЬТ",
            
            # БУЛЛ
            25: "ВИКИНГ БУЛЛ", 
            64: "ТАЧДАУН БУЛЛ",
            103: "СЕРЕБРЯНЫЙ БУЛЛ", 
            104: "ЗОЛОТОЙ БУЛЛ",
            
            # БРОК
            5: "ПЛЯЖНЫЙ БРОК", 
            58: "БРЕЙК-ДАНСЕР БРОК",
            72: "КУНГ-ФУ БРОК", 
            91: "СТРИТРЕЙСЕР БРОК",
            
            # РИКО
            26: "МАЖОР РИКО", 
            68: "ПОПКОРН РИКО",
            105: "СЕРЕБРЯНЫЙ РИКО", 
            106: "ЗОЛОТОЙ РИКО",
            
            # СПАЙК
            11: "САКУРА СПАЙК", 
            101: "СЕРЕБРЯНЫЙ СПАЙК", 
            102: "ЗОЛОТОЙ СПАЙК",
            
            # БАРЛИ
            27: "ЗОЛОТОЙ БАРЛИ", 
            59: "ВОЛШЕБНИк БАРЛИ",
            90: "БАРЛИ С ПЛЮШКАМИ", 
            92: "КЛЕНОВЫЙ БАРЛИ",
            
            # ДЖЕССИ
            44: "ДРАКОНОБОРЕЦ ДЖЕССИ",
            47: "ЛЕТНЯЯ ДЖЕССИ",
            
            # НИТА
            15: "ПАНДА НИТА", 
            60: "НИТА КРАСНЫЙ НОС",
            79: "СИБА-ИНУ НИТА",
            
            # ДИНОМАЙК
            56: "САНТАМАЙК", 
            57: "МАЙК-ПОВАР",
            113: "СЕРЕБРЯНЫЙ ДИНОМАЙК", 
            114: "ЗОЛОТОЙ ДИНОМАЙК",
            
            # ЭЛЬ ПРИМО
            28: "ЭЛЬ РУДО ПРИМО", 
            30: "ЭЛЬ РЕЙ ПРИМО",
            
            # МОРТИС
            50: "РОКАБИЛЬЩИК МОРТИС", 
            63: "МОРТИС В ЦИЛИНДРЕ",
            75: "НОЧНАЯ ВЕДЬМА МОРТИС",
            
            # ВОРОН
            20: "БЕЛЫЙ ВОРОН", 
            49: "ВОРОН ФЕНИКС",
            
            # ПОКО
            71: "МЕНИСТРЕЛЬ ПОКО",
            107: "СЕРЕБРЯНЫЙ ПОКО", 
            108: "ЗОЛОТОЙ ПОКО",
            
            # БО
            99: "СЕРЕБРЯНЫЙ БО", 
            100: "ЗОЛОТОЙ БО",
            
            # ТАРА
            94: "ИНДИГО ТАРА",
            
            # ДЭРРИЛ
            70: "СОЕВЫЙ ДЭРРИЛ",
            
            # ПЕННИ
            61: "ПОМОЩНИЦА ПЕННИ", 
            88: "ЗАЙКА ПЕННИ",
            
            # ФРЭНК
            45: "ПЕЩЕРНЫЙ ФРЭНК",
            
            # ДЖИН
            111: "СЕРЕБРЯНЫЙ ДЖИН", 
            112: "ЗОЛОТОЙ ДЖИН",
            117: "ОБЕЗЬЯНКА ДЖИН",
            
            # ЛЕОН
            109: "СЕРЕБРЯНЫЙ ЛЕОН", 
            110: "ЗОЛОТОЙ ЛЕОН",
            
            # КАРЛ
            93: "БЕЗУМНЫЙ КАРЛ",
            115: "СЕРЕБРЯНЫЙ КАРЛ", 
            116: "ЗОЛОТОЙ КАРЛ"
        }
        
    def get_online_count(self):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
                return config.get('Online', 0)
        except Exception as e:
            print(f"Error reading online count: {e}")
            return 0

    def get_current_time(self):
        return datetime.now().strftime('%H:%M:%S | %d.%m.%Y')

    def add_time_stamp(self, message):
        return f"{message}\n\n{self.get_current_time()}"

    def decode(self):
        self.msg = self.read_string()

        if self.msg.lower() == '/myaccount':
            try:
                self.bot_msg = self.add_time_stamp(f"<c3>Ваш аккаунт:</c>\nNAME: {self.player.name}\nID: {self.player.low_id}\nTOKEN: {self.player.token}\nТрофеи: {self.player.trophies}\nКристаллы: {self.player.gems}\nМонеты: {self.player.gold}")
                self.IsAcmd = True
            except Exception as e:
                self.bot_msg = self.add_time_stamp(f"Ошибка при получении данных аккаунта: {e}\n\nОбратитесь в поддержку сервера")
                self.IsAcmd = True

        elif self.msg.lower() == '/help':
            self.show_help()
            self.IsAcmd = True

        elif self.msg.lower().startswith('/promo'):
            try:
                promo_code = self.msg.split(" ", 1)[1].upper()
                self.process_promo_code(promo_code)
                self.IsAcmd = True
            except:
                self.bot_msg = self.add_time_stamp("Неверный формат команды!\nИспользуйте: /promo <промокод>")

        elif self.msg.lower().startswith('/register'):
            try:
                parts = self.msg.split(" ")
                if len(parts) != 4:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /register «ID» «пароль» «повторить пароль»</c>")
                    return
                
                low_id = parts[1]
                password = parts[2]
                confirm_password = parts[3]
                
                self.register_account(low_id, password, confirm_password)
                self.IsAcmd = True
            except Exception as e:
                self.bot_msg = self.add_time_stamp(f"Ошибка при обработке команды регистрации: {str(e)}\n\nОбратитесь в поддержку сервера.")

        elif self.msg.lower().startswith('/login'):
            try:
                parts = self.msg.split(" ")
                if len(parts) != 3:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /login «ID» «пароль»</c>")
                    return
                
                low_id = parts[1]
                password = parts[2]
                
                self.login_account(low_id, password)
                self.IsAcmd = True
            except Exception as e:
                self.bot_msg = self.add_time_stamp(f"Ошибка при обработке команды входа: {str(e)}\n\nОбратитесь в поддержку сервера.")

        elif self.msg.lower().startswith('/unregister'):
            try:
                parts = self.msg.split(" ")
                if len(parts) != 2:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /unregister «пароль»</c>")
                    return
                
                password = parts[1]
                
                self.unregister_account(password)
                self.IsAcmd = True
            except Exception as e:
                self.bot_msg = self.add_time_stamp(f"Ошибка при обработке команды отвязки: {str(e)}\n\nОбратитесь в поддержку сервера.")

        elif self.msg.lower().startswith('/resetpassword'):
            try:
                parts = self.msg.split(" ")
                if len(parts) != 4:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /resetpassword «старый пароль» «новый пароль» «повторить пароль»</c>")
                    return
                
                old_password = parts[1]
                new_password = parts[2]
                confirm_password = parts[3]
                
                self.reset_password(old_password, new_password, confirm_password)
                self.IsAcmd = True
            except Exception as e:
                self.bot_msg = self.add_time_stamp(f"Ошибка при обработке команды смены пароля: {str(e)}\n\nОбратитесь в поддержку сервера.")

        elif self.msg.lower().startswith('/snos'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 1:
                        success = self.delete_own_account()
                        if success:
                            self.player.err_code = 1
                            message = "ВАШ АККАУНТ УСПЕШНО УДАЛЁН!\nПожалуйста перезайдите в игру!"
                            LoginFailedMessage(self.client, self.player, message).send()
                            return
                    elif len(parts) == 2:
                        target_low_id = parts[1]
                        success, player_name = self.delete_player_account(target_low_id)
                        
                        if success:
                            self.bot_msg = self.add_time_stamp(f"<c3>Аккаунт {player_name} (ID: {target_low_id}) успешно удален!</c>")
                        else:
                            self.bot_msg = self.add_time_stamp(f"<c7>Аккаунт с ID {target_low_id} не найден или нельзя удалить админа!</c>")
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /snos или /snos «ID»</c>")
                    
                    self.IsAcmd = True
                except Exception as e:
                    self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при удалении аккаунта:</c>\n{str(e)}")
                    self.IsAcmd = True
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/reset'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 1:
                        old_gems = self.player.gems
                        old_gold = self.player.gold
                        old_tickets = self.player.tickets
                        
                        DataBase.replaceValue(self, 'gold', 0)
                        DataBase.replaceValue(self, 'gems', 0)
                        DataBase.replaceValue(self, 'tickets', 0)
                        DataBase.replaceValue(self, 'tokensdoubler', 0)
                        DataBase.replaceValue(self, 'winstreak', 0)
                        DataBase.replaceValue(self, 'brawlBoxes', 0)
                        DataBase.replaceValue(self, 'bigBoxes', 0)
                        DataBase.replaceValue(self, 'vip', 0)
                        DataBase.replaceValue(self, 'viptime', "0")
                        DataBase.replaceValue(self, 'title', "ОТСУТСТВУЕТ")
                        
                        self.player.err_code = 1
                        message = f"ВАШИ РЕСУРСЫ УСПЕШНО СБРОШЕНЫ!\n\nБыло:\nКристаллы: {old_gems}\nМонеты: {old_gold}\nБилеты: {old_tickets}\n\nСтало:\nКристаллы: 0\nМонеты: 0\nБилеты: 0\n\nПожалуйста перезайдите в игру!"
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 2:
                        target_low_id = parts[1]
                        self.reset_player_resources(target_low_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /reset или /reset «ID»</c>")
                    self.IsAcmd = True
                except Exception as e:
                    self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при сбросе ресурсов:</c>\n{str(e)}")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/addgems'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_gems = self.player.gems
                        new_gems = old_gems + amount
                        DataBase.replaceValue(self, 'gems', new_gems)
                        
                        self.player.err_code = 1
                        message = f"Кристаллы успешно выданы +{amount} кристаллов. Новый баланс: {new_gems}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.add_player_gems(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addgems «количество» или /addgems «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/setgems'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_gems = self.player.gems
                        DataBase.replaceValue(self, 'gems', amount)
                        
                        self.player.err_code = 1
                        message = f"Кристаллы успешно назначены {amount} кристаллов. Было баланс: {old_gems}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.set_player_gems(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /setgems «количество» или /setgems «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/ungems'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_gems = self.player.gems
                        new_gems = max(0, old_gems - amount)
                        DataBase.replaceValue(self, 'gems', new_gems)
                        
                        self.player.err_code = 1
                        message = f"Кристаллы успешно забраны -{amount} кристаллов. Новый баланс: {new_gems}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.remove_player_gems(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /ungems «количество» или /ungems «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/addgold'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_gold = self.player.gold
                        new_gold = old_gold + amount
                        DataBase.replaceValue(self, 'gold', new_gold)
                        
                        self.player.err_code = 1
                        message = f"Монеты успешно выданы +{amount} монет. Новый баланс: {new_gold}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.add_player_gold(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addgold «количество» или /addgold «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/setgold'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_gold = self.player.gold
                        DataBase.replaceValue(self, 'gold', amount)
                        
                        self.player.err_code = 1
                        message = f"Монеты успешно назначены {amount} монет. Было баланс: {old_gold}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.set_player_gold(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /setgold «количество» или /setgold «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/ungold'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_gold = self.player.gold
                        new_gold = max(0, old_gold - amount)
                        DataBase.replaceValue(self, 'gold', new_gold)
                        
                        self.player.err_code = 1
                        message = f"Монеты успешно забраны -{amount} монет. Новый баланс: {new_gold}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.remove_player_gold(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /ungold «количество» или /ungold «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/addtickets'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_tickets = self.player.tickets
                        new_tickets = old_tickets + amount
                        DataBase.replaceValue(self, 'tickets', new_tickets)
                        
                        self.player.err_code = 1
                        message = f"Билеты успешно выданы +{amount} билетов. Новый баланс: {new_tickets}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.add_player_tickets(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addtickets «количество» или /addtickets «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/settickets'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_tickets = self.player.tickets
                        DataBase.replaceValue(self, 'tickets', amount)
                        
                        self.player.err_code = 1
                        message = f"Билеты успешно назначены {amount} билетов. Было баланс: {old_tickets}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.set_player_tickets(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /settickets «количество» или /settickets «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/untickets'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        amount = int(parts[1])
                        old_tickets = self.player.tickets
                        new_tickets = max(0, old_tickets - amount)
                        DataBase.replaceValue(self, 'tickets', new_tickets)
                        
                        self.player.err_code = 1
                        message = f"Билеты успешно забраны -{amount} билетов. Новый баланс: {new_tickets}\nПожалуйста перезайдите в игру."
                        LoginFailedMessage(self.client, self.player, message).send()
                        return
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        amount = int(parts[2])
                        self.remove_player_tickets(target_low_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /untickets «количество» или /untickets «ID» «количество»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        # Новые команды для управления трофеями бойцов
        elif self.msg.lower().startswith('/addtrophies'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 4:
                        target_low_id = parts[1]
                        brawler_id = int(parts[2])
                        amount = int(parts[3])
                        self.add_player_brawler_trophies(target_low_id, brawler_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addtrophies «ID» «ID бойца» «кол-во»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/settrophies'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 4:
                        target_low_id = parts[1]
                        brawler_id = int(parts[2])
                        amount = int(parts[3])
                        self.set_player_brawler_trophies(target_low_id, brawler_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /settrophies «ID» «ID бойца» «кол-во»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/untrophies'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 4:
                        target_low_id = parts[1]
                        brawler_id = int(parts[2])
                        amount = int(parts[3])
                        self.remove_player_brawler_trophies(target_low_id, brawler_id, amount)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /untrophies «ID» «ID бойца» «кол-во»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        # Новые команды для управления ящиками
        elif self.msg.lower().startswith('/addboxes'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        small_boxes = int(parts[2])
                        self.add_player_boxes(target_low_id, small_boxes, 0)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addboxes «ID» «малые ящики»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/setboxes'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        small_boxes = int(parts[2])
                        self.set_player_boxes(target_low_id, small_boxes, 0)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /setboxes «ID» «малые ящики»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/unboxes'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        small_boxes = int(parts[2])
                        self.remove_player_boxes(target_low_id, small_boxes, 0)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /unboxes «ID» «малые ящики»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/addbigboxes'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        big_boxes = int(parts[2])
                        self.add_player_boxes(target_low_id, 0, big_boxes)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addbigboxes «ID» «большие ящики»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/setbigboxes'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        big_boxes = int(parts[2])
                        self.set_player_boxes(target_low_id, 0, big_boxes)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /setbigboxes «ID» «большие ящики»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/unbigboxes'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        big_boxes = int(parts[2])
                        self.remove_player_boxes(target_low_id, 0, big_boxes)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /unbigboxes «ID» «большие ящики»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        # Команда для смены темы
        elif self.msg.lower().startswith('/theme'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        theme_id = int(parts[1])
                        self.change_theme(theme_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /theme «ID темы»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/ban'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        target_low_id = parts[1]
                        self.ban_player_forever(target_low_id)
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        ban_days = parts[2]
                        self.ban_player(target_low_id, ban_days)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /ban «ID» или /ban «ID» «дни»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/unban'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        target_low_id = parts[1]
                        self.unban_player(target_low_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /unban «ID»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/vip'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        target_low_id = parts[1]
                        self.set_vip_forever(target_low_id)
                    elif len(parts) == 3:
                        target_low_id = parts[1]
                        vip_days = parts[2]
                        self.set_vip(target_low_id, vip_days)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /vip «ID» или /vip «ID» «дни»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/unvip'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        target_low_id = parts[1]
                        self.remove_vip(target_low_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /unvip «ID»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/info'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        target_low_id = parts[1]
                        self.get_player_info(target_low_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /info «ID»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower() == '/serverinfo':
            if self.player.admin == 1:
                self.get_server_info()
                self.IsAcmd = True
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/addadmin'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        target_low_id = parts[1]
                        self.add_admin(target_low_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addadmin «ID»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/unadmin'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 2:
                        target_low_id = parts[1]
                        self.remove_admin(target_low_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /unadmin «ID»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/addskin'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        skin_id = int(parts[2])
                        self.add_skin(target_low_id, skin_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addskin «ID» «ID скина»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/unskin'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        skin_id = int(parts[2])
                        self.remove_skin(target_low_id, skin_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /unskin «ID» «ID скина»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/addbrawler'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        brawler_id = int(parts[2])
                        self.add_brawler(target_low_id, brawler_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /addbrawler «ID» «ID бойца»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        elif self.msg.lower().startswith('/unbrawler'):
            if self.player.admin == 1:
                try:
                    parts = self.msg.split(" ")
                    if len(parts) == 3:
                        target_low_id = parts[1]
                        brawler_id = int(parts[2])
                        self.remove_brawler(target_low_id, brawler_id)
                    else:
                        self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>\n<c3>Используйте: /unbrawler «ID» «ID бойца»</c>")
                    self.IsAcmd = True
                except:
                    self.bot_msg = self.add_time_stamp("<c7>Неверный формат команды!</c>")
            else:
                self.bot_msg = self.add_time_stamp("<c2>Недостаточно прав для выполнения этой команды!</c>")

        else:
            self.IsAcmd = False

    # Новые методы для управления трофеями бойцов
    def add_player_brawler_trophies(self, target_low_id, brawler_id, amount):
        try:
            if brawler_id not in self.brawler_names:
                self.bot_msg = self.add_time_stamp(f"<c7>Боец с ID {brawler_id} не существует!</c>")
                return
                
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    # Получаем текущие трофеи бойца
                    brawlers_trophies = player_data.get('brawlersTrophies', {})
                    current_trophies = brawlers_trophies.get(str(brawler_id), 0)
                    
                    # Добавляем трофеи
                    new_trophies = current_trophies + amount
                    brawlers_trophies[str(brawler_id)] = new_trophies
                    player_data['brawlersTrophies'] = brawlers_trophies
                    
                    # Обновляем общие трофеи
                    total_trophies = player_data.get('trophies', 0)
                    player_data['trophies'] = total_trophies + amount
                    
                    # Обновляем максимальные трофеи если нужно
                    highest_trophies = player_data.get('highesttrophies', 0)
                    if player_data['trophies'] > highest_trophies:
                        player_data['highesttrophies'] = player_data['trophies']
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    brawler_name = self.brawler_names[brawler_id]
                    self.bot_msg = self.add_time_stamp(f"<c3>Трофеи бойца {brawler_name} игрока {player_name} (ID: {target_low_id}) успешно добавлены +{amount} трофеев. Было: {current_trophies}, стало: {new_trophies}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при добавлении трофеев бойца:</c>\n{str(e)}")

    def set_player_brawler_trophies(self, target_low_id, brawler_id, amount):
        try:
            if brawler_id not in self.brawler_names:
                self.bot_msg = self.add_time_stamp(f"<c7>Боец с ID {brawler_id} не существует!</c>")
                return
                
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    # Получаем текущие трофеи бойца
                    brawlers_trophies = player_data.get('brawlersTrophies', {})
                    current_trophies = brawlers_trophies.get(str(brawler_id), 0)
                    
                    # Вычисляем разницу для обновления общих трофеев
                    difference = amount - current_trophies
                    
                    # Устанавливаем новые трофеи
                    brawlers_trophies[str(brawler_id)] = amount
                    player_data['brawlersTrophies'] = brawlers_trophies
                    
                    # Обновляем общие трофеи
                    total_trophies = player_data.get('trophies', 0)
                    player_data['trophies'] = max(0, total_trophies + difference)
                    
                    # Обновляем максимальные трофеи если нужно
                    highest_trophies = player_data.get('highesttrophies', 0)
                    if player_data['trophies'] > highest_trophies:
                        player_data['highesttrophies'] = player_data['trophies']
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    brawler_name = self.brawler_names[brawler_id]
                    self.bot_msg = self.add_time_stamp(f"<c3>Трофеи бойца {brawler_name} игрока {player_name} (ID: {target_low_id}) успешно установлены на {amount} трофеев. Было: {current_trophies}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при установке трофеев бойца:</c>\n{str(e)}")

    def remove_player_brawler_trophies(self, target_low_id, brawler_id, amount):
        try:
            if brawler_id not in self.brawler_names:
                self.bot_msg = self.add_time_stamp(f"<c7>Боец с ID {brawler_id} не существует!</c>")
                return
                
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    # Получаем текущие трофеи бойца
                    brawlers_trophies = player_data.get('brawlersTrophies', {})
                    current_trophies = brawlers_trophies.get(str(brawler_id), 0)
                    
                    # Вычитаем трофеи
                    new_trophies = max(0, current_trophies - amount)
                    brawlers_trophies[str(brawler_id)] = new_trophies
                    player_data['brawlersTrophies'] = brawlers_trophies
                    
                    # Обновляем общие трофеи
                    total_trophies = player_data.get('trophies', 0)
                    player_data['trophies'] = max(0, total_trophies - amount)
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    brawler_name = self.brawler_names[brawler_id]
                    self.bot_msg = self.add_time_stamp(f"<c3>Трофеи бойца {brawler_name} игрока {player_name} (ID: {target_low_id}) успешно убраны -{amount} трофеев. Было: {current_trophies}, стало: {new_trophies}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при удалении трофеев бойца:</c>\n{str(e)}")

    # Новые методы для управления ящиками
    def add_player_boxes(self, target_low_id, small_boxes, big_boxes):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_small = player_data.get('brawlBoxes', 0)
                    old_big = player_data.get('bigBoxes', 0)
                    
                    new_small = old_small + small_boxes
                    new_big = old_big + big_boxes
                    
                    player_data['brawlBoxes'] = new_small
                    player_data['bigBoxes'] = new_big
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    boxes_info = []
                    if small_boxes > 0:
                        boxes_info.append(f"+{small_boxes} малых ящиков")
                    if big_boxes > 0:
                        boxes_info.append(f"+{big_boxes} больших ящиков")
                    
                    self.bot_msg = self.add_time_stamp(f"<c3>Ящики игрока {player_name} (ID: {target_low_id}) успешно выданы: {', '.join(boxes_info)}. Малые: {old_small}→{new_small}, Большие: {old_big}→{new_big}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче ящиков:</c>\n{str(e)}")

    def set_player_boxes(self, target_low_id, small_boxes, big_boxes):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_small = player_data.get('brawlBoxes', 0)
                    old_big = player_data.get('bigBoxes', 0)
                    
                    player_data['brawlBoxes'] = small_boxes
                    player_data['bigBoxes'] = big_boxes
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    boxes_info = []
                    if small_boxes >= 0:
                        boxes_info.append(f"малые: {old_small}→{small_boxes}")
                    if big_boxes >= 0:
                        boxes_info.append(f"большие: {old_big}→{big_boxes}")
                    
                    self.bot_msg = self.add_time_stamp(f"<c3>Ящики игрока {player_name} (ID: {target_low_id}) успешно установлены: {', '.join(boxes_info)}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при установке ящиков:</c>\n{str(e)}")

    def remove_player_boxes(self, target_low_id, small_boxes, big_boxes):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_small = player_data.get('brawlBoxes', 0)
                    old_big = player_data.get('bigBoxes', 0)
                    
                    new_small = max(0, old_small - small_boxes)
                    new_big = max(0, old_big - big_boxes)
                    
                    player_data['brawlBoxes'] = new_small
                    player_data['bigBoxes'] = new_big
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    boxes_info = []
                    if small_boxes > 0:
                        boxes_info.append(f"-{small_boxes} малых ящиков")
                    if big_boxes > 0:
                        boxes_info.append(f"-{big_boxes} больших ящиков")
                    
                    self.bot_msg = self.add_time_stamp(f"<c3>Ящики игрока {player_name} (ID: {target_low_id}) успешно убраны: {', '.join(boxes_info)}. Малые: {old_small}→{new_small}, Большие: {old_big}→{new_big}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при удалении ящиков:</c>\n{str(e)}")

    # Метод для смены темы
    def change_theme(self, theme_id):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
            
            old_theme = config.get('ThemeID', 12)
            config['ThemeID'] = theme_id
            
            with open('config.json', 'w') as f:
                json.dump(config, f, indent=4)
            
            self.bot_msg = self.add_time_stamp(f"<c3>Тема успешно изменена! Было: {old_theme}, стало: {theme_id}</c>")
            
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при изменении темы:</c>\n{str(e)}")

    def delete_own_account(self):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("DELETE FROM players WHERE token=?", (self.player.token,))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Ошибка при удалении своего аккаунта: {e}")
            return False

    def delete_player_account(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            account_found = False
            target_token = None
            target_name = "Unknown"
            
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    if player_data.get('admin', 0) == 1:
                        return False, None
                    
                    target_token = token
                    target_name = player_data.get('name', 'Unknown')
                    account_found = True
                    break
            
            if account_found and target_token:
                cursor.execute("DELETE FROM players WHERE token=?", (target_token,))
                conn.commit()
                conn.close()
                return True, target_name
            else:
                conn.close()
                return False, None
                
        except Exception as e:
            print(f"Ошибка при удалении аккаунта: {e}")
            return False, None

    def ban_player(self, target_low_id, ban_days):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    ban_end_date = (datetime.now() + timedelta(days=int(ban_days))).strftime("%d.%m.%Y")
                    player_data['ban'] = 1
                    player_data['bantime'] = ban_end_date
                    player_data['baninfo'] = f"Забанен администратором на {ban_days} дней"
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Игрок {player_name} (ID: {target_low_id}) забанен на {ban_days} дней до {ban_end_date}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при бане игрока:</c>\n{str(e)}")

    def ban_player_forever(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    player_data['ban'] = 2
                    player_data['bantime'] = "FOREVER"
                    player_data['baninfo'] = "Забанен навсегда администратором"
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Игрок {player_name} (ID: {target_low_id}) забанен навсегда!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при бане игрока:</c>\n{str(e)}")

    def unban_player(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    player_data['ban'] = 0
                    player_data['bantime'] = "0"
                    player_data['baninfo'] = "ОТСУТСТВУЕТ"
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Игрок {player_name} (ID: {target_low_id}) разбанен!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при разбане игрока:</c>\n{str(e)}")

    def set_vip(self, target_low_id, vip_days):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    vip_end_date = (datetime.now() + timedelta(days=int(vip_days))).strftime("%d.%m.%Y")
                    player_data['vip'] = 1
                    player_data['viptime'] = vip_end_date
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>VIP статус выдан игроку {player_name} (ID: {target_low_id}) на {vip_days} дней до {vip_end_date}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче VIP:</c>\n{str(e)}")

    def set_vip_forever(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    player_data['vip'] = 2
                    player_data['viptime'] = "FOREVER"
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>VIP статус выдан игроку {player_name} (ID: {target_low_id}) навсегда!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче VIP:</c>\n{str(e)}")

    def remove_vip(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    player_data['vip'] = 0
                    player_data['viptime'] = "0"
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>VIP статус забран у игрока {player_name} (ID: {target_low_id})!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при снятии VIP:</c>\n{str(e)}")

    def add_admin(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    player_data['admin'] = 1
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Админ права выданы игроку {player_name} (ID: {target_low_id})!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче админ прав:</c>\n{str(e)}")

    def remove_admin(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    player_data['admin'] = 0
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Админ права забраны у игрока {player_name} (ID: {target_low_id})!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при снятии админ прав:</c>\n{str(e)}")

    def add_skin(self, target_low_id, skin_id):
        try:
            if skin_id not in self.skin_names:
                self.bot_msg = self.add_time_stamp(f"<c7>Скин с ID {skin_id} не существует!</c>")
                return
                
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    unlocked_skins = player_data.get('UnlockedSkins', [])
                    
                    if skin_id in unlocked_skins:
                        self.bot_msg = self.add_time_stamp(f"<c7>У игрока уже есть скин {self.skin_names[skin_id]}!</c>")
                        conn.close()
                        return
                    
                    unlocked_skins.append(skin_id)
                    player_data['UnlockedSkins'] = unlocked_skins
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Скин {self.skin_names[skin_id]} выдан игроку {player_name} (ID: {target_low_id})!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче скина:</c>\n{str(e)}")

    def remove_skin(self, target_low_id, skin_id):
        try:
            if skin_id not in self.skin_names:
                self.bot_msg = self.add_time_stamp(f"<c7>Скин с ID {skin_id} не существует!</c>")
                return
                
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    unlocked_skins = player_data.get('UnlockedSkins', [])
                    
                    if skin_id not in unlocked_skins:
                        self.bot_msg = self.add_time_stamp(f"<c7>У игрока нет скина {self.skin_names[skin_id]}!</c>")
                        conn.close()
                        return
                    
                    unlocked_skins.remove(skin_id)
                    player_data['UnlockedSkins'] = unlocked_skins
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Скин {self.skin_names[skin_id]} забран у игрока {player_name} (ID: {target_low_id})!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при снятии скина:</c>\n{str(e)}")

    def add_brawler(self, target_low_id, brawler_id):
        try:
            if brawler_id not in self.brawler_names:
                self.bot_msg = self.add_time_stamp(f"<c7>Боец с ID {brawler_id} не существует!</c>")
                return
                
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    brawlers_unlocked = player_data.get('UnlockedBrawlers', {})
                    
                    if str(brawler_id) in brawlers_unlocked and brawlers_unlocked[str(brawler_id)] == 1:
                        self.bot_msg = self.add_time_stamp(f"<c7>У игрока уже есть боец {self.brawler_names[brawler_id]}!</c>")
                        conn.close()
                        return
                    
                    brawlers_unlocked[str(brawler_id)] = 1
                    player_data['UnlockedBrawlers'] = brawlers_unlocked
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Боец {self.brawler_names[brawler_id]} выдан игроку {player_name} (ID: {target_low_id})!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче бойца:</c>\n{str(e)}")

    def remove_brawler(self, target_low_id, brawler_id):
        try:
            if brawler_id not in self.brawler_names:
                self.bot_msg = self.add_time_stamp(f"<c7>Боец с ID {brawler_id} не существует!</c>")
                return
                
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    brawlers_unlocked = player_data.get('UnlockedBrawlers', {})
                    
                    if str(brawler_id) not in brawlers_unlocked or brawlers_unlocked[str(brawler_id)] != 1:
                        self.bot_msg = self.add_time_stamp(f"<c7>У игрока нет бойца {self.brawler_names[brawler_id]}!</c>")
                        conn.close()
                        return
                    
                    brawlers_unlocked[str(brawler_id)] = 0
                    player_data['UnlockedBrawlers'] = brawlers_unlocked
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Боец {self.brawler_names[brawler_id]} забран у игрока {player_name} (ID: {target_low_id})!</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при снятии бойца:</c>\n{str(e)}")

    def get_player_info(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    ban_status = "Не забанен"
                    if player_data.get('ban', 0) == 1:
                        ban_status = f"Забанен до {player_data.get('bantime', 'НЕИЗВЕСТНО')}"
                    elif player_data.get('ban', 0) == 2:
                        ban_status = "Забанен навсегда"
                    
                    vip_status = "Нет VIP"
                    if player_data.get('vip', 0) == 1:
                        vip_status = f"VIP до {player_data.get('viptime', 'НЕИЗВЕСТНО')}"
                    elif player_data.get('vip', 0) == 2:
                        vip_status = "Бессрочный VIP"
                    
                    admin_status = "Нет" if player_data.get('admin', 0) == 0 else "Да"
                    
                    brawlers_count = 0
                    brawlers_unlocked = player_data.get('UnlockedBrawlers', {})
                    for brawler_id, unlocked in brawlers_unlocked.items():
                        if unlocked == 1:
                            brawlers_count += 1
                    
                    skins_count = len(player_data.get('UnlockedSkins', []))
                    
                    self.bot_msg = self.add_time_stamp(
                        f"<c3>Информация об игроке:</c>\n"
                        f"Имя: {player_data.get('name', 'Unknown')}\n"
                        f"ID: {target_low_id}\n"
                        f"Трофеи: {player_data.get('trophies', 0)}\n"
                        f"Кристаллы: {player_data.get('gems', 0)}\n"
                        f"Монеты: {player_data.get('gold', 0)}\n"
                        f"Билеты: {player_data.get('tickets', 0)}\n"
                        f"Бойцов: {brawlers_count}\n"
                        f"Скинов: {skins_count}\n"
                        f"Админ: {admin_status}\n"
                        f"Статус бана: {ban_status}\n"
                        f"VIP статус: {vip_status}\n"
                        f"Титул: {player_data.get('title', 'ОТСУТСТВУЕТ')}"
                    )
                    player_found = True
                    break
            
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при получении информации:</c>\n{str(e)}")

    def get_server_info(self):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM players")
            total_players = cursor.fetchone()[0]
            
            cursor.execute("SELECT SUM(json_extract(info, '$.gems')) FROM players")
            total_gems = cursor.fetchone()[0] or 0
            
            cursor.execute("SELECT SUM(json_extract(info, '$.trophies')) FROM players")
            total_trophies = cursor.fetchone()[0] or 0
            
            cursor.execute("SELECT COUNT(*) FROM players WHERE json_extract(info, '$.vip') > 0")
            vip_players = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM players WHERE json_extract(info, '$.ban') > 0")
            banned_players = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM players WHERE json_extract(info, '$.admin') = 1")
            admin_players = cursor.fetchone()[0]
            
            conn.close()
            
            self.bot_msg = self.add_time_stamp(
                f"<c3>Информация о сервере:</c>\n"
                f"Всего игроков: {total_players}\n"
                f"Админов: {admin_players}\n"
                f"VIP игроков: {vip_players}\n"
                f"Забаненных: {banned_players}\n"
                f"Всего кристаллов: {total_gems}\n"
                f"Всего трофеев: {total_trophies}\n"
                f"Онлайн: {self.get_online_count()}"
            )
            
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при получении информации о сервере:</c>\n{str(e)}")

    def add_player_gems(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_gems = player_data.get('gems', 0)
                    new_gems = old_gems + amount
                    player_data['gems'] = new_gems
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Кристаллы игрока {player_name} (ID: {target_low_id}) успешно выданы +{amount} кристаллов. Новый баланс: {new_gems}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче кристаллов:</c>\n{str(e)}")

    def set_player_gems(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_gems = player_data.get('gems', 0)
                    player_data['gems'] = amount
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Кристаллы игрока {player_name} (ID: {target_low_id}) успешно назначены {amount} кристаллов. Было баланс: {old_gems}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при установке кристаллов:</c>\n{str(e)}")

    def remove_player_gems(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_gems = player_data.get('gems', 0)
                    new_gems = max(0, old_gems - amount)
                    player_data['gems'] = new_gems
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Кристаллы игрока {player_name} (ID: {target_low_id}) успешно забраны -{amount} кристаллов. Новый баланс: {new_gems}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при снятии кристаллов:</c>\n{str(e)}")

    def add_player_gold(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_gold = player_data.get('gold', 0)
                    new_gold = old_gold + amount
                    player_data['gold'] = new_gold
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Монеты игрока {player_name} (ID: {target_low_id}) успешно выданы +{amount} монет. Новый баланс: {new_gold}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче монет:</c>\n{str(e)}")

    def set_player_gold(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_gold = player_data.get('gold', 0)
                    player_data['gold'] = amount
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Монеты игрока {player_name} (ID: {target_low_id}) успешно назначены {amount} монет. Было баланс: {old_gold}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при установке монет:</c>\n{str(e)}")

    def remove_player_gold(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_gold = player_data.get('gold', 0)
                    new_gold = max(0, old_gold - amount)
                    player_data['gold'] = new_gold
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Монеты игрока {player_name} (ID: {target_low_id}) успешно забраны -{amount} монет. Новый баланс: {new_gold}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при снятии монет:</c>\n{str(e)}")

    def add_player_tickets(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_tickets = player_data.get('tickets', 0)
                    new_tickets = old_tickets + amount
                    player_data['tickets'] = new_tickets
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Билеты игрока {player_name} (ID: {target_low_id}) успешно выданы +{amount} билетов. Новый баланс: {new_tickets}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при выдаче билетов:</c>\n{str(e)}")

    def set_player_tickets(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_tickets = player_data.get('tickets', 0)
                    player_data['tickets'] = amount
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Билеты игрока {player_name} (ID: {target_low_id}) успешно назначены {amount} билетов. Было баланс: {old_tickets}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при установке билетов:</c>\n{str(e)}")

    def remove_player_tickets(self, target_low_id, amount):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_tickets = player_data.get('tickets', 0)
                    new_tickets = max(0, old_tickets - amount)
                    player_data['tickets'] = new_tickets
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Билеты игрока {player_name} (ID: {target_low_id}) успешно забраны -{amount} билетов. Новый баланс: {new_tickets}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при снятии билетов:</c>\n{str(e)}")

    def reset_player_resources(self, target_low_id):
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            players = cursor.fetchall()
            
            player_found = False
            for token, info_json in players:
                player_data = json.loads(info_json)
                if str(player_data.get('lowID')) == str(target_low_id):
                    old_gems = player_data.get('gems', 0)
                    old_gold = player_data.get('gold', 0)
                    old_tickets = player_data.get('tickets', 0)
                    
                    player_data['gold'] = 0
                    player_data['gems'] = 0
                    player_data['tickets'] = 0
                    player_data['tokensdoubler'] = 0
                    player_data['winstreak'] = 0
                    player_data['brawlBoxes'] = 0
                    player_data['bigBoxes'] = 0
                    player_data['vip'] = 0
                    player_data['viptime'] = "0"
                    player_data['title'] = "ОТСУТСТВУЕТ"
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_data), token))
                    
                    player_name = player_data.get('name', 'Unknown')
                    self.bot_msg = self.add_time_stamp(f"<c3>Ресурсы игрока {player_name} (ID: {target_low_id}) успешно сброшены!\nБыло: Кристаллы: {old_gems}, Монеты: {old_gold}, Билеты: {old_tickets}</c>")
                    player_found = True
                    break
            
            conn.commit()
            conn.close()
            
            if not player_found:
                self.bot_msg = self.add_time_stamp(f"<c7>Игрок с ID {target_low_id} не найден!</c>")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"<c2>Ошибка при сбросе ресурсов игрока:</c>\n{str(e)}")

    def validate_password(self, password):
        if len(password) < 8:
            return False, "Пароль должен содержать минимум 8 символов\nПовторите попытку."
        if not any(char.isdigit() for char in password):
            return False, "Пароль должен содержать хотя бы одну цифру\nПовторите попытку."
        return True, ""

    def register_account(self, low_id, password, confirm_password):
        if password != confirm_password:
            self.bot_msg = self.add_time_stamp("Пароли не совпадают!\nПовторите попытку.")
            return
        
        is_valid, error_msg = self.validate_password(password)
        if not is_valid:
            self.bot_msg = self.add_time_stamp(error_msg)
            return
        
        try:
            low_id_int = int(low_id)
            if low_id_int != self.player.low_id:
                self.bot_msg = self.add_time_stamp("Неверный ID! Вы можете зарегистрировать только свой аккаунт\nПовторите попытку.")
                return
        except:
            self.bot_msg = self.add_time_stamp("Неверный формат ID!\nПовторите попытку.")
            return
        
        try:
            try:
                with open("JSON/login.json", "r") as f:
                    data = json.load(f)
            except:
                data = {}
            
            for account_id in data:
                if str(data[account_id]["lowID"]) == str(low_id):
                    self.bot_msg = self.add_time_stamp("Аккаунт с таким ID уже зарегистрирован!\nПовторите попытку.")
                    return
            
            new_index = str(len(data))
            data[new_index] = {
                "lowID": str(self.player.low_id),
                "Token": self.player.token,
                "Password": password
            }
            
            with open("JSON/login.json", "w") as f:
                json.dump(data, f, indent=4)
            
            self.bot_msg = self.add_time_stamp("<c3>Аккаунт успешно зарегистрирован!</c>")
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"Ошибка при регистрации аккаунта: {str(e)}\n\nОбратитесь в поддержку сервера.")

    def login_account(self, low_id, password):
        try:
            try:
                with open("JSON/login.json", "r") as f:
                    login_data = json.load(f)
            except:
                self.bot_msg = self.add_time_stamp("<c2>Файл с зарегистрированными пользователями не найден!</c>")
                return
            
            target_account = None
            target_index = None
            for account_id in login_data:
                if (str(login_data[account_id]["lowID"]) == str(low_id) and 
                    login_data[account_id]["Password"] == password):
                    target_account = login_data[account_id]
                    target_index = account_id
                    break
             
            if not target_account:
                self.bot_msg = self.add_time_stamp("<c7>Неверный ID или пароль!</c>")
                return
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players WHERE info LIKE ?", (f'%"lowID": {low_id}%',))
            target_result = cursor.fetchone()
            
            cursor.execute("SELECT token, info FROM players WHERE token=?", (str(self.player.token),))
            current_result = cursor.fetchone()
            
            if not target_result or not current_result:
                self.bot_msg = self.add_time_stamp("<c7>Один из аккаунтов не найден!</c>")
                conn.close()
                return
            
            target_token, target_info_json = target_result
            current_token, current_info_json = current_result
            
            target_data = json.loads(target_info_json)
            current_data = json.loads(current_info_json)
            
            cursor.execute("UPDATE players SET info=? WHERE token=?", (json.dumps(target_data), current_token))
            cursor.execute("UPDATE players SET info=? WHERE token=?", (json.dumps(current_data), target_token))
            
            conn.commit()
            conn.close()
            
            login_data[target_index]["Token"] = current_token
            login_data[target_index]["lowID"] = str(self.player.low_id)
            
            for account_id in login_data:
                if str(login_data[account_id]["lowID"]) == str(low_id):
                    login_data[account_id]["lowID"] = str(self.player.low_id)
                elif str(login_data[account_id]["lowID"]) == str(self.player.low_id):
                    login_data[account_id]["lowID"] = str(low_id)
            
            with open("JSON/login.json", "w") as f:
                json.dump(login_data, f, indent=4)
                
            account_name = target_data["name"]
            ban_status = target_data.get("ban", 0)
            vip_status = target_data.get("vip", 0)

            if ban_status > 0:
                ban_info = ""
                if ban_status == 1:
                    ban_end_date = target_data.get("bantime", "НЕИЗВЕСТНО")
                    try:
                        ban_date = datetime.strptime(ban_end_date, "%d.%m.%Y")
                        today = datetime.now()
                        if ban_date > today:
                            days_left = (ban_date - today).days + 1
                            ban_info = f"⟩⟩ АККАУНТ ЗАБЛОКИРОВАН! ОСТАЛОСЬ: {days_left} ДНЕЙ\n"
                        else:
                            DataBase.replaceValue(self, 'ban', 0)
                            DataBase.replaceValue(self, 'bantime', "0")
                            ban_status = 0
                    except:
                        ban_info = "⟩⟩ АККАУНТ ЗАБЛОКИРОВАН! СРОК НЕИЗВЕСТЕН\n"
                elif ban_status == 2:
                    ban_info = "⟩⟩ АККАУНТ ЗАБЛОКИРОВАН НАВСЕГДА!\n"
                
                if ban_status != 0:
                    vip_info = ""
                    if vip_status > 0:
                        if vip_status == 1:
                            vip_end_date = target_data.get("viptime", "НЕИЗВЕСТНО")
                            vip_info = f"⟩⟩ VIP ДЕЙСТВУЕТ ДО: {vip_end_date}\n"
                        elif vip_status == 2:
                            vip_info = "⟩⟩ VIP ДЕЙСТВУЕТ: БЕССРОЧНО\n"
                    
                    message = (
                        f"ВОЙТИ НА АККАУНТ НЕ УДАЛОСЬ!\n\n"
                        f"⟩⟩ ИМЯ: [BAN] {account_name}\n"
                        f"{ban_info}"
                        f"{vip_info}"
                        f"⟩⟩ ID: {low_id}\n"
                        f"⟩⟩ ТРОФЕИ: {target_data['trophies']}\n"
                        f"⟩⟩ КРИСТАЛЛЫ: {target_data['gems']}\n"
                        f"⟩⟩ МОНЕТЫ: {target_data['gold']}\n\n"
                        f"Обратитесь в поддержку сервера, если считаете блокировку ошибочной.\n\n"
                        f"ДАТА: {datetime.now().strftime('%H:%M:%S | %d.%m.%Y')}\n\n"
                        f"Перезайдите в игру."
                    )
                    
                    self.player.err_code = 1
                    LoginFailedMessage(self.client, self.player, message).send()
                    return

            vip_info = ""
            if vip_status > 0:
                if vip_status == 1:
                    vip_end_date = target_data.get("viptime", "НЕИЗВЕСТНО")
                    vip_info = f"⟩⟩ VIP ДЕЙСТВУЕТ ДО: {vip_end_date}\n"
                elif vip_status == 2:
                    vip_info = "⟩⟩ VIP ДЕЙСТВУЕТ: БЕССРОЧНО\n"

            formatted_name = f"[VIP] {account_name}" if vip_status > 0 else account_name

            message = (
                f"ВЫ УСПЕШНО ВОШЛИ НА АККАУНТ!\n\n"
                f"⟩⟩ ИМЯ: {formatted_name}\n"
                f"{vip_info}"
                f"⟩⟩ ID: {low_id}\n"
                f"⟩⟩ ТРОФЕИ: {target_data['trophies']}\n"
                f"⟩⟩ КРИСТАЛЛЫ: {target_data['gems']}\n"
                f"⟩⟩ МОНЕТЫ: {target_data['gold']}\n\n"
                f"ДАТА: {datetime.now().strftime('%H:%M:%S | %d.%m.%Y')}\n\n"
                f"Перезайдите в игру."
            )

            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, message).send()

        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"Ошибка при входе на аккаунт: {str(e)}\n\nОбратитесь в поддержку сервера.")

    def reset_password(self, old_password, new_password, confirm_password):
        if new_password != confirm_password:
            self.bot_msg = self.add_time_stamp("Новые пароли не совпадают!\nПовторите попытку.")
            return
        
        is_valid, error_msg = self.validate_password(new_password)
        if not is_valid:
            self.bot_msg = self.add_time_stamp(error_msg)
            return
        
        try:
            with open("JSON/login.json", "r") as f:
                data = json.load(f)
            
            account_found = False
            for account_id in data:
                if str(data[account_id]["lowID"]) == str(self.player.low_id):
                    if data[account_id]["Password"] == old_password:
                        data[account_id]["Password"] = new_password
                        account_found = True
                        break
                    else:
                        self.bot_msg = self.add_time_stamp("Неверный текущий пароль!\nПовторите попытку.")
                        return
            
            if not account_found:
                self.bot_msg = self.add_time_stamp("Аккаунт не найден!\nПовторите попытку.")
                return
            
            with open("JSON/login.json", "w") as f:
                json.dump(data, f, indent=4)
            
            self.bot_msg = self.add_time_stamp("<c3>Пароль успешно изменен!</c>")
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"Ошибка при смене пароля: {str(e)}\n\nОбратитесь в поддержку сервера.")

    def unregister_account(self, password):
        try:
            with open("JSON/login.json", "r") as f:
                data = json.load(f)
            
            account_found = False
            for account_id in list(data.keys()):
                if (str(data[account_id]["lowID"]) == str(self.player.low_id) and 
                    data[account_id]["Password"] == password):
                    del data[account_id]
                    account_found = True
                    break
            
            if not account_found:
                self.bot_msg = self.add_time_stamp("Неверный пароль или аккаунт не найден!\nПовторите попытку.")
                return
            
            with open("JSON/login.json", "w") as f:
                json.dump(data, f, indent=4)
            
            self.bot_msg = self.add_time_stamp("<c3>Аккаунт успешно отвязан!</c>")
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"Ошибка при отвязке аккаунта: {str(e)}\n\nОбратитесь в поддержку сервера.")

    def show_help(self):
        if self.player.admin == 1:
            self.bot_msg = self.add_time_stamp(
                "<c3>Доступные команды:</c>\n\n"
                " /register «ID» «пароль» «повторить пароль» - Зарегистрировать аккаунт\n"
                " /login «ID» «пароль» - Войти на аккаунт\n"
                " /unregister «пароль» - Отвязать аккаунт\n"
                " /resetpassword «старый пароль» «новый пароль» «повторить пароль» - Сменить пароль\n"
                " /myaccount - Показать информацию о вашем аккаунте\n"
                " /promo «код» - Активировать промокод\n"
                " /help - Показать это сообщение\n\n\n"
                "<c4>Админ-команды:</c>\n\n"
                " /snos «ID» - Удалить аккаунт игрока\n"
                " /reset «ID» - Сбросить ресурсы игрока\n"
                " /theme «ID темы» - Изменить тему сервера\n"
                " /addgems «ID» «кол-во» - Выдать кристаллы игроку\n"
                " /setgems «ID» «кол-во» - Установить кристаллы игроку\n"
                " /ungems «ID» «кол-во» - Забрать кристаллы игрока\n"
                " /addgold «ID» «кол-во» - Выдать монеты игроку\n"
                " /setgold «ID» «кол-во» - Установить монеты игроку\n"
                " /ungold «ID» «кол-во» - Забрать монеты игрока\n"
                " /addtickets «ID» «кол-во» - Выдать билеты игроку\n"
                " /settickets «ID» «кол-во» - Установить билеты игроку\n"
                " /untickets «ID» «кол-во» - Забрать билеты игрока\n"
                " /addtrophies «ID» «ID бойца» «кол-во» - Добавить трофеи бойцу\n"
                " /settrophies «ID» «ID бойца» «кол-во» - Установить трофеи бойцу\n"
                " /untrophies «ID» «ID бойца» «кол-во» - Убрать трофеи бойца\n"
                " /addboxes «ID» «малые ящики» - Выдать малые ящики\n"
                " /setboxes «ID» «малые ящики» - Установить малые ящики\n"
                " /unboxes «ID» «малые ящики» - Забрать малые ящики\n"
                " /addbigboxes «ID» «большие ящики» - Выдать большие ящики\n"
                " /setbigboxes «ID» «большие ящики» - Установить большие ящики\n"
                " /unbigboxes «ID» «большие ящики» - Забрать большие ящики\n"
                " /ban «ID» «дни» - Забанить игрока\n"
                " /unban «ID» - Разбанить игрока\n"
                " /vip «ID» «дни» - Выдать VIP\n"
                " /info «ID» - Информация об игроке\n"
                " /serverinfo - Информация о сервере\n"
                " /addadmin «ID» - Выдать админа\n"
                " /unadmin «ID» - Забрать админа\n"
                " /addskin «ID» «ID скина» - Выдать скин\n"
                " /unskin «ID» «ID скина» - Забрать скин\n"
                " /addbrawler «ID» «ID бойца» - Выдать бойца\n"
                " /unbrawler «ID» «ID бойца» - Забрать бойца"
            )
        else:
            self.bot_msg = self.add_time_stamp(
                "<c3>Доступные команды:</c>\n\n"
                " /register «ID» «пароль» «повторить пароль» - Зарегистрировать аккаунт\n"
                " /login «ID» «пароль» - Войти на аккаунт\n"
                " /unregister «пароль» - Отвязать аккаунт\n"
                " /resetpassword «старый пароль» «новый пароль» «повторить пароль» - Сменить пароль\n"
                " /myaccount - Показать информацию о вашем аккаунте\n"
                " /promo «код» - Активировать промокод\n"
                " /help - Показать это сообщение"
            )

    def get_brawler_name(self, brawler_id):
        return self.brawler_names.get(brawler_id, None)

    def get_skin_name(self, skin_id):
        return self.skin_names.get(skin_id, None)

    def process_promo_code(self, promo_code):
        try:
            with open("JSON/promocode.json", "r") as f:
                data = json.load(f)
            
            found = False
            for i in data:
                if data[i]["Promo"] == promo_code:
                    found = True

                    if promo_code == "VIP" and self.player.vip == 0:
                    	self.bot_msg = self.add_time_stamp(f"ПРОМОКОД: «VIP» НЕДОСТУПЕН ДЛЯ ВАС!")
                    	return                    	
                    	
                    if self.player.low_id in data[i]["WhoBuyed"]:
                        self.bot_msg = self.add_time_stamp(f"ПРОМОКОД: «{promo_code}» УЖЕ БЫЛ РАНЕЕ ИСПОЛЬЗОВАН!")
                        return
                    
                    if data[i]["MaxUses"] <= 0:
                        self.bot_msg = self.add_time_stamp(f"ПРОМОКОД: «{promo_code}» БОЛЬШЕ НЕ ДЕЙСТВИТЕЛЕН!")
                        return                      
                    
                    reward_ids = data[i]["ID"]
                    multipliers = data[i]["Multiplier"]
                    brawler_ids = data[i]["BrawlerID"]
                    skin_ids = data[i]["SkinID"]
                    
                    if not (len(reward_ids) == len(multipliers) == len(brawler_ids) == len(skin_ids)):
                        self.bot_msg = self.add_time_stamp("ОШИБКА: НЕСООТВЕТСТВИЕ КОЛИЧЕСТВА НАГРАД В ПРОМОКОДЕ!\n\nОбратитесь в поддержку сервера.")
                        return
                    
                    rewards_info = []
                    reward_count = 1
                    
                    for j in range(len(reward_ids)):
                        reward_id = reward_ids[j]
                        multiplier = multipliers[j]
                        brawler_id = brawler_ids[j]
                        skin_id = skin_ids[j]
                        reward_type = ""
                        reward_amount = 0
                        
                        if multiplier == 0:
                            continue
                            
                        if reward_id == 0:
                            DataBase.replaceValue(self, 'gems', self.player.gems + multiplier)
                            reward_type = "КРИСТАЛЛОВ"
                            reward_amount = multiplier
                            
                        elif reward_id == 1:
                            DataBase.replaceValue(self, 'gold', self.player.gold + multiplier)
                            reward_type = "МОНЕТ"
                            reward_amount = multiplier
                            
                        elif reward_id == 2:
                            DataBase.replaceValue(self, 'tickets', self.player.tickets + multiplier)
                            reward_type = "БИЛЕТОВ"
                            reward_amount = multiplier
                            
                        elif reward_id == 3:
                            DataBase.replaceValue(self, 'tokensdoubler', self.player.tokensdoubler + multiplier)
                            reward_type = "УДВОИТЕЛЕЙ"
                            reward_amount = multiplier
                            
                        elif reward_id == 4:
                            DataBase.replaceValue(self, 'brawlBoxes', self.player.brawl_boxes + multiplier)
                            reward_type = "МАЛЕНЬКИХ ЯЩИКОВ"
                            reward_amount = multiplier // 100
                            
                        elif reward_id == 5:
                            DataBase.replaceValue(self, 'bigBoxes', self.player.big_boxes + multiplier)
                            reward_type = "БОЛЬШИХ ЯЩИКОВ"
                            reward_amount = multiplier // 10
                                                
                        elif reward_id == 6:
                            if brawler_id == 0:
                                continue
                                
                            brawler_name = self.get_brawler_name(brawler_id)
                            if not brawler_name:
                                continue
                            
                            if str(brawler_id) in self.player.BrawlersUnlockedState and self.player.BrawlersUnlockedState[str(brawler_id)] == 1:
                                continue
                            
                            self.player.BrawlersUnlockedState[str(brawler_id)] = 1
                            DataBase.replaceValue(self, 'UnlockedBrawlers', self.player.BrawlersUnlockedState)
                            reward_type = f"БОЙЦА «{brawler_name}»"
                            reward_amount = 1
                            
                        elif reward_id == 7:
                            if skin_id == 0:
                                continue
                                
                            skin_name = self.get_skin_name(skin_id)
                            if not skin_name:
                                continue
                            
                            if skin_id in self.player.UnlockedSkins:
                                continue
                            
                            self.player.UnlockedSkins.append(skin_id)
                            DataBase.replaceValue(self, 'UnlockedSkins', self.player.UnlockedSkins)
                            reward_type = f"СКИН «{skin_name}»"
                            reward_amount = 1
                            
                        elif reward_id == 8:
                            try:
                                with open(os.path.join('JSON', 'titles.json'), 'r', encoding='utf-8') as file:
                                    titles_data = json.load(file)
                                    title_options = [title['gradient'] for title in titles_data['titles']]
                            except Exception as e:
                                print(f"Ошибка при чтении titles.json: {e}")
                                title_options = ["ОТСУТСТВУЕТ"]
                                
                            if brawler_id > 0 and brawler_id < len(title_options):
                                random_title = title_options[brawler_id]
                            else:
                                random_title = random.choice(title_options)
                            self.player.title = random_title
                            DataBase.replaceValue(self, 'title', self.player.title)
                            clean_title = re.sub('<.*?>', '', random_title)
                            reward_amount = 1
                            
                        elif reward_id == 9:
                            if self.player.vip == 2:
                                continue
                                
                            current_date = datetime.now()
                            if self.player.vip == 0:
                                vip_end_date = (current_date + timedelta(days=multiplier)).strftime("%d.%m.%Y")
                                DataBase.replaceValue(self, 'vip', 1)
                                DataBase.replaceValue(self, 'viptime', vip_end_date)
                            elif self.player.vip == 1:
                                try:
                                    vip_end_date = datetime.strptime(self.player.viptime, "%d.%m.%Y")
                                    new_end_date = vip_end_date + timedelta(days=multiplier)
                                    vip_end_date = new_end_date.strftime("%d.%m.%Y")
                                    DataBase.replaceValue(self, 'viptime', vip_end_date)
                                except:
                                    vip_end_date = (current_date + timedelta(days=multiplier)).strftime("%d.%m.%Y")
                                    DataBase.replaceValue(self, 'viptime', vip_end_date)
                            
                            reward_type = "VIP-СТАТУСА"
                            reward_amount = f"{multiplier} ДНЕЙ (ДО {vip_end_date})"
                        
                        if reward_id not in [6, 7, 9] or (reward_id in [6, 7] and reward_type):
                            rewards_info.append(f"{reward_count}] ВЫ ПОЛУЧИЛИ: {reward_amount} {reward_type}")
                        reward_count += 1
                        
                    if not rewards_info:
                        self.bot_msg = self.add_time_stamp(f"ПРОМОКОД: «{promo_code}» НЕ СОДЕРЖИТ ДОСТУПНЫХ ДЛЯ ВАС НАГРАД!")
                        return
                        
                    data[i]["WhoBuyed"].append(int(self.player.low_id))
                    data[i]["MaxUses"] -= 1
                    with open("JSON/promocode.json", "w") as f:
                    	json.dump(data, f)             
                    	
                    
                    self.player.err_code = 1
                    message = f"ПРОМОКОД «{promo_code}» АКТИВИРОВАН УСПЕШНО!\n" + "\n".join(rewards_info) + f"\n\n{self.get_current_time()}\n\nПожалуйста перезайдите в игру."
                    LoginFailedMessage(self.client, self.player, message).send()
                    return
            
            if not found:
                self.bot_msg = self.add_time_stamp(f"ПРОМОКОД: «{promo_code}» НЕ СУЩЕСТВУЕТ!")
                
        except Exception as e:
            self.bot_msg = self.add_time_stamp(f"ОШИБКА ПРИ ОБРАБОТКЕ ПРОМОКОДА «{promo_code}»! {e}\n\nОбратитесь в поддержку сервера если останутся вопросы. Мы будем рады вам помочь.")

    def process(self):
        
        if not self.IsAcmd and not self.msg.startswith('/'):
            try:
                DataBase.GetmsgCount(self, self.player.club_low_id)
                DataBase.AddMessage(self, self.player.club_low_id, 0, 2, 0, self.player.low_id, self.player.name, self.player.club_role, self.msg)
                DataBase.GetmsgCount(self, self.player.club_low_id)
                DataBase.loadClub(self, self.player.club_low_id)
                for member_id in self.plrids:
                    AllianceChatServerMessage(self.client, self.player, self.msg).sendWithLowID(member_id)
            except Exception as e:
                print(f"[ОШИБКА] Ошибка при отправке сообщения: {e}")

        if self.bot_msg != '':  # Ответ бота
            try:
                AllianceBotChatServerMessage(self.client, self.player, self.bot_msg).send()
                print()
            except Exception as e:
                print(f"[ОШИБКА] Ошибка при отправке ответа бота: {e}")

        if self.send_ofs:  # Требуется перезагрузка
            try:
                OutOfSyncMessage(self.client, self.player, 'Изменения были применены!\n\nПерезайдите в игру!').send()
            except Exception as e:
                print(f"[ОШИБКА] Ошибка при отправке OutOfSync: {e}")