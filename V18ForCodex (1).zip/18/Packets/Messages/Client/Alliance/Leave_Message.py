from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from random import choice
from string import ascii_uppercase
import json
import sqlite3

from Logic.Player import Players
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.Events.AllianceLeaveOkMessage import AllianceLeaveOkMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage

from Utils.Reader import BSMessageReader


class Leave_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.db = DataBase(player)

    def decode(self):
        pass

    def process(self):
        try:           
            # Загружаем данные клуба
            DataBase.loadClub(self, self.player.club_low_id)

            # Удаляем игрока из клуба
            if self.clubmembercount == 1:
                DataBase.AddMember(self, self.player.club_low_id, self.player.low_id, self.player.name, 0)                
                try:
                    conn = sqlite3.connect('Database/Club/chat.db')
                    cursor = conn.cursor()
                    cursor.execute("DELETE FROM chats WHERE clubID=?", (self.player.club_low_id,))
                    conn.commit()
                    conn.close()
                except Exception as e:
                    print(f"[ERROR] Ошибка при удалении чата клуба: {e}")
                    
            else:
                # Удаляем только игрока из клуба
                DataBase.AddMember(self, self.player.club_low_id, self.player.low_id, self.player.name, 2)
                
                # Добавляем сообщение о выходе в чат клуба
                DataBase.GetmsgCount(self, self.player.club_low_id)
                DataBase.AddMessage(self, self.player.club_low_id, self.MessageCount + 1, 4, 0, self.player.low_id, self.player.name, self.player.club_role, f"{self.player.name} покинул клуб")

            # Обновляем данные игрока
            self.player.last_seen_message_id = 0
            self.db.replaceValue('last_seen_message_id', 0)
            old_club_id = self.player.club_low_id
            DataBase.replaceValue(self, 'clubID', 0)
            self.player.club_low_id = 0
            DataBase.replaceValue(self, 'clubRole', 0)
            self.player.club_role = 0

            # Отправляем сообщения клиенту
            AllianceLeaveOkMessage(self.client, self.player).send()
            MyAllianceMessage(self.client, self.player, 0).send()

            # Уведомляем других участников клуба (если клуб не удален)
            if self.clubmembercount > 1:
                for player_id in self.plrids:
                    if player_id != self.player.low_id:  # Не отправляем себе
                        try:
                            AllianceDataMessage(self.client, self.player, 0, old_club_id).sendWithLowID(player_id)
                            AllianceChatServerMessage(self.client, self.player, 4).sendWithLowID(player_id)
                        except Exception as e:
                        	return

        except Exception as e:
            import traceback
            traceback.print_exc()