from time import daylight
from random import choice
from string import ascii_uppercase
import json

from Logic.Player import Players
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.Events.AllianceJoinOkMessage import AllianceJoinOkMessage
from Database.DatabaseManager import DataBase
from Utils.Helpers import Helpers

from Utils.Reader import BSMessageReader


class Create_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.db = DataBase(player)

    def decode(self):
        # ClubID
        self.clubHighID = 0
        self.clubLowID = Helpers.randomClubID(self)

        # Info
        self.clubName           = self.read_string()    # Club name 
        self.clubdescription    = self.read_string()    # Club description

        # Badge
        self.BadgeIdentifier    = self.read_Vint()      # Badge Identifier
        self.clubbadgeID        = self.read_Vint()      # BadgeID

        # Region
        self.RegionIdentifier   = self.read_Vint()      # Region Identifier
        self.clubregionID       = self.read_Vint()      # RegionID 

        # Settings
        self.clubtype           = self.read_Vint()      # Type
        self.clubtrophiesneeded = self.read_Vint()      # Trophy required
        self.clubfriendlyfamily = self.read_Vint()      # Family friendly

    def process(self):
        try:
            print(f"[DEBUG] Создание клуба: {self.clubName}, ID: {self.clubLowID}")
            
            # Обновляем данные игрока
            DataBase.replaceValue(self, 'clubID', self.clubLowID)
            self.player.club_low_id = self.clubLowID
            DataBase.replaceValue(self, 'clubRole', 2)
            self.player.club_role = 2

            # Устанавливаем данные для создания клуба
            self.player.clubName = self.clubName
            self.player.clubdescription = self.clubdescription
            self.player.clubbadgeID = self.clubbadgeID
            self.player.clubtype = self.clubtype
            self.player.clubtrophiesneeded = self.clubtrophiesneeded
            self.player.clubfriendlyfamily = self.clubfriendlyfamily

            # Создаем клуб
            self.player.last_seen_message_id = 0
            self.db.replaceValue('last_seen_message_id', 0)
            DataBase.createClub(self, self.clubLowID)
            print(f"[DEBUG] Клуб создан успешно")

            # Отправляем подтверждение
            AllianceJoinOkMessage(self.client, self.player).send()
            MyAllianceMessage(self.client, self.player, self.clubLowID).send()
            AllianceStreamMessage(self.client, self.player, self.clubLowID, 0).send()
            
            print(f"[DEBUG] Все сообщения отправлены")

        except Exception as e:
            print(f"[ОШИБКА] Ошибка при создании клуба: {e}")
            import traceback
            traceback.print_exc()