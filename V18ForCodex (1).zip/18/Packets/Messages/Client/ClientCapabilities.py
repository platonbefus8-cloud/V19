from Packets.LobbyInfoMessage import LobbyInfoMessage
from Utils.Reader import BSMessageReader


class ClientCapabilities(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.Latency = self.read_Vint()

    def process(self):
        LobbyInfoMessage(self.client, self.player, 0).send()