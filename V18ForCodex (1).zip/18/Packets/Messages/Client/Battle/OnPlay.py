from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Client.Gameroom.TeamCreateMessage import TeamCreateMessage
from Logic.EventSlots import EventSlots
from Database.DatabaseManager import DataBase
import random, time
from Utils.Reader import BSMessageReader

from Packets.Messages.Server.Gameroom.TeamGameStartingMessage import TeamGameStartingMessage


class OnPlay(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):
        print("CALL: OnPlay")
        self.read_Vint()
        self.CardID = self.read_Vint()

        self.read_Vint()
        self.MapIndex = self.read_Vint()

        print("OnPlay: CardID =", self.CardID, "MapIndex =", self.MapIndex)

    def process(self):
        self.roomType = 1
        self.player.room_id = random.randint(0, 2147483647)
        DataBase.replaceValue(self, 'roomID', self.player.room_id)
        data = EventSlots.loadEvents(self)
        self.player.map_id = data[str(self.MapIndex - 1)]['ID']
        DataBase.createGameroomDB(self)
        time.sleep(0.1)
        TeamGameroomDataMessage(self.client, self.player).send()
