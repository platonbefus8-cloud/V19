from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import json

class GetLeaderboardGlobalOkMessage(Writer):

    def __init__(self, client, player, players):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.players = players

    def rainbow_text(self, text):
        rainbow_colors = [
            '<cFF0000>', # красный
            '<cFF7F00>', # оранжевый
            '<cFFFF00>', # желтый
            '<c00FF00>', # зеленый
            '<c0000FF>'  # синий
        ]
        colored_text = ""
        for i, char in enumerate(text):
            color = rainbow_colors[i % len(rainbow_colors)]
            colored_text += f"{color}{char}</c>"
        return colored_text

    def get_special_ids(self):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
                return config.get("special_ids", []) or []
        except Exception as e:
            print(f"Error reading config.json: {e}")
            return []

    def encode(self):
        self.indexOfPlayer = 1
        
        # Ограничиваем количество игроков до 200
        displayed_players = self.players[:200]
        
        # Находим реальную позицию игрока в общем рейтинге и его данные
        current_player_data = None
        for i, player in enumerate(self.players):
            if player["lowID"] == self.player.low_id:
                self.indexOfPlayer = i + 1
                current_player_data = player
                break

        self.writeVint(1)
        self.writeVint(0) # SCID
        self.writeString()

        self.writeVint(len(displayed_players)) # Players Count

        special_ids = self.get_special_ids()

        for player in displayed_players:
            self.writeVint(0) # High ID
            self.writeVint(player["lowID"]) # Low ID

            self.writeVint(1)
            self.writeVint(player['trophies']) # Player Trophies

            self.writeVint(1)
            
            # Загружаем данные клуба
            club_name = ""
            if player["clubID"] != 0:
                db = DataBase()
                club_data = db.loadClub(player["clubID"])
                if club_data:
                    club_name = club_data.get("name", "")
            
            # Формируем строку с информацией о клубе и префиксе
            club_info = ""
            if club_name:
                club_info = f"КЛУБ: <c3>{club_name}</c>"
            
            title_info = ""
            if player.get('title') and player['title'] != "ОТСУТСТВУЕТ":
                title_info = f"ПРЕФИКС: {player['title']}"
            
            online = "<cFF0000>■</c>"
            if player.get('online') == 1:
                online = "<c00FFFF>■</c>"
            
            # Объединяем информацию о клубе и префиксе
            if club_info and title_info:
                self.writeString(f"{club_info} | {title_info}")
            elif club_info:
                self.writeString(f"{club_info}")
            elif title_info:
                self.writeString(f"{title_info}")
            else:
                self.writeString()
            
            is_special_id = player['lowID'] in special_ids
            
            if player.get('ban', 0) > 0:
                ban_gradient = (
                    f"<cFF0000>[</c>"
                    f"<cFF3333>B</c>"
                    f"<cCC0000>A</c>"
                    f"<cFF0000>N</c>"
                    f"<cFF3333>] </c> " 
                )
                name_to_display = self.rainbow_text(player['name']) if is_special_id else player['name']
                self.writeString(f"{online} " + ban_gradient + name_to_display)
            elif player.get('admin', 0) > 0:
                admin_gradient = (
                    f"<c6A0DAD>[</c>"
                    f"<c8A2BE2>A</c>"
                    f"<c9932CC>D</c>"
                    f"<c6A0DAD>M</c>"
                    f"<c6A0DAD>] </c> "
                )
                name_to_display = self.rainbow_text(player['name']) if is_special_id else player['name']
                self.writeString(f"{online} " + admin_gradient + name_to_display)
            elif player.get('vip', 0) > 0:
                vip_gradient = (
                    f"<cFFD700>[</c>"
                    f"<cFFC000>V</c>"
                    f"<cFFEE00>I</c>"
                    f"<cFFD700>P</c>"
                    f"<cFFC000>] </c> "
                )
                name_to_display = self.rainbow_text(player['name']) if is_special_id else player['name']
                self.writeString(f"{online} " + vip_gradient + name_to_display)
            else:
                name_to_display = self.rainbow_text(player['name']) if is_special_id else player['name']
                self.writeString(f"{online} " + name_to_display)
                          
            self.writeVint(player.get('playerExp', 1)) # Player Level
            self.writeVint(28000000 + player.get('profileIcon', 0))
            self.writeVint(43000000 + player.get("namecolor", 0))
            self.writeVint(0)

        self.writeVint(0)
        self.writeVint(self.indexOfPlayer)  # Реальная позиция игрока (даже если не в топ-200)
        self.writeVint(1)
        self.writeVint(0) # Leaderboard global TID
        
        # Отправляем информацию о клубе, префиксе и онлайне текущего игрока
        if current_player_data:
            club_name = ""
            if current_player_data["clubID"] != 0:
                db = DataBase()
                club_data = db.loadClub(current_player_data["clubID"])
                if club_data:
                    club_name = club_data.get("name", "")
            
            club_info = ""
            if club_name:
                club_info = f"КЛУБ: <c3>{club_name}</c>"
            
            title_info = ""
            if current_player_data.get('title') and current_player_data['title'] != "ОТСУТСТВУЕТ":
                title_info = f"ПРЕФИКС: {current_player_data['title']}"
            
            online = "Offline"
            if current_player_data.get('online') == 1:
                online = "<c00FFFF>Online</c>"
                        
        self.writeString("RU")