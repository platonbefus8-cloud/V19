from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import json
import sqlite3

class BrawlerLeaderLocal(Writer):
    def __init__(self, client, player, ID):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.brawler = ID

    def rainbow_text(self, text):
        rainbow_colors = [
            '<cFF0000>', # красный
            '<cFF7F00>', # оранжевый
            '<cFFFF00>', # желтый
            '<c00FF00>', # зеленый
            '<c0000FF>'  # синий
        ]
        colored_text = ""
        for i, char in enumerate(text):
            color = rainbow_colors[i % len(rainbow_colors)]
            colored_text += f"{color}{char}</c>"
        return colored_text

    def get_special_ids(self):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
                return config.get("special_ids", []) or []
        except Exception as e:
            print(f"Error reading config.json: {e}")
            return []

    def get_players_from_database(self):
        """Получаем всех игроков напрямую из базы данных"""
        try:
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            players_data = []
            
            # Получаем всех игроков из базы
            cursor.execute("SELECT info FROM players")
            all_players = cursor.fetchall()
            
            for player_info_json, in all_players:
                try:
                    player_info = json.loads(player_info_json)
                    
                    # Получаем трофеи указанного бойца
                    brawler_trophies = player_info.get('brawlersTrophies', {})
                    current_brawler_trophies = brawler_trophies.get(str(self.brawler), 0)
                    
                    # Включаем только игроков с трофеями этого бойца
                    if current_brawler_trophies > 0:
                        players_data.append([
                            player_info.get('lowID', 0),           # lowID
                            player_info.get('name', 'Player'),     # name
                            player_info,                           # full info
                            player_info.get('profileIcon', 0),     # profileIcon
                            player_info.get('namecolor', 0),       # namecolor
                            player_info.get('clubID', 0),          # clubID
                            current_brawler_trophies               # brawler trophies
                        ])
                except Exception as e:
                    print(f"[ERROR] Error processing player data: {e}")
                    continue
            
            conn.close()
            return players_data
            
        except Exception as e:
            print(f"[ERROR] Error reading from database: {e}")
            return []

    def get_club_name(self, club_id):
        """Получаем название клуба по ID"""
        if club_id == 0:
            return ""
        
        try:
            db_instance = DataBase(self.player)
            club_data = db_instance.loadClub(club_id)
            if club_data:
                return club_data.get('name', '')
        except Exception as e:
            print(f"[ERROR] Error getting club name for {club_id}: {e}")
        
        return ""

    def encode(self):
        self.indexOfPlayer = 1
        self.writeVint(0)
        self.writeVint(0)
        self.writeScId(16, self.brawler)
        self.writeString(self.player.Region)

        # Получаем данные напрямую из базы
        players_data = self.get_players_from_database()
        
        # Сортируем по трофеям бойца (по убыванию)
        players_data.sort(key=lambda x: x[6], reverse=True)  # x[6] - это трофеи бойца

        # Ограничиваем количество игроков до 100
        displayed_players = players_data[:100]

        self.writeVint(len(displayed_players))  # Записываем количество игроков

        special_ids = self.get_special_ids()

        # Перебираем игроков и записываем их данные
        rank = 0
        for player_data in displayed_players:
            low_id = player_data[0]       # lowID
            name = player_data[1]         # name
            player_info = player_data[2]  # full info
            profile_icon = player_data[3] # profileIcon
            name_color = player_data[4]   # namecolor
            club_id = player_data[5]      # clubID
            trophies = player_data[6]     # brawler trophies

            rank += 1
            
            # Находим индекс текущего игрока
            if low_id == self.player.low_id:
                self.indexOfPlayer = rank

            self.writeVint(0)  # High ID
            self.writeVint(low_id)  # Low ID
            self.writeVint(rank)  # Ранг игрока

            # Записываем количество трофеев
            self.writeVint(trophies)
            self.writeVint(1)

            # Получаем название клуба
            club_name = self.get_club_name(club_id)
            self.writeString(club_name)

            # Обработка специальных ID и оформления имени
            is_special_id = low_id in special_ids
            
            if player_info.get('ban', 0) > 0:
                ban_gradient = (
                    f"<cFF0000>[</c>"
                    f"<cFF3333>B</c>"
                    f"<cCC0000>A</c>"
                    f"<cFF0000>N</c>"
                    f"<cFF3333>]</c> " 
                )
                name_to_display = self.rainbow_text(name) if is_special_id else name
                self.writeString(ban_gradient + name_to_display)
            elif player_info.get('admin', 0) > 0:
                admin_gradient = (
                    f"<c6A0DAD>[</c>"
                    f"<c8A2BE2>A</c>"
                    f"<c9932CC>D</c>"
                    f"<c6A0DAD>M</c>"
                    f"<c6A0DAD>]</c> "
                )
                name_to_display = self.rainbow_text(name) if is_special_id else name
                self.writeString(admin_gradient + name_to_display)
            elif player_info.get('vip', 0) > 0:
                vip_gradient = (
                    f"<cFFD700>[</c>"
                    f"<cFFC000>V</c>"
                    f"<cFFEE00>I</c>"
                    f"<cFFD700>P</c>"
                    f"<cFFC000>]</c> "
                )
                name_to_display = self.rainbow_text(name) if is_special_id else name
                self.writeString(vip_gradient + name_to_display)
            else:
                name_to_display = self.rainbow_text(name) if is_special_id else name
                self.writeString(name_to_display)

            self.writeVint(100)  # Уровень игрока
            self.writeVint(28000000 + profile_icon)  # Profile icon
            self.writeVint(43000000 + name_color)    # Name color
            self.writeVint(0)
            self.writeVint(0)

        # Дополнительные параметры для завершения пакета данных
        self.writeVint(0)
        self.writeVint(self.indexOfPlayer)
        self.writeVint(1)
        self.writeVint(0)
        self.writeString("RU")