from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class GetLeaderboardClubLocalOkMessage(Writer):

    def __init__(self, client, player, type):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.type = type

    def encode(self):
        self.indexOfClub = 0
        
        # Заголовок сообщения
        self.writeVint(2)  # Leaderboard type (clubs)
        self.writeVint(0)  # Unknown
        self.writeVint(0)  # Unknown
        self.writeString("RU") # Player Region

        # Получаем данные клубов
        DataBase.CountClub(self, 1, 100, 2, 200)
        print(f"[DEBUG] Local club leaderboard: found {self.AllianceCount} clubs")

        # Функция для сортировки по трофеям
        def by_trophy(club):
            return club['trophies']

        # Сортируем клубы по трофеям
        self.club_data.sort(key=by_trophy, reverse=True)
        self.writeVint(self.AllianceCount)  # Club count

        # Записываем данные каждого клуба
        for index, club in enumerate(self.club_data):
            # Находим позицию клуба игрока
            if club["clubID"] == self.player.club_low_id:
                self.indexOfClub = index + 1
                print(f"[DEBUG] Player club found at position {self.indexOfClub}")
            
            # Загружаем полные данные клуба
            db = DataBase()
            club_data = db.loadClub(club['clubID'])
            
            if club_data:
                self.writeVint(0) # Club High ID
                self.writeVint(club['clubID']) # Club Low ID
                self.writeVint(1) # Unknown
                self.writeVint(club_data['trophies']) # Club Trophies
                self.writeVint(2) # Unknown
                self.writeString(club_data['name']) # Club Name
                self.writeVint(club_data['members']['totalmembers']) # Club Members Count
                self.writeVint(8) # Club Badge
                self.writeVint(club_data['badgeID']) # Club Badge ID
            else:
                print(f"[ERROR] Failed to load club data for club ID {club['clubID']}")

        # Футер сообщения
        self.writeVint(0)  # Unknown
        self.writeVint(self.indexOfClub)  # Player club position
        self.writeVint(0)  # Unknown
        self.writeVint(0)  # Unknown
        self.writeString("RU")  # Region