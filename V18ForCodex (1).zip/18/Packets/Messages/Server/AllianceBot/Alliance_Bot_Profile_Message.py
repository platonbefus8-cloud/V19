from Utils.Writer import Writer


class BotProfileMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24113
        self.player = player

    def encode(self):
        self.writeVint(1)  # High Id
        self.writeVint(1)  # Low Id

        self.writeBoolean(False)

        self.writeVint(len(self.player.brawlers_id))  # Unlocked Brawlers Array

        for brawler_id in self.player.brawlers_id:
            self.writeScId(16, brawler_id)
            self.writeVint(0)
            self.writeVint(0) # Brawler Trophies
            self.writeVint(0) # Brawler Highest Trophies
            self.writeVint(10)    # Power Level

        self.writeVint(0) # Count

        self.writeVint(1)
        self.writeVint(0)  # 3v3 Victories

        self.writeVint(2)
        self.writeVint(1262469) # Experience

        self.writeVint(3)
        self.writeVint(self.player.trophies)  # Trophies

        self.writeVint(4)
        self.writeVint(self.player.trophies)  # Highest Trophies

        self.writeVint(5)
        self.writeVint(len(self.player.brawlers_id)) # Brawlers Count

        self.writeVint(6)
        self.writeVint(0)

        self.writeVint(7)
        self.writeVint(0)

        self.writeVint(8)
        self.writeVint(0)  # Solo Victories

        self.writeVint(9)
        self.writeVint(0)  # Best Robo Rumble Time

        self.writeVint(10)
        self.writeVint(0)  # Best Time as Big Brawler

        self.writeVint(11)
        self.writeVint(0)  # Duo Victories

        self.writeVint(12)
        self.writeVint(0)     # Highest Boss Fight Lvl Passed

        self.writeVint(13)
        self.writeVint(0)

        self.writeVint(14)
        self.writeVint(1)      # Highest Power Play Rank

        self.writeVint(15)
        self.writeVint(0)  # Most Challenge Wins
        
        info_gradient = (
            f"<c7E37B9>A</c>"
            f"<c8A49C8>N</c>"
            f"<c965BD7>G</c>"
            f"<cA26DE6>E</c>"
            f"<cAE7FF5>L</c>"
            f" "
            f"<cBA91FF>B</c>"
            f"<cC6A3FF>O</c>"
            f"<cD2B5FF>T</c>"
            )
            
        self.writeString(info_gradient) # Player Name

        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)

        in_club = True

        if in_club:

            self.writeBoolean(True) # Player in Club

            self.writeInt(0) # Club High Id
            self.writeInt(1) # Club Low Id                                
            self.writeString(info_gradient) # Club Name

            self.writeVint(8)
            self.writeVint(5) # Badge ID

            self.writeVint(3)  # Club Type
            self.writeVint(2)  # Club Members Count

            self.writeVint(0) # Club total trophies
            self.writeVint(0) # Club required trophies
            self.writeVint(0)

            self.writeVint(0)
            self.writeVint(0)

        else:
            self.writeVint(0)
            self.writeVint(0)



