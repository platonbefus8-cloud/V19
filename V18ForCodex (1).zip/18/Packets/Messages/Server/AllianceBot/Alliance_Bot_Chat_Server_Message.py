from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class AllianceBotChatServerMessage(Writer):

    def __init__(self, client, player, bot_msg_content):
        super().__init__(client)
        self.bot_msg_content = bot_msg_content
        self.id = 24312
        self.player = player

    def encode(self):
        
        info_gradient = (
            f"<c7E37B9>A</c>"
            f"<c8A49C8>N</c>"
            f"<c965BD7>G</c>"
            f"<cA26DE6>E</c>"
            f"<cAE7FF5>L</c>"
            f" "
            f"<cBA91FF>B</c>"
            f"<cC6A3FF>O</c>"
            f"<cD2B5FF>T</c>"
        )
        
        DataBase.GetmsgCount(self, self.player.club_low_id)
        self.writeVint(2)
        self.writeVint(1)
        self.writeVint(self.MessageCount)
        self.writeVint(1)
        self.writeVint(1)
        self.writeString(info_gradient)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeString(self.bot_msg_content)


