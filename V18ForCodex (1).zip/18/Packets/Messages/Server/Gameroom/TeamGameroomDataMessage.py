from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots

class TeamGameroomDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24124
        self.player = player
        self.playerCount = 1

    def encode(self):
        DataBase.loadGameroom(self)
        brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        brawler_trophies_for_rank = self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)]
        brawler_level = self.player.Brawler_level[str(self.player.brawler_id)]

        if self.player.room_id != 0:
            self.writeVint(1)#Team Mode
            self.writeVint(0)#?
            self.writeVint(1)#?

            self.writeInt(0)#High Id Room
            self.writeInt(self.player.room_id)#Room ID

            self.writeVint(100)#Timestamp
            self.writeVint(0)#?
            self.writeVint(0)#?
            self.writeVint(self.player.slot_index)#Slot index
            
            self.writeScId(15, self.mapID)# MapID
            print("MAP", self.mapID)

            for x in range(1):
                # Player
                self.writeVint(1)
                self.writeVint(True)# Gameroom owner boolean
                self.writeInt(0)                                      # HighID
                self.writeInt(self.player.low_id)# LowID

                self.writeScId(16, self.player.brawler_id)# BrawlerID
                self.writeVint(0)                                    #
                self.writeVint(brawler_trophies)# Brawler trophies
                self.writeVint(brawler_trophies_for_rank)#Brawler trophies for rank
                self.writeVint(self.player.Brawler_level[str(self.player.brawler_id)])# Power level

                self.writeVint(3)# Player State | 11: Events, 10: Brawlers, 9: Writing..., 8: Training, 7: Spectactor, 6: Offline, 5: End Combat Screen, 4: Searching, 3: Not Ready, 2: AFK, 1: In Combat, 0: OffLine
                self.writeVint(0)    # Is ready
                self.writeVint(0)     # Team | 0: Blue, 1: Red
                self.writeVint(0)

                self.writeString(self.player.name)                  # Player name
                self.writeVint(100)
                self.writeVint(28000000 + self.player.profile_icon)  # Player icon
                self.writeVint(43000000 + self.player.name_color)    #
                
                if self.player.Brawler_level[str(self.player.brawler_id)] > 8:
                	self.writeScId(16, self.player.brawler_id) # Starpower
                else:
                	self.writeScId(0, 0)

            self.writeVint(0)
            self.writeVint(0)
            self.writeVint(0)
            print(self.player.room_id)