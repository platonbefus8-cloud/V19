from Database.DatabaseManager import DataBase
import json
from Utils.Writer import Writer
import sqlite3


class AllianceStreamMessage(Writer):

    def __init__(self, client, player, clubLowID, type):
        super().__init__(client)
        self.id = 24311
        self.player = player
        self.eventType = type
        self.clubLowID = clubLowID if clubLowID != 0 else player.club_low_id
        self.db = DataBase(player)

    def encode(self):
        club_id = self.clubLowID if self.clubLowID != 0 else self.player.club_low_id
        
        if club_id != 0:
            self.db.GetmsgCount(club_id)
                        
            try:
                conn = sqlite3.connect('Database/Club/chat.db')
                cursor = conn.cursor()
                
                cursor.execute("SELECT info FROM chats WHERE clubID=?", (club_id,))
                result = cursor.fetchone()
                
                if result:
                    data = json.loads(result[0])
                    
                    if self.player.last_seen_message_id > self.db.MessageCount:
                        self.player.last_seen_message_id = 0
                        self.db.replaceValue('last_seen_message_id', 0)
                    
                    last_seen_msg = self.player.last_seen_message_id
                    
                    new_message_count = max(0, self.db.MessageCount - last_seen_msg)
                                        
                    self.writeVint(new_message_count)
                    
                    if new_message_count > 0:
                        print()
                        
                        for i in range(last_seen_msg + 1, self.db.MessageCount + 1):
                            msg_key = str(i)
                            if msg_key in data and msg_key != 'Total':
                                msg_data = data[msg_key]
                                
                                self.writeVint(msg_data['Event'])
                                self.writeVint(0)
                                self.writeVint(msg_data['Tick'])
                                self.writeVint(0)
                                self.writeVint(msg_data['PlayerID'])
                                self.writeString(msg_data['PlayerName'])
                                self.writeVint(msg_data['PlayerRole'])
                                self.writeVint(0)
                                self.writeVint(0)
                                if msg_data['Event'] == 4:
                                    self.writeString(msg_data['Message'])
                                    self.writeVint(1)
                                    self.writeVint(0)
                                    self.writeVint(msg_data['PlayerID'])
                                    self.writeString(msg_data['PlayerName'])
                                else:
                                    self.writeString(msg_data['Message'])
                            else:
                                print()
                        
                        self.player.last_seen_message_id = self.db.MessageCount
                        self.db.replaceValue('last_seen_message_id', self.db.MessageCount)
                    else:
                        print()
                else:
                    print(f"[ERROR] AllianceStreamMessage: чат клуба {club_id} не найден")
                    self.player.last_seen_message_id = 0
                    self.db.replaceValue('last_seen_message_id', 0)
                    self.writeVint(0)
                
                conn.close()
            except Exception as e:
                print(f"[ERROR] AllianceStreamMessage: {e}")
                self.player.last_seen_message_id = 0
                self.db.replaceValue('last_seen_message_id', 0)
                self.writeVint(0)

        else:
            self.writeVint(0)