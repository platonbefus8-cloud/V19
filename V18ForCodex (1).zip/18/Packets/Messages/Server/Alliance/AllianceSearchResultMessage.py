from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import json
import random


class AllianceSearchResultMessage(Writer):

    def __init__(self, client, player, requestedName, count):
        super().__init__(client)
        self.id = 24310
        self.player = player
        self.requestedName = str(requestedName)
        self.count = count

    def encode(self):
        # Загружаем все клубы
        DataBase.CountClub(self, 1, 100, 2, 100)
        
        self.writeString(self.requestedName)
        
        # Фильтруем клубы по имени (если есть поисковый запрос)
        matching_clubs = []
        search_name_lower = self.requestedName.lower()
        
        if self.requestedName.strip():  # Если есть поисковый запрос
            for i, club_info in enumerate(self.club_data):
                try:
                    club_name = club_info.get('name', '')
                    if search_name_lower in club_name.lower():
                        matching_clubs.append((self.club_list[i], club_info))
                except Exception as e:
                    print(f"[ОШИБКА] Ошибка при фильтрации клуба: {e}")
                    continue
        else:
            # Если поисковый запрос пустой, используем все клубы
            for i, club_info in enumerate(self.club_data):
                matching_clubs.append((self.club_list[i], club_info))
        
        # Выбираем один случайный клуб из найденных
        if matching_clubs:
            # Берем случайный клуб
            random_club_id, random_club_info = random.choice(matching_clubs)
            
            # Загружаем данные случайного клуба
            DataBase.loadClub(self, random_club_id)
            
            # Отправляем только один клуб
            self.writeVint(1)  # Количество найденных клубов = 1

            self.writeInt(0)  # ClubHighID
            self.writeInt(random_club_id)  # ClubLowID
            self.writeString(self.clubName)  # Club name

            self.writeVint(8)  # BadgeID type
            self.writeVint(self.clubbadgeID)  # Club badge number

            self.writeVint(self.clubtype)  # Club type

            self.writeVint(self.clubmembercount)  # Member count

            self.writeVint(self.clubtrophies)  # Trophies total
            self.writeVint(self.clubtrophiesneeded)  # Trophies needed
            self.writeVint(0)  # Unknown

            self.writeString(self.clubregion)  # Region
            self.writeVint(0)  # Members online
            self.writeVint(0)  # Family friendly
            
            print(f"[INFO] Поиск: найден случайный клуб '{self.clubName}' по запросу '{self.requestedName}'")
        else:
            # Если клубов не найдено
            self.writeVint(0)
            print(f"[INFO] Поиск: клубов по запросу '{self.requestedName}' не найдено")