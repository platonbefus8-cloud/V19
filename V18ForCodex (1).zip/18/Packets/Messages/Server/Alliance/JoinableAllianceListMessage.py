import json
import random
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class JoinableAllianceListMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24304
        self.player = player

    def encode(self):
        # Загружаем все клубы
        DataBase.CountClub(self, 1, 100, 2, 100)
        
        # Выбираем один случайный клуб
        if self.AllianceCount > 0:
            # Берем случайный клуб из списка
            random_club_index = random.randint(0, self.AllianceCount - 1)
            random_club_id = self.club_list[random_club_index]
            
            # Загружаем данные случайного клуба
            DataBase.loadClub(self, random_club_id)
            
            # Отправляем только один клуб
            self.writeVint(1)  # Количество клубов = 1
            
            self.writeInt(0)                                 # ClubHighID
            self.writeInt(random_club_id)                    # ClubLowID
            self.writeString(self.clubName)                  # Club name

            self.writeVint(8)                                # BadgeID type
            self.writeVint(self.clubbadgeID)                 # Club badge number

            self.writeVint(self.clubtype)                    # Club type

            self.writeVint(self.clubmembercount)             # Member count

            self.writeVint(self.clubtrophies)                # Trophies total
            self.writeVint(self.clubtrophiesneeded)          # Trophies needed
            self.writeVint(0)                                # Unknown

            self.writeString(self.clubregion)                # Region
            self.writeVint(0)                                # Members online
            self.writeVint(0)                                # Family friendly
            
            print(f"[INFO] Отображаем случайный клуб: {self.clubName} (ID: {random_club_id})")
        else:
            # Если клубов нет, отправляем пустой список
            self.writeVint(0)
            print(f"[INFO] Нет доступных клубов для отображения")