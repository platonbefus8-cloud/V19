from Utils.Writer import Writer
import json
from Database.DatabaseManager import DataBase
import sqlite3

class AllianceChatServerMessage(Writer):

    def __init__(self, client, player, msg_content):
        super().__init__(client)
        self.msg_content = msg_content
        self.id = 24312
        self.player = player
        self.db = DataBase(player)

    def encode(self):
        try:
            self.db.GetmsgCount(self.player.club_low_id)
            
            print(f"[DEBUG] AllianceChatServerMessage: Total = {self.db.MessageCount}")
            
            conn = sqlite3.connect('Database/Club/chat.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM chats WHERE clubID=?", (self.player.club_low_id,))
            result = cursor.fetchone()
            
            if not result:
                print(f"[ERROR] Чат клуба {self.player.club_low_id} не найден")
                conn.close()
                return
                
            data = json.loads(result[0])
            
            # Берем последнее сообщение (самое новое)
            last_message_id = data.get('Total', 0)
            current_msg_index = str(last_message_id)
            
            print(f"[DEBUG] Ищем последнее сообщение с ID: {current_msg_index}")
            
            if current_msg_index not in data:
                print(f"[ERROR] Сообщение {current_msg_index} не найдено в чате клуба")
                conn.close()
                return
            
            message_data = data[current_msg_index]
            
            print(f"[DEBUG] Отправляем новое сообщение: {message_data}")
            
            # Отправляем только одно сообщение - последнее
            self.writeVint(message_data['Event'])
            self.writeVint(0)
            self.writeVint(last_message_id)  # ID сообщения
            self.writeVint(0)
            self.writeVint(message_data['PlayerID'])
            self.writeString(message_data['PlayerName'])
            self.writeVint(message_data['PlayerRole'])
            self.writeVint(0)
            self.writeVint(0)
            
            if message_data['Event'] == 4:
                self.writeString(message_data['Message'])
                self.writeVint(1)
                self.writeVint(0)
                self.writeVint(message_data['PlayerID'])
                self.writeString(message_data['PlayerName'])
            else:
                self.writeString(message_data['Message'])
                
            print(f"[SUCCESS] AllianceChatServerMessage отправлено: '{message_data['Message']}' от {message_data['PlayerName']}")
            
            conn.close()
                
        except Exception as e:
            print(f"[ERROR] AllianceChatServerMessage: {e}")