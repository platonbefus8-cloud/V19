from Logic.Player import Players
from os import SEEK_CUR, curdir
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import json


class AllianceDataMessage(Writer):

    def __init__(self, client, player, clubHighID, clubLowID):
        super().__init__(client)
        self.id = 24301
        self.player = player
        self.clubHighID = clubHighID
        self.clubLowID = clubLowID

    def rainbow_text(self, text):
        rainbow_colors = [
            '<cFF0000>', # красный
            '<cFF7F00>', # оранжевый
            '<cFFFF00>', # желтый
            '<c00FF00>', # зеленый
            '<c0000FF>'  # синий
        ]
        colored_text = ""
        for i, char in enumerate(text):
            color = rainbow_colors[i % len(rainbow_colors)]
            colored_text += f"{color}{char}</c>"
        return colored_text

    def get_special_ids(self):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
                return config.get("special_ids", []) or []
        except Exception as e:
            print(f"Error reading config.json: {e}")
            return []

    def encode(self):
        db = DataBase(self.player)
        db.loadClub(self.clubLowID)

        if self.player.club_low_id != 0:
            self.writeVint(0)
        else:
            self.writeVint(2)

        # ClubID
        self.writeInt(0) # Club high id
        self.writeInt(self.clubLowID) # Club low id

        self.writeString(db.clubName) # Club name

        # Badge
        self.writeVint(8)
        self.writeVint(db.clubbadgeID) # Club badge id

        # Club settings
        self.writeVint(db.clubtype) # Club type [1 = open, 2 = invite only, 3 = closed]
        self.writeVint(len(db.plrids)) # Club members count

        # Club trophies
        self.writeVint(db.clubtrophies)           # Club total trophies
        self.writeVint(db.clubtrophiesneeded)     # Club required trophies

        # Club Info
        self.writeVint(0)
        self.writeString(db.clubregion)           # Region
        self.writeVint(0)

        self.writeString(db.clubdescription)      # Description

        special_ids = self.get_special_ids()

        # Members list
        self.writeVint(len(db.plrids))        # Members list count

        for id in db.plrids:
            db.GetMemberData(id)

            self.writeInt(0)                                    # High Id
            self.writeInt(id)                      # Low Id

            self.writeVint(db.plrrole)                        # player club role | 0 = Nothing, 1 = Member, 2 = President, 3 = Senior, 4 = Vice President
            self.writeVint(db.plrtrophies)                    # trophies
            
            self.writeVint(2)                             # Player states | 0 = last online 1 hour ago, 1 = battling, 2 = menu, 4 = matchmaking, 6 = last online 1 month ago, 7 = spectating, 8 = practicing            
            
            online = "<cFF0000>■</c>"
            if db.plronline == 1:
                online = "<c00FFFF>■</c>"
            
            is_special_id = id in special_ids
            
            if db.plrban > 0:
                ban_gradient = (
                    f"<cFF0000>[</c>"
                    f"<cFF3333>B</c>"
                    f"<cCC0000>A</c>"
                    f"<cFF0000>N</c>"
                    f"<cFF3333>] </c> " 
                )
                name_to_display = self.rainbow_text(db.plrname) if is_special_id else db.plrname
                player_name_display = f"{online} " + ban_gradient + name_to_display
            elif db.plradmin > 0:
                admin_gradient = (
                    f"<c6A0DAD>[</c>"
                    f"<c8A2BE2>A</c>"
                    f"<c9932CC>D</c>"
                    f"<c6A0DAD>M</c>"
                    f"<c6A0DAD>] </c> "
                )
                name_to_display = self.rainbow_text(db.plrname) if is_special_id else db.plrname
                player_name_display = f"{online} " + admin_gradient + name_to_display
            elif db.plrvip > 0:
                vip_gradient = (
                    f"<cFFD700>[</c>"
                    f"<cFFC000>V</c>"
                    f"<cFFEE00>I</c>"
                    f"<cFFD700>P</c>"
                    f"<cFFC000>] </c> "
                )
                name_to_display = self.rainbow_text(db.plrname) if is_special_id else db.plrname
                player_name_display = f"{online} " + vip_gradient + name_to_display
            else:
                name_to_display = self.rainbow_text(db.plrname) if is_special_id else db.plrname
                player_name_display = f"{online} " + name_to_display
            
            self.writeVint(0)
            self.writeVint(0)
            self.writeString(player_name_display)
            self.writeVint(100)
            self.writeVint(28000000 + db.plricon)
            self.writeVint(43000000 + db.plrnamecolor)