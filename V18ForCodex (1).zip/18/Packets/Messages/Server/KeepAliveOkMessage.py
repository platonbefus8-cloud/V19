from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage

class KeepAliveOkMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20108
        self.player = player

    def encode(self):
        db = DataBase(self.player)
        db.GetmsgCount(self.player.club_low_id)
        AllianceStreamMessage(self.client, self.player, 0, 0).send()
        #MyAllianceMessage(self.client, self.player, 0).send()