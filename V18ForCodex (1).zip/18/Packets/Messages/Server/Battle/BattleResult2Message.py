from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class BattleResult2Message(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23456
        self.player = player

    def encode(self):
        self.writeVint(0)
        self.writeVint(self.player.battle_result)
        
        vip = self.player.vip
        winstreak = self.player.winstreak
        tickets = self.player.tickets
        brawler_level = self.player.Brawler_level[str(self.player.brawler_id)]
        brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        brawler_trophies_for_rank = self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)]
        
        exp_reward = [8, 6, 4]
        player_tokens_reward = [20, 15, 10]
        elif vip > 0 and tickets == 0:
        	exp_reward = [16, 12, 8]
        	player_tokens_reward = [40, 30, 20]
        elif vip == 0 and tickets > 0:
        	exp_reward = [16, 12, 8]
        	player_tokens_reward = [40, 30, 20]
        	self.player.tickets -= 1
        	DataBase.replaceValue(self, 'tickets', self.player.tickets)
        elif vip > 0 and tickets > 0:
        	exp_reward = [24, 18, 12]
        	player_tokens_reward = [60, 45, 30]
        	self.player.tickets -= 1
        	DataBase.replaceValue(self, 'tickets', self.player.tickets)
        	        	        

        if winstreak == 0 and vip == 0:
           win_val = 5
        elif winstreak == 0 and vip > 0:
            win_val = 10
        elif winstreak > 0 and winstreak < 6 and vip == 0:
           win_val = 5 + winstreak
        elif winstreak > 0 and winstreak < 6 and vip > 0:
           win_val = 10 + winstreak
        elif winstreak > 5 and vip == 0:
            win_val = 10
        elif winstreak > 5 and vip > 0:
            win_val = 15
            
        if 0 <= brawler_trophies <= 49:
            lose_val = 0
        elif 50 <= brawler_trophies <= 99:
            lose_val = -1
        elif 100 <= brawler_trophies <= 199:
            lose_val = -2
        elif 200 <= brawler_trophies <= 299:
            lose_val = -3
        elif 300 <= brawler_trophies <= 399:
            lose_val = -4
        elif 400 <= brawler_trophies <= 499:
            lose_val = -5
        elif 500 <= brawler_trophies <= 599:
            lose_val = -6
        elif 600 <= brawler_trophies <= 699:
            lose_val = -7
        elif 700 <= brawler_trophies <= 799:
            lose_val = -8
        elif 800 <= brawler_trophies <= 899:
            lose_val = -9
        elif 900 <= brawler_trophies <= 999:
            lose_val = -10
        elif 1000 <= brawler_trophies <= 1099:
            lose_val = -11
        elif 1100 <= brawler_trophies <= 1199:
            lose_val = -12
        elif brawler_trophies >= 1200:
            lose_val = -12
            	

        if self.player.battle_result == 0:
            self.player.ThreeVSThree_wins += 1
            self.player.player_experience += exp_reward[0]
            if self.player.tokensdoubler > 0:
                if self.player.tokensdoubler <= player_tokens_reward[0]:
                     player_tokens_reward[0] += self.player.tokensdoubler
                     self.player.tokensdoubler = 0
                     self.player.brawl_boxes += player_tokens_reward[0]
                     DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
                     DataBase.replaceValue(self, "brawlBoxes", self.player.brawl_boxes)
                else:
                    self.player.tokensdoubler -= player_tokens_reward[0]
                    player_tokens_reward[0] += player_tokens_reward[0]
                    self.player.brawl_boxes += player_tokens_reward[0]
                    DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
                    DataBase.replaceValue(self, "brawlBoxes", self.player.brawl_boxes)
            else:
                self.player.brawl_boxes += player_tokens_reward[0]
            self.player.trophies += win_val
            self.player.winstreak += 1
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + win_val
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[str(self.player.brawler_id)]:
                self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] = brawler_trophies_for_rank + win_val

            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)
            DataBase.replaceValue(self, '3vs3Wins', self.player.ThreeVSThree_wins)
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)
            DataBase.replaceValue(self, 'winstreak', self.player.winstreak)
        else:
            self.player.player_experience += exp_reward[2]
            if self.player.tokensdoubler > 0:
                if self.player.tokensdoubler <= player_tokens_reward[2]:
                     player_tokens_reward[2] += self.player.tokensdoubler
                     self.player.tokensdoubler = 0
                     self.player.brawl_boxes += player_tokens_reward[2]
                     DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
                     DataBase.replaceValue(self, "brawlBoxes", self.player.brawl_boxes)
                else:
                    self.player.tokensdoubler -= player_tokens_reward[2]
                    player_tokens_reward[2] += player_tokens_reward[2]
                    self.player.brawl_boxes += player_tokens_reward[2]
                    DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
                    DataBase.replaceValue(self, "brawlBoxes", self.player.brawl_boxes)
            else:
                self.player.brawl_boxes += player_tokens_reward[2]
            self.player.trophies -= lose_val
            self.player.winstreak = 0
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + lose_val

            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', self.player.trophies)
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)
            DataBase.replaceValue(self, 'winstreak', self.player.winstreak)

        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(32)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(6)
        self.writeVint(5)
        self.writeVint(16)
        self.writeVint(self.player.brawler_id)
        self.writeVint(29)
        self.writeVint(self.player.skin_id)
        self.writeVint(99999)
        self.writeVint(0)
        self.writeVint(brawler_level)
        self.writeVint(0)
        self.writeString(self.player.name)
        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)

        self.writeVint(0)
        self.writeVint(16)
        self.writeVint(self.player.bot1)
        self.writeVint(0)
        self.writeVint(99999)
        self.writeVint(0)
        self.writeVint(10)
        self.writeVint(0)
        self.writeString(self.player.bot1_n)
        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)

        self.writeVint(0)
        self.writeVint(16)
        self.writeVint(self.player.bot2)
        self.writeVint(0)
        self.writeVint(99999)
        self.writeVint(0)
        self.writeVint(10)
        self.writeVint(0)
        self.writeString(self.player.bot2_n)
        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)

        self.writeVint(2)
        self.writeVint(16)
        self.writeVint(self.player.bot3)
        self.writeVint(0)
        self.writeVint(99999)
        self.writeVint(0)
        self.writeVint(10)
        self.writeVint(0)
        self.writeString(self.player.bot3_n)
        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)

        self.writeVint(2)
        self.writeVint(16)
        self.writeVint(self.player.bot4)
        self.writeVint(0)
        self.writeVint(99999)
        self.writeVint(0)
        self.writeVint(10)
        self.writeVint(0)
        self.writeString(self.player.bot4_n)
        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)

        self.writeVint(2)
        self.writeVint(16)
        self.writeVint(self.player.bot5)
        self.writeVint(0)
        self.writeVint(99999)
        self.writeVint(0)
        self.writeVint(10)
        self.writeVint(0)
        self.writeString(self.player.bot5_n)
        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)