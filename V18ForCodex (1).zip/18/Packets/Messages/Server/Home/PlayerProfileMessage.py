from os import truncate
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import json

class PlayerProfileMessage(Writer):

    def __init__(self, client, player, high_id, low_id, players):
        super().__init__(client)
        self.id = 24113
        self.player = player
        self.high_id = high_id
        self.low_id = low_id
        self.players = players

    def rainbow_text(self, text):
        rainbow_colors = [
            '<cFF0000>', # красный
            '<cFF7F00>', # оранжевый
            '<cFFFF00>', # желтый
            '<c00FF00>', # зеленый
            '<c0000FF>'  # синий
        ]
        colored_text = ""
        for i, char in enumerate(text):
            color = rainbow_colors[i % len(rainbow_colors)]
            colored_text += f"{color}{char}</c>"
        return colored_text
        
    def get_special_ids(self):
        try:
            with open('config.json', 'r') as f:
            	config = json.load(f)
            	return config.get("special_ids", []) or []
        except Exception as e:
        	print(f"Error reading config.json: {e}")
        	return []

    def encode(self):
        special_ids = self.get_special_ids()
        
        for player in self.players:
            if self.low_id == player["lowID"]:
                self.UnlockedBrawlersList = []
                for brawler_id in player["UnlockedBrawlers"]:
                    if player["UnlockedBrawlers"][str(brawler_id)] == 1:
                        self.UnlockedBrawlersList.append(int(brawler_id))

                self.writeVint(self.high_id)  # High Id
                self.writeVint(self.low_id)  # Low Id
                self.writeVint(0)  # Unknown

                self.writeVint(len(self.UnlockedBrawlersList))  # Brawlers array

                for brawler_id in self.UnlockedBrawlersList:
                    self.writeScId(16, int(brawler_id))
                    self.writeVint(0)
                    self.writeVint(player["brawlersTrophiesForRank"][str(brawler_id)])  # Trophies for rank
                    self.writeVint(player["brawlersTrophies"][str(brawler_id)])  # Trophies
                    self.writeVint(player["brawlerPowerLevel"][str(brawler_id)] + 1)  # power lvl

                self.writeVint(15)

                self.writeVint(1)
                self.writeVint(player["3vs3Wins"])  # 3v3 victories

                self.writeVint(2)
                self.writeVint(player["playerExp"])  # Player experience

                self.writeVint(3)
                self.writeVint(player["trophies"])  # Trophies

                self.writeVint(4)
                self.writeVint(player["highesttrophies"])  # Highest trophies

                self.writeVint(5)
                self.writeVint(len(self.UnlockedBrawlersList))  # Brawlers list

                self.writeVint(7)
                self.writeVint(28000000 + player["profileIcon"])  # Profile icon??

                self.writeVint(8)
                self.writeVint(player["soloWins"])  # Solo victories

                self.writeVint(9)
                self.writeVint(0)  # Best robo rumble time

                self.writeVint(10)
                self.writeVint(0)  # Best time as big brawler

                self.writeVint(11)
                self.writeVint(player["duoWins"])  # Duo victories

                self.writeVint(12)
                self.writeVint(0)  # Highest boss fight lvl passed

                self.writeVint(13)
                self.writeVint(0)  # Highest power player points

                self.writeVint(14)
                self.writeVint(1)  # Highest power play rank

                self.writeVint(15)
                self.writeVint(0)  # most challenge wins

                self.writeVint(16)
                self.writeVint(20)
                
                if player['title'] == "ОТСУТСТВУЕТ":
                    title = ""
                else:
                    title = f"<cFFFFFF> | </c>{player['title']}"
                
                online = " | <cFF0000>Offline</c>"
                if player['online'] == 1:
                	online = " | <c00FFFF>Online</c>"
                
                is_special_id = self.player.low_id in special_ids
                name_to_display = self.rainbow_text(player['name']) if is_special_id else player['name']
                player_id_display = f"<cFFFFFF> | {player['lowID']}</c>"
                
                if player['ban'] > 0:
                    ban_gradient = (
                        f"<cFF0000>[</c>"
                        f"<cFF3333>B</c>"
                        f"<cCC0000>A</c>"
                        f"<cFF0000>N</c>"
                        f"<cFF3333>] </c> "
                    )
                    self.writeString(f"{ban_gradient}{name_to_display}{title}{player_id_display}{online}")
                elif player['admin'] > 0:
                    admin_gradient = (
                        f"<c6A0DAD>[</c>"
                        f"<c8A2BE2>A</c>"
                        f"<c9932CC>D</c>"
                        f"<c6A0DAD>M</c>"
                        f"<c8A2BE2>]</c>"
                    )
                    self.writeString(f"{admin_gradient}{name_to_display}{title}{player_id_display}{online}")
                elif player['vip'] > 0:
                    vip_gradient = (
                        f"<cFFD700>[</c>"
                        f"<cFFC000>V</c>"
                        f"<cFFEE00>I</c>"
                        f"<cFFD700>P</c>"
                        f"<cFFC000>]</c> "
                    )
                    self.writeString(f"{vip_gradient}{name_to_display}{title}{player_id_display}{online}")
                else:
                    self.writeString(f"{name_to_display}{title}{player_id_display}{online}")
                    
                self.writeVint(100)
                self.writeVint(28000000 + player["profileIcon"])  # Profile icon
                self.writeVint(43000000 + player["namecolor"])  # Name color
                self.player.NC = player["namecolor"]

                if player["clubID"] != 0:
                    db = DataBase(self.player)
                    club_data = db.loadClub(player["clubID"])

                    if club_data is not None:
                        self.writeBoolean(True)  # Is in club

                        self.writeInt(0)
                        self.writeInt(player["clubID"])
                        self.writeString(db.clubName)  # club name
                        self.writeVint(8)
                        self.writeVint(db.clubbadgeID)  # Club badgeID
                        self.writeVint(db.clubtype)  # club type | 1 = Open, 2 = invite only, 3 = closed
                        self.writeVint(db.clubmembercount)  # Current members count
                        self.writeVint(db.clubtrophies)
                        self.writeVint(db.clubtrophiesneeded)  # Trophy required
                        self.writeVint(0)  # (Unknown)
                        self.writeString(db.clubregion)  # region
                        self.writeVint(0)  # (Unknown)
                        self.writeVint(0)  # (Unknown)
                        self.writeVint(25)
                        self.writeVint(player["clubRole"])
                    else:
                        self.writeVint(0)
                        self.writeVint(0)
                else:
                    self.writeVint(0)
                    self.writeVint(0)