from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards
from datetime import datetime
import random
import json

from Utils.Writer import Writer
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Gameroom.DoNotDistrubOkMessage import DoNotDistrubOkMessage
from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage

from Logic.Shop import Shop
from Logic.EventSlots import EventSlots

class OwnHomeDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24101
        self.player = player
        
    def randomID(self):
    	length = 9
    	return int(''.join([str(random.randint(0, 9)) for _ in range(length)]))
        
    def get_online_count(self):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
                return config.get('Online', 0)
        except Exception as e:
            print(f"Error reading online count: {e}")
            return 0
                        
    def rainbow_text(self, text):
        rainbow_colors = [
            '<cFF0000>', # красный
            '<cFF7F00>', # оранжевый
            '<cFFFF00>', # желтый
            '<c00FF00>', # зеленый
            '<c0000FF>'  # синий
        ]
        colored_text = ""
        for i, char in enumerate(text):
            color = rainbow_colors[i % len(rainbow_colors)]
            colored_text += f"{color}{char}</c>"
        return colored_text

    def get_special_ids(self):
        try:
            with open('config.json', 'r') as f:
            	config = json.load(f)
            	return config.get("special_ids", []) or []
        except Exception as e:
        	print(f"Error reading config.json: {e}")
        	return []

    def encode(self):
        
        if not hasattr(self.player, 'brawlers_id'):
            self.player.brawlers_id = []
        if not hasattr(self.player, 'card_unlock_id'):
            self.player.card_unlock_id = []
        if not hasattr(self.player, 'UnlockedSkins'):
            self.player.UnlockedSkins = []
        if not hasattr(self.player, 'brawlers_skins'):
            self.player.brawlers_skins = {}

        db = DataBase(self.player)
        
        try:
            db.loadAccount()
        except Exception as e:
            print(f"Error loading account: {e}")
            try:
                if not hasattr(self.player, 'name') or self.player.name == "Guest":
                    self.player.name = "Guest"
                if not hasattr(self.player, 'low_id'):
                    self.player.low_id = self.randomID()
                db.createAccount()
                print(f"Created new account for {self.player.name} (ID: {self.player.low_id})")
            except Exception as create_error:
                print(f"Error creating account: {create_error}")

        self.writeVint(0)
        self.writeVint(0)  # Timestamp

        # Основные данные игрока
        self.writeVint(getattr(self.player, 'trophies', 0))
        self.writeVint(getattr(self.player, 'highest_trophies', 0))
        self.writeVint(0)
        self.writeVint(getattr(self.player, 'trophy_road', 0))
        self.writeVint(99999)  # Player exp

        # Иконка и цвет имени
        self.writeScId(28, getattr(self.player, 'profile_icon', 0))
        self.writeScId(43, getattr(self.player, 'name_color', 0))

        self.writeVint(0)

        # Скины
        self.writeVint(len(self.player.brawlers_skins))
        for brawler_id in self.player.brawlers_skins:
            self.writeVint(29)
            self.writeVint(self.player.brawlers_skins[brawler_id])

        self.writeVint(len(self.player.UnlockedSkins))
        for skin_id in self.player.UnlockedSkins:
            self.writeScId(29, skin_id)

        # Различные флаги
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)
        self.writeVint(1)
        self.writeBoolean(True)
        self.writeVint(getattr(self.player, 'tokensdoubler', 0))
        self.writeVint(Helpers.LeaderboardTimer(self))
        self.writeByte(8)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        
        self.writeVint(30)
        self.writeVint(0)
        
        Shop.encodeShopOffers(self)

        self.writeVint(0)
        self.writeVint(getattr(self.player, 'battle_tokens', 0))
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(getattr(self.player, 'tickets', 0))
        self.writeVint(0)
        self.writeScId(16, getattr(self.player, 'brawler_id', 0))

        # Информация о сервере
        self.writeString(getattr(self.player, 'region', ''))
        rainbow = (
            "<cFF0000>t</c>"
            "<cFF4000>.</c>"
            "<cFF8000>m</c>"
            "<cFFBF00>e</c>"
            "<cFFFF00>/</c>"
            "<c80FF00>A</c>"
            "<c00FF00>n</c>"
            "<c00FF80>g</c>"
            "<c00FFFF>e</c>"
            "<c0080FF>l</c>"
            "<c0000FF>B</c>"
            "<c8000FF>r</c>"
            "<cBF00FF>a</c>"
            "<cFF00FF>w</c>"
            "<cFF0080>l</c>"
        )
        self.writeString(rainbow)

        # Анимации
        self.writeVint(3)
        self.writeInt(3)
        self.writeInt(getattr(self.player, 'tokensAnim', 0))
        self.writeInt(4)
        self.writeInt(getattr(self.player, 'trophiesAnim', 0))
        self.writeInt(5)
        self.writeInt(getattr(self.player, 'bigTokensAnim', 0))

        # Сброс анимаций
        self.player.tokensAnim = 0
        self.player.trophiesAnim = 0
        self.player.bigTokensAnim = 0

        # Магазин и ивенты
        self.writeVint(2019049)
        self.writeVint(100)
        self.writeVint(10)

        for item in Shop.boxes:
            self.writeVint(item['Cost'])
            self.writeVint(item['Multiplier'])

        self.writeVint(Shop.token_doubler['Cost'])
        self.writeVint(Shop.token_doubler['Amount'])
        self.writeVint(500)
        self.writeVint(50)
        self.writeVint(999900)
        self.writeVint(0)
        self.writeVint(6)

        for i in range(6):
            self.writeVint(i)

        EventSlots.offset(self)
        self.writeVint(0)

        # Логика магазина
        self.writeVint(8)
        for i in [20, 35, 75, 140, 290, 480, 800, 1250]:
            self.writeVint(i)

        self.writeVint(8)
        for i in [1, 2, 3, 4, 5, 10, 15, 20]:
            self.writeVint(i)

        self.writeVint(3)
        for i in [10, 30, 80]:
            self.writeVint(i)

        self.writeVint(3)
        for i in [6, 20, 60]:
            self.writeVint(i)

        self.writeVint(len(Shop.gold))
        for item in Shop.gold:
            self.writeVint(item['Cost'])

        self.writeVint(len(Shop.gold))
        for item in Shop.gold:
            self.writeVint(item['Amount'])

        self.writeVint(0)
        self.writeVint(200)
        self.writeVint(20)
        self.writeVint(8640)
        self.writeVint(10)
        self.writeVint(5)
        self.writeVint(6)
        self.writeVint(50)
        self.writeVint(604800)
        self.writeBoolean(True)
        self.writeVint(0)
        
        try:
            with open('config.json', 'r') as f:
    	        config = json.load(f)
    	        theme_id = config.get('ThemeID', 12)
        except Exception as e:
        	print(f"Error reading ThemeID from config.json: {e}")
        	theme_id = 12
        
        # Тема меню
        self.writeVint(1)
        self.writeInt(1)
        self.writeInt(41000000 + theme_id)

        # ID игрока
        high_id = getattr(self.player, 'high_id', 0)
        low_id = getattr(self.player, 'low_id', 0)
        self.writeInt(high_id)
        self.writeInt(low_id)

        # VIP информация
        vip_status = "<c2>ОТСУТСТВУЕТ</c>"
        if getattr(self.player, 'vip', 0) == 1:
            if hasattr(self.player, 'viptime') and self.player.viptime != "0":
                try:
                    vip_date = datetime.strptime(self.player.viptime, "%d.%m.%Y")
                    today = datetime.now()
                    if vip_date > today:
                        days_left = (vip_date - today).days + 1
                        vip_status = f"<c3>АКТИВИРОВАН</c> | <c3>ОСТАЛОСЬ: {days_left} ДНЕЙ</c>"
                    else:
                        self.player.vip = 0
                        db.replaceValue('vip', self.player.vip)
                        self.player.viptime = "0"
                        db.replaceValue('viptime', self.player.viptime)
                        self.player.err_code = 1
                        LoginFailedMessage(self.client, self.player, f"ВАШ VIP-СТАТУС ИСТЁК!\n\nДАТА: {datetime.now().strftime('%H:%M:%S | %d.%m.%Y')}\n\nПерезайдите в игру.").send()
                except ValueError:
                    vip_status = "<c2>ОШИБКА ДАТЫ</c>"
        elif getattr(self.player, 'vip', 0) == 2:
            vip_status = "<c3>АКТИВИРОВАН</c> | <c3>БЕССРОЧНЫЙ</c>"

        # Градиенты                 
        vip_gradient = (
            f"<cFFD700>[</c>"
            f"<cFFC000>V</c>"
            f"<cFFEE00>I</c>"
            f"<cFFD700>P</c>"
            f"<cFFC000>]</c>"
            f"<cFFEE00>:</c>"
        )
        
        winstreak_gradient = (
            f"<cFFA500>[</c>"
            f"<cFF8C00>W</c>"
            f"<cFFA07A>I</c>"
            f"<cFF8C00>N</c>"
            f"<cFFA500>S</c>"
            f"<cFF8C00>T</c>"
            f"<cFFA07A>R</c>"
            f"<cFF8C00>E</c>"
            f"<cFFA500>A</c>"
            f"<cFF8C00>K</c>"
            f"<cFFA07A>]</c>"
            f"<cFF8C00>:</c>"
        )

        prefix_gradient = (
           f"<cFF4500>[</c>"
           f"<cFF6347>P</c>"
           f"<cFF7F50>R</c>"
           f"<cFF4500>E</c>"
           f"<cFF6347>F</c>"
           f"<cFF7F50>I</c>"
           f"<cFF4500>X</c>"
           f"<cFF6347>]</c>"
           f"<cFF7F50>:</c>"
        )
                                
        info_gradient = (
            f"<c7E37B9>A</c>"
            f"<c8A49C8>N</c>"
            f"<c965BD7>G</c>"
            f"<cA26DE6>E</c>"
            f"<cAE7FF5>L</c>"
            f" "
            f"<cBA91FF>B</c>"
            f"<cC6A3FF>R</c>"
            f"<cD2B5FF>A</c>"
            f"<cDEC7FF>W</c>"
            f"<cEAD9FF>L</c>"
        )
        
        if getattr(self.player, 'title', '') == "ОТСУТСТВУЕТ":
        	prifix_info = "<c2>ОТСУТСТВУЕТ</c>"
        else:
        	prifix_info = getattr(self.player, 'title', '')        
        
        # Нотифы
        notifications_count = 0
        notifications_to_show = []
        
        try:
            with open('JSON/Notif.json', 'r', encoding='utf-8') as f:
                notif_data = json.load(f)
                         
            notif_unique_ids = {}                                                                             
            for notif_key, notif_info in notif_data.items():
                notif_id = notif_info.get('NotifID', 0)
                notif_info_list = notif_info.get('NotifInfo', [])
                notif_amount = notif_info.get('NotifAmount', 0)
                notif_brawler_id = notif_info.get('NotifBrawlerID', 0)
                notif_skin_id = notif_info.get('NotifSkinID', 0)
                notif_text = notif_info.get('NotifTXT', 'Текст недоступен')
                notif_sender = notif_info.get('NotifSender', 0)
                notif_type = notif_info.get('NotifType', 1)
                
                should_show = False
                if notif_type == 0: # Для всех
                	should_show = self.player.low_id not in notif_info_list
                elif notif_type == 1: # Для особенных 
                	should_show = self.player.low_id in notif_info_list
                
                if should_show:
                	unique_id = hash(notif_key) % 900000 + 100000
                	if notif_id == 0:
                		if getattr(self.player, 'sbros', 0) > 0:
                			notifications_count += 1
                	else:
                		notifications_count += 1
                	
                	notifications_to_show.append({
                        'id': notif_id,
                        'unique_id': unique_id,
                        'amount': notif_amount,
                        'brawler_id': notif_brawler_id,
                        'skin_id': notif_skin_id,
                        'text': notif_text,
                        'sender': notif_sender,
                        'key': notif_key,
                        'type': notif_type
                    })
                    
        except Exception as e:
            print(f"Error reading Notif.json: {e}")
                                    
        self.writeVint(1 + notifications_count)
        
        if getattr(self.player, 'winstreak', 0) == 0:
        	info_winstreak = f""
        elif getattr(self.player, 'winstreak', 0) > 0 and getattr(self.player, 'winstreak', 0) < 6:
        	info_winstreak = f"[ +{getattr(self.player, 'winstreak', 0)} ТРОФЕЕВ ]"
        elif getattr(self.player, 'winstreak', 0) > 5:
        	info_winstreak = f"[ +5 ТРОФЕЕВ ]"
        else:
        	info_winstreak = f""
        
        self.writeVint(81)
        self.writeInt(10000)
        self.writeBoolean(False)
        self.writeInt(86400)
        self.writeString(f"{info_gradient} INFO:\n\n◽[ID]:  {low_id}\n◽[TOKEN]:  {getattr(self.player, 'token', '')}\n\n⭐{vip_gradient}  {vip_status}\n♨️{prefix_gradient}  {prifix_info}\n🔥{winstreak_gradient}  {getattr(self.player, 'winstreak', 0)} {info_winstreak}")
        self.writeVint(1)       

        for notif in notifications_to_show:
            notif_id = notif['id']
            unique_id = notif['unique_id']
            notif_amount = notif['amount']
            brawler_id = notif['brawler_id']
            skin_id = notif['skin_id']
            notif_text = notif['text']
            notif_sender = notif['sender']
            	            
            if notif_id == 0: # Сброс сезона
                	if getattr(self.player, 'sbros', 0) > 0:
                		if getattr(self.player, 'sbros', 0) == 1:
                			sbros_info = "Кристаллы"
                		elif getattr(self.player, 'sbros', 0) == 2:
                			sbros_info = "Билеты"
                		elif getattr(self.player, 'sbros', 0) == 3:
                			sbros_info = "Монеты"
                		else:
                			sbros_info = "Неизвестно"
                			
                		self.writeVint(89)
                		self.writeInt(unique_id)
                		self.writeBoolean(False)
                		self.writeInt(86400)
                		self.writeString(f"<c3>СБРОС СЕЗОНА!\nНаграда: {sbros_info} (</c>{getattr(self.player, 'sbroscost', 0)}<c3>)\nЗа -{getattr(self.player, 'sbrosinfo', 0)} трофеев</c>")
                		self.writeVint(notif_sender)
                		self.writeVint(getattr(self.player, 'questBP', 0))
            
            elif notif_id == 1:  # Монеты
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>Монеты (</c>{notif_amount}<c3>)</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                
            elif notif_id == 2:  # Гемы
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>Кристаллы (</c>{notif_amount}<c3>)</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                
            elif notif_id == 3:  # Билеты
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>Билеты (</c>{notif_amount}<c3>)</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                
            elif notif_id == 4:  # Удвоители
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>Удвоители (</c>{notif_amount}<c3>)</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                
            elif notif_id == 5:  # Скин
                self.writeVint(94)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(notif_text)
                self.writeVint(29000000 + skin_id)
            
            elif notif_id == 6:  # Боец
                self.writeVint(93)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(notif_text)
                self.writeVint(notif_sender)
                self.writeVint(16000000 + brawler_id)
                
            elif notif_id == 7:  # Маленький ящик
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>Сумму (</c>{notif_amount}<c3>) Ящиков</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                
            elif notif_id == 8:  # Большой ящик
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>Сумму (</c>{notif_amount}<c3>) Больших Ящиков</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                
            elif notif_id == 9:  # Мегаящик
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>Сумму (</c>{notif_amount}<c3>) МегаЯщиков</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                
            elif notif_id == 10:  # Префикс
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>Случайный Префикс (</c>{notif_amount}<c3>)</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                
            elif notif_id == 11:  # VIP-Статус
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>(</c>{notif_amount}<c3>) Дней VIP-Статуса</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
            
            elif notif_id == 12:  # ADM-Статус
                self.writeVint(89)
                self.writeInt(unique_id)
                self.writeBoolean(False)
                self.writeInt(86400)
                self.writeString(f"<c3>(</c>∞<c3>) Дней ADM-Статуса</c>\n{notif_text}")
                self.writeVint(notif_sender)
                self.writeVint(notif_amount)
                	


        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(0)

        # Повторная запись ID
        self.writeVint(high_id)
        self.writeVint(low_id)
        self.writeVint(high_id)
        self.writeVint(low_id)
        self.writeVint(high_id)
        self.writeVint(low_id)

        # Обработка имени игрока
        special_ids = self.get_special_ids()
        is_special_id = hasattr(self.player, 'low_id') and self.player.low_id in special_ids
        
        if not hasattr(self.player, 'name') or self.player.name == "Guest":
        	self.writeString("Guest")
        	self.writeVint(0)
        else:
            name_to_display = self.rainbow_text(self.player.name) if is_special_id else self.player.name
            
            if getattr(self.player, 'ban', 0) > 0:
                name_to_display = f"<cFF0000>[<cFF3333>B<cCC0000>A<cFF0000>N<cFF3333>]</c> {name_to_display}"
            elif getattr(self.player, 'admin', 0) > 0:
                name_to_display = f"<c6A0DAD>[<c8A2BE2>A<c9932CC>D<c6A0DAD>M<c6A0DAD>]</c> {name_to_display}"
            elif getattr(self.player, 'vip', 0) > 0:
                name_to_display = f"<cFFD700>[<cFFC000>V<cFFEE00>I<cFFD700>P<cFFC000>]</c> {name_to_display}"
                
            self.writeString(name_to_display)
            self.writeVint(1)

        self.writeString()

        # Ресурсы игрока
        self.writeVint(8)
        self.writeVint(len(self.player.card_unlock_id) + 4)

        index = 0
        for unlock_id in self.player.card_unlock_id:
            self.writeVint(23)
            self.writeVint(unlock_id)
            try:
                self.writeVint(self.player.BrawlersUnlockedState[str(index)])
            except:
                self.writeVint(1)
            index += 1

        self.writeVint(5)
        self.writeVint(1)
        self.writeVint(getattr(self.player, 'brawl_boxes', 0))

        self.writeVint(5)
        self.writeVint(8)
        self.writeVint(getattr(self.player, 'gold', 0))

        self.writeVint(5)
        self.writeVint(9)
        self.writeVint(getattr(self.player, 'big_boxes', 0))

        self.writeVint(5)
        self.writeVint(10)
        self.writeVint(getattr(self.player, 'star_points', 0))

        # Бравлеры
        if hasattr(self.player, 'brawlers_id') and self.player.brawlers_id:
            # Трофеи бравлеров
            self.writeVint(len(self.player.brawlers_id))
            for brawler_id in self.player.brawlers_id:
                self.writeScId(16, brawler_id)
                self.writeVint(getattr(self.player, 'brawlers_trophies', {}).get(str(brawler_id), 0))

            # Ранги
            self.writeVint(len(self.player.brawlers_id))
            for brawler_id in self.player.brawlers_id:
                self.writeScId(16, brawler_id)
                self.writeVint(getattr(self.player, 'brawlers_trophies_in_rank', {}).get(str(brawler_id), 0))

            self.writeVint(0)

            # Очки улучшений
            self.writeVint(len(self.player.brawlers_id))
            for brawler_id in self.player.brawlers_id:
                self.writeScId(16, brawler_id)
                brawler_level = getattr(self.player, 'Brawler_level', {}).get(str(brawler_id), 1)
                if brawler_level > 8:
                    self.writeVint(1410)
                else:
                    self.writeVint(getattr(self.player, 'brawlers_upgradium', {}).get(str(brawler_id), 0))

            # Уровни бравлеров
            self.writeVint(len(self.player.brawlers_id))
            for brawler_id in self.player.brawlers_id:
                self.writeScId(16, brawler_id)
                brawler_level = getattr(self.player, 'Brawler_level', {}).get(str(brawler_id), 1)
                if brawler_level < 10:
                    self.writeVint(getattr(self.player, 'Brawler_level', {}).get(str(brawler_id), 1))
                else:
                    self.writeVint(9)

            # Звёздные силы
            self.writeVint(len(self.player.brawlers_id))
            for brawler_id in self.player.brawlers_id:
                self.writeScId(16, brawler_id)
                
                brawler_level = getattr(self.player, 'Brawler_level', {}).get(str(brawler_id), 1)
                if brawler_level > 8:
                    self.writeVint(getattr(self.player, 'Brawler_starPower', {}).get(str(brawler_id), 0))
                else:
                    self.writeVint(0)

            # Новые бравлеры
            self.writeVint(len(self.player.brawlers_id))
            for brawler_id in self.player.brawlers_id:
                self.writeScId(16, brawler_id)
                self.writeVint(getattr(self.player, 'Brawler_newTag', {}).get(str(brawler_id), 0))
        else:
            for _ in range(6):
                self.writeVint(0)

        # Гемы
        self.writeVint(getattr(self.player, 'gems', 0))
        self.writeVint(getattr(self.player, 'gems', 0))
        for _ in range(8):
            self.writeVint(0)
        self.writeVint(getattr(self.player, 'tutorial', 0))
        self.writeVint(1585502369)

        # Проверка бана
        if getattr(self.player, 'ban', 0) == 1:
            if hasattr(self.player, 'bantime') and self.player.bantime != "0":
                try:
                    ban_date = datetime.strptime(self.player.bantime, "%d.%m.%Y")
                    today = datetime.now()
                    if ban_date > today:
                        days_left = (ban_date - today).days + 1
                        self.player.err_code = 11
                        LoginFailedMessage(self.client, self.player, f"ОСТАЛОСЬ {days_left} ДНЕЙ.\nВаш ID: {self.player.low_id}\nПричина: {self.player.baninfo}\n\nДАТА: {datetime.now().strftime('%H:%M:%S | %d.%m.%Y')}\n\nОбратитесь в поддержку сервера если считаете блокировку ошибочной. Мы будем рады вам помочь.").send()
                    else:
                        self.player.ban = 0        	   	   
                        db.replaceValue('ban', self.player.ban)
                        self.player.bantime = "0"
                        db.replaceValue('bantime', self.player.bantime)
                        self.player.err_code = 1
                        LoginFailedMessage(self.client, self.player, "ВЫ РАЗБЛОКИРОВАНЫ!\n\nДАТА: {datetime.now().strftime('%H:%M:%S | %d.%m.%Y')}\n\nПерезайдите в игру.").send()                        	   	                       
                except ValueError as e:
                	self.player.err_code = 1
                	LoginFailedMessage(self.client, self.player, f"ОШИБКА РАЗБЛОКИРОВКИ!\n\n{str(e)}\n\nВаш ID: {self.player.low_id}\nПричина: {self.player.baninfo}\n\nДАТА: {datetime.now().strftime('%H:%M:%S | %d.%m.%Y')}\n\nОбратитесь в поддержку сервера.").send()
            else:
            	self.player.err_code = 1
            	LoginFailedMessage(self.client, self.player, f"ОШИБКА РАЗБЛОКИРОВКИ!\n\n{str(e)}\n\nВаш ID: {self.player.low_id}\nПричина: {self.player.baninfo}\n\nДАТА: {datetime.now().strftime('%H:%M:%S | %d.%m.%Y')}\n\nОбратитесь в поддержку сервера.").send()
        elif getattr(self.player, 'ban', 0) == 2:
            self.player.err_code = 11
            LoginFailedMessage(self.client, self.player, f"ВЫ ЗАБЛОКИРОВАНЫ НАВСЕГДА.\nВаш ID: {self.player.low_id}\nПричина: {self.player.baninfo}\n\nДАТА: {datetime.now().strftime('%H:%M:%S | %d.%m.%Y')}\n\nОбратитесь в поддержку сервера если считаете блокировку ошибочной.").send()