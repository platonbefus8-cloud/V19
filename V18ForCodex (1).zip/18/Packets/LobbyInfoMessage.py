from Utils.Writer import Writer
import sys
import json
import os
from datetime import datetime

_BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_CONFIG_PATH = os.path.join(_BASE_DIR, 'config.json')

def _grad(text, colors):
    result = ""
    n = len(colors)
    for i, ch in enumerate(text):
        if ch == ' ':
            result += ' '
        else:
            c = colors[i % n]
            result += f"<c{c}>{ch}</c>"
    return result

def _get_online():
    # Берём через sys.modules — нет риска циклического импорта
    main_mod = sys.modules.get('__main__') or sys.modules.get('main')
    if main_mod and hasattr(main_mod, 'Server'):
        return main_mod.Server.Online
    # Фоллбэк — config.json
    try:
        with open(_CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f).get('Online', 0)
    except Exception:
        return 0

class LobbyInfoMessage(Writer):

    def __init__(self, client, player, count):
        super().__init__(client)
        self.id = 23457
        self.player = player
        self.count = count

    def encode(self):
        online = _get_online()
        now = datetime.now().strftime('%H:%M')

        title = _grad("Angel Brawl", [
            "7E37B9","8A49C8","965BD7","A26DE6","AE7FF5",
            "BA91FF","C6A3FF","D2B5FF","DEC7FF","EAD9FF","F0E8FF"
        ])

        tg_line = _grad("TG: @AngelBrawl_official", [
            "5BC8FF","4DB8FF","3FA8FF","2E98EF","5BC8FF",
            "4DB8FF","3FA8FF","2E98EF","5BC8FF","4DB8FF",
            "3FA8FF","2E98EF","5BC8FF","4DB8FF","3FA8FF",
            "2E98EF","5BC8FF","4DB8FF","3FA8FF","2E98EF",
            "5BC8FF","4DB8FF","3FA8FF","2E98EF"
        ])

        online_line = _grad(f"Онлайн: {online}", [
            "4CFF72","3DEF63","2EDF54","1FCF45","4CFF72",
            "3DEF63","2EDF54","1FCF45","4CFF72","3DEF63",
            "2EDF54","1FCF45","4CFF72","3DEF63","2EDF54"
        ])

        time_line = _grad(f"Время: {now}", [
            "FFD700","FFBE00","FFA500","FF8C00","FFD700",
            "FFBE00","FFA500","FF8C00","FFD700","FFBE00",
            "FFA500","FF8C00","FFD700","FFBE00","FFA500"
        ])

        lobby_text = (
            title + "\n"
            + tg_line + "\n"
            + online_line + "\n"
            + time_line
            + "\n" * 100
        )

        self.writeVint(self.count)
        self.writeString(lobby_text)
        self.writeVint(0)
