"""
Монитор трофеев — каждые N секунд проверяет всех игроков в БД.
Если у кого-то trophies выросли на >THRESHOLD за интервал — пишет в suspicious.json.
Запускается как отдельный процесс (systemd-сервис).
"""
import json
import sqlite3
import time
from datetime import datetime

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from AntiCheat.SuspiciousTracker import report_trophy_jump

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'Database', 'Player', 'data.db')
CHECK_INTERVAL = 10
TROPHY_THRESHOLD = 100


def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.execute('PRAGMA journal_mode=WAL;')
    return conn


def load_all_trophies():
    """Возвращает {low_id: (name, trophies)}"""
    try:
        conn = _connect()
        cur = conn.cursor()
        cur.execute("SELECT info FROM players")
        result = {}
        for (raw,) in cur.fetchall():
            try:
                info = json.loads(raw)
                low_id = info.get('lowID')
                if low_id is None:
                    continue
                result[int(low_id)] = (info.get('name', '?'), int(info.get('trophies', 0)))
            except Exception:
                continue
        conn.close()
        return result
    except Exception as e:
        print('[TrophyMonitor] DB error:', e)
        return {}


def main():
    print('[TrophyMonitor] Started. Interval=%ss, Threshold=%s' % (CHECK_INTERVAL, TROPHY_THRESHOLD))
    prev = {}
    while True:
        try:
            current = load_all_trophies()
            now = time.time()
            for low_id, (name, trophies) in current.items():
                if low_id in prev:
                    prev_name, prev_trophies = prev[low_id]
                    delta = trophies - prev_trophies
                    if delta > TROPHY_THRESHOLD:
                        report_trophy_jump(
                            low_id=low_id,
                            name=name,
                            before=prev_trophies,
                            after=trophies,
                            seconds=CHECK_INTERVAL
                        )
            prev = current
        except Exception as e:
            print('[TrophyMonitor] loop error:', e)
        time.sleep(CHECK_INTERVAL)


if __name__ == '__main__':
    main()
