"""
AntiCheat: отслеживает подозрительно быстрый рост трофеев.
Пишет подозрительных в JSON/suspicious.json
"""
import json
import os
import time
from datetime import datetime

SUSPICIOUS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    'JSON', 'suspicious.json'
)
TROPHY_THRESHOLD = 100    # сколько трофеев за CHECK_INTERVAL = подозрительно
CHECK_INTERVAL = 10       # секунд между проверками
MAX_ENTRIES = 500


def _load():
    try:
        with open(SUSPICIOUS_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if not isinstance(data, list):
                return []
            return data
    except Exception:
        return []


def _save(data):
    try:
        data = data[-MAX_ENTRIES:]
        with open(SUSPICIOUS_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print('[AntiCheat] save error:', e)
        return False


def add_suspicious(low_id, name, reason, details, trophies_before=None, trophies_after=None):
    """
    Универсальная запись подозрительного игрока.
    reason: 'trophy_jump' и т.п.
    details: человекочитаемое описание
    """
    data = _load()
    # Если уже есть pending-запись по этому игроку с тем же reason — не дублируем
    for item in data:
        if (item.get('low_id') == low_id
                and item.get('reason') == reason
                and item.get('status') == 'pending'):
            # Обновим последнее значение
            item['details'] = details
            item['at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            item['ts'] = int(time.time())
            if trophies_after is not None:
                item['trophies_after'] = trophies_after
            _save(data)
            return item

    entry = {
        'low_id': low_id,
        'name': name,
        'reason': reason,
        'details': details,
        'status': 'pending',      # pending / ignored / banned
        'at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'ts': int(time.time()),
    }
    if trophies_before is not None:
        entry['trophies_before'] = trophies_before
    if trophies_after is not None:
        entry['trophies_after'] = trophies_after

    data.append(entry)
    _save(data)
    print(f'[AntiCheat] SUSPICIOUS {name} (ID {low_id}): {details}')
    return entry


def report_trophy_jump(low_id, name, before, after, seconds):
    delta = after - before
    details = f'+{delta} трофеев за {seconds}с (было {before}, стало {after})'
    return add_suspicious(
        low_id, name, 'trophy_jump', details,
        trophies_before=before, trophies_after=after
    )


def get_all():
    return _load()


def set_status(ts, status):
    data = _load()
    changed = False
    for item in data:
        if item.get('ts') == ts:
            item['status'] = status
            changed = True
            break
    if changed:
        _save(data)
    return changed


def remove(ts):
    data = _load()
    new_data = [x for x in data if x.get('ts') != ts]
    if len(new_data) != len(data):
        _save(new_data)
        return True
    return False


def clear():
    _save([])
