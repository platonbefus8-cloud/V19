import json
import sqlite3
from collections import OrderedDict

def reset_trophy_season():
    # Настройки
    MAX_TROPHIES_PER_BRAWLER = 500  # Максимальное количество трофеев на 1 персонажа
    REWARD_TYPE = 1  # 1 = gems, 2 = tickets, 3 = gold
    UPDATE_LEAGUE_REWARD = True  # Обновлять ли leagueReward
    ADD_BOX_REWARD = False
    BONUS_BOXES_PER_1000_TROPHIES = 0
    
    REWARD_FACTOR = 10  # 1 монета за 10 трофеев
    GEMS_FACTOR = 20  # 1 гем за 100 трофеев  
    TICKETS_FACTOR = 50  # 1 билет за 50 трофеев
    
    db_path = "Database/Player/data.db"
    
    def get_league_reward(trophies):
        if trophies <= 5: return 2
        elif trophies <= 10: return 3
        elif trophies <= 20: return 4
        elif trophies <= 30: return 5
        elif trophies <= 40: return 6
        elif trophies <= 60: return 7
        elif trophies <= 100: return 8
        elif trophies <= 150: return 9
        elif trophies <= 200: return 10
        elif trophies <= 250: return 11
        elif trophies <= 300: return 12
        elif trophies <= 350: return 13
        elif trophies <= 400: return 14
        elif trophies <= 450: return 15
        elif trophies <= 500: return 16
        elif trophies <= 550: return 17
        elif trophies <= 600: return 18
        elif trophies <= 650: return 19
        elif trophies <= 700: return 20
        elif trophies <= 750: return 21
        elif trophies <= 800: return 22
        elif trophies <= 850: return 23
        elif trophies <= 900: return 24
        elif trophies <= 950: return 25
        elif trophies <= 1000: return 26
        elif trophies <= 1100: return 27
        elif trophies <= 1200: return 28
        elif trophies <= 1300: return 29
        elif trophies <= 1400: return 30
        elif trophies <= 1500: return 31
        elif trophies <= 1600: return 32
        elif trophies <= 1700: return 33
        elif trophies <= 1800: return 34
        elif trophies <= 1900: return 35
        elif trophies <= 2000: return 36
        elif trophies <= 2100: return 37
        elif trophies <= 2200: return 38
        elif trophies <= 2300: return 39
        elif trophies <= 2400: return 40
        elif trophies <= 2500: return 41
        elif trophies <= 2600: return 42
        elif trophies <= 2700: return 43
        elif trophies <= 2800: return 44
        elif trophies <= 2900: return 45
        elif trophies <= 3000: return 46
        elif trophies <= 3100: return 47
        elif trophies <= 3200: return 48
        elif trophies <= 3300: return 49
        elif trophies <= 3400: return 50
        elif trophies <= 3500: return 51
        elif trophies <= 3600: return 52
        elif trophies <= 3700: return 53
        elif trophies <= 3800: return 54
        elif trophies <= 3900: return 55
        elif trophies <= 4000: return 56
        elif trophies <= 4150: return 57
        elif trophies <= 4300: return 58
        elif trophies <= 4500: return 59
        elif trophies <= 4750: return 60
        elif trophies <= 5000: return 61
        elif trophies <= 5150: return 62
        elif trophies <= 5300: return 63
        elif trophies <= 5500: return 64
        elif trophies <= 5750: return 65
        elif trophies <= 6000: return 66
        elif trophies <= 6150: return 67
        elif trophies <= 6300: return 68
        elif trophies <= 6500: return 69
        elif trophies <= 6750: return 70
        elif trophies <= 7000: return 71
        elif trophies <= 7150: return 72
        elif trophies <= 7300: return 73
        elif trophies <= 7500: return 74
        elif trophies <= 7750: return 75
        elif trophies <= 8000: return 76
        elif trophies <= 8150: return 77
        elif trophies <= 8300: return 78
        elif trophies <= 8500: return 79
        elif trophies <= 8750: return 80
        elif trophies <= 9000: return 81
        elif trophies <= 9150: return 82
        elif trophies <= 9300: return 83
        elif trophies <= 9500: return 84
        elif trophies <= 9750: return 85
        elif trophies <= 10000: return 86
        elif trophies <= 10150: return 87
        elif trophies <= 10300: return 88
        elif trophies <= 10500: return 89
        elif trophies <= 10750: return 90
        elif trophies <= 11000: return 91
        elif trophies <= 11150: return 92
        elif trophies <= 11300: return 93
        elif trophies <= 11500: return 94
        elif trophies <= 11750: return 95
        elif trophies <= 12000: return 96
        elif trophies <= 12150: return 97
        elif trophies <= 12300: return 98
        elif trophies <= 12500: return 99
        elif trophies <= 12750: return 100
        elif trophies <= 13000: return 101
        elif trophies <= 13150: return 102
        elif trophies <= 13300: return 103
        elif trophies <= 13500: return 104
        elif trophies <= 13750: return 105
        elif trophies <= 14000: return 106
        elif trophies <= 14150: return 107
        elif trophies <= 14300: return 108
        elif trophies <= 14500: return 109
        elif trophies <= 14750: return 110
        elif trophies <= 15000: return 111
        else: return 112
    
    def validateAndFixPlayerData(player_data):
        try:
            if 'info' not in player_data:
                player_data['info'] = OrderedDict()
            elif not isinstance(player_data['info'], OrderedDict):
                player_data['info'] = OrderedDict(player_data['info'])
            
            info = player_data['info']
            
            field_order = [
                "name", "lowID", "clubID", "clubRole", "isFBLinked", "facebookID", "tutorial", "leagueReward", "playerExp", "soloWins", "duoWins", "3vs3Wins", "gems", "gold", "starpoints", "tokensdoubler", "battleTokens", "tickets", "UnlockedSkins", "brawlerID", "skinID", "trophies", "highesttrophies", "profileIcon", "namecolor", "brawlBoxes", "bigBoxes", "winstreak", "admin", "vip", "viptime", "ban", "bantime", "baninfo", "title", "questBPvin", "questBPvininfo", "questBP", "questBPtime", "questBPinfo", "sbros", "sbroscost", "sbrosinfo", "last_seen_message_id", "online", "gadget", "starpower", "DoNotDistrub", "roomID", "brawlersSkins", "brawlersTrophies",	 "brawlersTrophiesForRank", "brawlersUpgradePoints", "brawlerPowerLevel", "UnlockedBrawlers", "brawlerStarPower", "wiver"
            ]
            
            required_fields = {
                "name": "Player",
                "lowID": 0,
                "clubID": 0,
                "clubRole": 0,
                "isFBLinked": 0,
                "facebookID": "None",
                "tutorial": 2,
                "leagueReward": 1,
                "playerExp": 0,
                "soloWins": 0,
                "duoWins": 0,
                "3vs3Wins": 0,
                "gems": 0,
                "gold": 0,
                "starpoints": 0,
                "tokensdoubler": 0,
                "battleTokens": 200,
                "tickets": 0,
                "UnlockedSkins": [],
                "brawlerID": 0,
                "skinID": 0,
                "trophies": 0,
                "highesttrophies": 0,
                "profileIcon": 0,
                "namecolor": 0,
                "brawlBoxes": 0,
                "bigBoxes": 0,
                "winstreak": 0,
                "admin": 0,
                "vip": 0,
                "viptime": "0",
                "ban": 0,
                "bantime": "0",
                "baninfo": "ОТСУТСТВУЕТ",
                "title": "ОТСУТСТВУЕТ",
                "questBPvin": 0,
                "questBPvininfo": 0,
                "questBP": 0,
                "questBPtime": 0,
                "questBPinfo": 0,
                "sbros": 0,
                "sbroscost": 0,
                "sbrosinfo": 0,
                "last_seen_message_id": 0,
                "online": 0,
                "gadget": None,
                "starpower": None,
                "DoNotDistrub": 0,
                "roomID": 0,
                "wiver": 2
            }
            
            new_info = OrderedDict()
            
            for field in field_order:
                if field in info:
                    new_info[field] = info[field]
                else:
                    new_info[field] = required_fields[field]
            
            player_data['info'] = new_info
            
            brawler_dicts = ['brawlersSkins', 'brawlersTrophies', 'brawlersTrophiesForRank', 'brawlersUpgradePoints', 'brawlerPowerLevel', 'UnlockedBrawlers', 'brawlerStarPower']
            
            for brawler_dict in brawler_dicts:
                if brawler_dict not in player_data['info'] or not isinstance(player_data['info'][brawler_dict], dict):
                    player_data['info'][brawler_dict] = {}
                
                ordered_brawler_dict = OrderedDict()
                for i in range(27):
                    key = str(i)
                    if key in player_data['info'][brawler_dict]:
                        ordered_brawler_dict[key] = player_data['info'][brawler_dict][key]
                    else:
                        if brawler_dict == 'UnlockedBrawlers' and i == 0:
                            ordered_brawler_dict[key] = 1
                        else:
                            ordered_brawler_dict[key] = 0
                
                player_data['info'][brawler_dict] = ordered_brawler_dict
            
            if player_data['info']['trophies'] < 0:
                player_data['info']['trophies'] = 0
            if player_data['info']['highesttrophies'] < player_data['info']['trophies']:
                player_data['info']['highesttrophies'] = player_data['info']['trophies']
            
            if player_data['info']['gems'] < 0:
                player_data['info']['gems'] = 0
            if player_data['info']['gold'] < 0:
                player_data['info']['gold'] = 0
            
            return player_data
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в validateAndFixPlayerData: {e}")
            return player_data

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='players'")
        if not cursor.fetchone():
            print("Таблица players не найдена в базе данных!")
            conn.close()
            return
        
        cursor.execute("SELECT token, info FROM players")
        players = cursor.fetchall()
        
        if not players:
            print("В базе данных нет игроков!")
            conn.close()
            return
        
        processed_count = 0
        total_reset_trophies_all = 0
        
        for token, info_json in players:
            try:
                player_data = {'token': token, 'info': json.loads(info_json, object_pairs_hook=OrderedDict)}
                player_data = validateAndFixPlayerData(player_data)
                
                player_info = player_data['info']
                brawlers_trophies = player_info['brawlersTrophies']
                total_reset_trophies = 0
                
                current_total_trophies = sum(brawlers_trophies.values())
                
                for brawler_id, trophies in brawlers_trophies.items():
                    if trophies > MAX_TROPHIES_PER_BRAWLER:
                        reset_trophies = trophies - MAX_TROPHIES_PER_BRAWLER
                        total_reset_trophies += reset_trophies
                        brawlers_trophies[brawler_id] = MAX_TROPHIES_PER_BRAWLER
                
                if total_reset_trophies > 0:
                    new_total_trophies = sum(brawlers_trophies.values())
                    player_info['trophies'] = new_total_trophies
                    player_info['brawlersTrophiesForRank'] = OrderedDict(brawlers_trophies)
                    
                    player_info['sbrosinfo'] = total_reset_trophies
                    
                    if REWARD_TYPE == 1:
                        gems = total_reset_trophies // GEMS_FACTOR
                        if gems > 0:
                            player_info['sbroscost'] = gems
                            player_info['sbros'] = 1
                            reward_message = f"Начислено {gems} гемов за сброс {total_reset_trophies} трофеев"
                            print(f"Новый баланс гемов: {player_info['gems']}")
                        else:
                            reward_message = f"Сброшено {total_reset_trophies} трофеев, но награда в гемах слишком мала"
                    elif REWARD_TYPE == 2:
                        tickets = total_reset_trophies // TICKETS_FACTOR
                        if tickets > 0:
                            player_info['sbroscost'] = tickets
                            player_info['sbros'] = 2
                            reward_message = f"Начислено {tickets} билетов за сброс {total_reset_trophies} трофеев"
                            print(f"Новый баланс билетов: {player_info['tickets']}")
                        else:
                            reward_message = f"Сброшено {total_reset_trophies} трофеев, но награда в билетах слишком мала"
                    else:
                        gold = total_reset_trophies // REWARD_FACTOR
                        if gold > 0:
                            player_info['sbroscost'] = gold
                            player_info['sbros'] = 3
                            reward_message = f"Начислено {gold} монет за сброс {total_reset_trophies} трофеев"
                            print(f"Новый баланс золота: {player_info['gold']}")
                        else:
                            reward_message = f"Сброшено {total_reset_trophies} трофеев, но награда в монетах слишком мала"
                    
                    print(f"Игрок {player_info['name']} (ID: {player_info['lowID']}): {reward_message}")
                    print(f"Было трофеев: {current_total_trophies}, стало: {new_total_trophies}")
                    print(f"Обновлено brawlersTrophiesForRank")
                    
                    if UPDATE_LEAGUE_REWARD:
                        current_league_reward = player_info['leagueReward']
                        new_league_reward = get_league_reward(new_total_trophies) - 1
                        
                        if new_league_reward <= current_league_reward:
                            player_info['leagueReward'] = new_league_reward
                            print(f"Обновлён leagueReward до {new_league_reward} (было: {current_league_reward})\n")
                        else:
                            print(f"Текущий leagueReward {current_league_reward} меньше нового {new_league_reward} - не изменяем\n")
                    
                    if ADD_BOX_REWARD:
                        bonus_boxes = (total_reset_trophies // 1000) * BONUS_BOXES_PER_1000_TROPHIES
                        if bonus_boxes > 0:
                            player_info['brawlBoxes'] += bonus_boxes
                            print(f"  Начислено {bonus_boxes} бонусных ящиков")
                    
                    if new_total_trophies > player_info['highesttrophies']:
                        player_info['highesttrophies'] = new_total_trophies
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(player_info), token))
                    
                    processed_count += 1
                    total_reset_trophies_all += total_reset_trophies                
            except Exception as e:
                print(f"Ошибка при обработке игрока с токеном {token}: {e}")
                continue
        
        conn.commit()
        conn.close()
        
        print(f"\nСброс сезона трофеев завершен!")
        print(f"Обработано игроков: {processed_count}")
        print(f"Всего сброшено трофеев: {total_reset_trophies_all}")
        
    except Exception as e:
        print(f"Критическая ошибка при работе с базой данных: {e}")

if __name__ == "__main__":
    reset_trophy_season()