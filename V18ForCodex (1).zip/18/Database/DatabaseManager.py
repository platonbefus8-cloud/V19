from Logic.Player import Players
import json
import os
import sqlite3
from collections import OrderedDict
import threading
import time

class DataBase:

    def __init__(self, player=None):
        self.player = player
        self.roomType = 0
        self.mapID = 0
        self.playerCount = 0
        self.playersdata = {}
        self.clubName = ""
        self.clubdescription = ""
        self.clubregion = ""
        self.clubbadgeID = 0
        self.clubtype = 0
        self.clubtrophiesneeded = 0
        self.clubfriendlyfamily = 0
        self.clubtrophies = 0
        self.clubmembercount = 0
        self.plrids = []
        self.club_list = []
        self.club_data = []
        self.AllianceCount = 0
        self.lowplrid = 0
        self.plrrole = 0
        self.plrtrophies = 0
        self.plrname = ""
        self.plricon = 0
        self.plrnamecolor = 0
        self.requested_val = None
        self.MessageCount = 0
        self.players = []

    @staticmethod
    def createDatabaseFolders():
        try:
            folders = ['Database/Player', 'Database/Gameroom', 'Database/Club']
            for folder in folders:
                if not os.path.exists(folder):
                    os.makedirs(folder)

            db_files = [
                ('Database/Player/data.db', 'players'),
                ('Database/Gameroom/gameroom.db', 'gamerooms'), 
                ('Database/Club/club.db', 'clubs'),
                ('Database/Club/chat.db', 'chats')
            ]

            for db_file, table_name in db_files:
                conn = sqlite3.connect(db_file)
                cursor = conn.cursor()
                
                if 'Player' in db_file:
                    cursor.execute('''CREATE TABLE IF NOT EXISTS players (token TEXT PRIMARY KEY, info TEXT)''')
                elif 'Gameroom' in db_file:
                    cursor.execute('''CREATE TABLE IF NOT EXISTS gamerooms (room_id INTEGER PRIMARY KEY, info TEXT)''')
                elif 'Club/club.db' in db_file:
                    cursor.execute('''CREATE TABLE IF NOT EXISTS clubs (clubID INTEGER PRIMARY KEY, info TEXT)''')
                elif 'Club/chat.db' in db_file:
                    cursor.execute('''CREATE TABLE IF NOT EXISTS chats (clubID INTEGER PRIMARY KEY, info TEXT)''')
                
                conn.commit()
                conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в createDatabaseFolders: {e}")

    @staticmethod
    def validateAndFixPlayerData(player_data):
        try:
            if 'info' not in player_data:
                player_data['info'] = OrderedDict()
            elif not isinstance(player_data['info'], OrderedDict):
                player_data['info'] = OrderedDict(player_data['info'])
            
            info = player_data['info']
            
            field_order = [
                "name", "lowID", "clubID", "clubRole", "isFBLinked", "facebookID", "tutorial", "leagueReward", "playerExp", "soloWins", "duoWins", "3vs3Wins", "gems", "gold", "starpoints", "tokensdoubler", "battleTokens", "tickets", "UnlockedSkins", "brawlerID", "skinID", "trophies", "highesttrophies", "profileIcon", "namecolor", "brawlBoxes", "bigBoxes", "winstreak", "admin", "vip", "viptime", "ban", "bantime", "baninfo", "title", "questBPvin", "questBPvininfo", "questBP", "questBPtime", "questBPinfo", "sbros", "sbroscost", "sbrosinfo", "last_seen_message_id", "online", "gadget", "starpower", "DoNotDistrub", "roomID", "brawlersSkins", "brawlersTrophies",	 "brawlersTrophiesForRank", "brawlersUpgradePoints", "brawlerPowerLevel", "UnlockedBrawlers", "brawlerStarPower", "wiver"
            ]
            
            required_fields = {
                "name": "Player",
                "lowID": 0,
                "clubID": 0,
                "clubRole": 0,
                "isFBLinked": 0,
                "facebookID": "None",
                "tutorial": 2,
                "leagueReward": 1,
                "playerExp": 0,
                "soloWins": 0,
                "duoWins": 0,
                "3vs3Wins": 0,
                "gems": 0,
                "gold": 0,
                "starpoints": 0,
                "tokensdoubler": 0,
                "battleTokens": 200,
                "tickets": 0,
                "UnlockedSkins": [],
                "brawlerID": 0,
                "skinID": 0,
                "trophies": 0,
                "highesttrophies": 0,
                "profileIcon": 0,
                "namecolor": 0,
                "brawlBoxes": 0,
                "bigBoxes": 0,
                "winstreak": 0,
                "admin": 0,
                "vip": 0,
                "viptime": "0",
                "ban": 0,
                "bantime": "0",
                "baninfo": "ОТСУТСТВУЕТ",
                "title": "ОТСУТСТВУЕТ",
                "questBPvin": 0,
                "questBPvininfo": 0,
                "questBP": 0,
                "questBPtime": 0,
                "questBPinfo": 0,
                "sbros": 0,
                "sbroscost": 0,
                "sbrosinfo": 0,
                "last_seen_message_id": 0,
                "online": 0,
                "gadget": None,
                "starpower": None,
                "DoNotDistrub": 0,
                "roomID": 0,
                "wiver": 2
            }
            
            new_info = OrderedDict()
            
            for field in field_order:
                if field in info:
                    new_info[field] = info[field]
                else:
                    new_info[field] = required_fields[field]
            
            player_data['info'] = new_info
            
            brawler_dicts = ['brawlersSkins', 'brawlersTrophies', 'brawlersTrophiesForRank', 'brawlersUpgradePoints', 'brawlerPowerLevel', 'UnlockedBrawlers', 'brawlerStarPower']
            
            for brawler_dict in brawler_dicts:
                if brawler_dict not in player_data['info'] or not isinstance(player_data['info'][brawler_dict], dict):
                    player_data['info'][brawler_dict] = {}
                
                ordered_brawler_dict = OrderedDict()
                for i in range(27):
                    key = str(i)
                    if key in player_data['info'][brawler_dict]:
                        ordered_brawler_dict[key] = player_data['info'][brawler_dict][key]
                    else:
                        if brawler_dict == 'UnlockedBrawlers' and i == 0:
                            ordered_brawler_dict[key] = 1
                        else:
                            ordered_brawler_dict[key] = 0
                
                player_data['info'][brawler_dict] = ordered_brawler_dict
            
            if player_data['info']['trophies'] < 0:
                player_data['info']['trophies'] = 0
            if player_data['info']['highesttrophies'] < player_data['info']['trophies']:
                player_data['info']['highesttrophies'] = player_data['info']['trophies']
            
            if player_data['info']['gems'] < 0:
                player_data['info']['gems'] = 0
            if player_data['info']['gold'] < 0:
                player_data['info']['gold'] = 0
            
            return player_data
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в validateAndFixPlayerData: {e}")
            return player_data

    def updatePlayerOnlineStatus(self, low_id, online_status):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            for row in cursor.fetchall():
                token, info_json = row
                user_data = {'token': token, 'info': json.loads(info_json, object_pairs_hook=OrderedDict)}
                
                if user_data['info'].get('lowID') == low_id:
                    user_data['info']['online'] = online_status
                    
                    cursor.execute("UPDATE players SET info=? WHERE token=?", 
                                 (json.dumps(user_data['info']), token))
                    break
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в updatePlayerOnlineStatus: {e}")

    def getPlayerOnlineStatus(self, low_id):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM players")
            for row in cursor.fetchall():
                user_data = json.loads(row[0], object_pairs_hook=OrderedDict)
                if user_data.get('lowID') == low_id:
                    conn.close()
                    return user_data.get('online', 0)
            
            conn.close()
            return 0
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в getPlayerOnlineStatus: {e}")
            return 0

    def getAllOnlinePlayers(self):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            online_players = []
            cursor.execute("SELECT info FROM players")
            for row in cursor.fetchall():
                user_data = json.loads(row[0], object_pairs_hook=OrderedDict)
                if user_data.get('online', 0) == 1:
                    online_players.append({
                        'lowID': user_data.get('lowID', 0),
                        'name': user_data.get('name', 'Unknown'),
                        'trophies': user_data.get('trophies', 0),
                        'clubID': user_data.get('clubID', 0)
                    })
            
            conn.close()
            return online_players
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в getAllOnlinePlayers: {e}")
            return []

    def loadAccount(self):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='players'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE players (token TEXT PRIMARY KEY, info TEXT)''')
                conn.commit()
                conn.close()
                self.createAccount()
                return
            
            cursor.execute("SELECT info FROM players WHERE token=?", (str(self.player.token),))
            result = cursor.fetchone()
            
            if result:
                user_data = {'token': str(self.player.token), 'info': json.loads(result[0], object_pairs_hook=OrderedDict)}
                user_data = DataBase.validateAndFixPlayerData(user_data)
                
                user_data['info']['online'] = 0
                
                club_id = user_data['info'].get("clubID", 0)
                if club_id != 0:
                    club_exists = self.checkClubExists(club_id)
                    if not club_exists:
                        user_data['info']["clubID"] = 0
                        user_data['info']["clubRole"] = 0
                        print(f"[DEBUG] Клуб {club_id} не существует. ClubID и clubRole обнулены для игрока {self.player.token}")
                
                cursor.execute("UPDATE players SET info=? WHERE token=?", 
                             (json.dumps(user_data['info']), str(self.player.token)))
                conn.commit()
                
                info = user_data["info"]
                
                self.player.name = info["name"]
                self.player.tutorial = info["tutorial"]
                self.player.trophy_road = info["leagueReward"]
                self.player.low_id = info["lowID"]
                self.player.IsFacebookLinked = info["isFBLinked"]
                self.player.FacebookID = info["facebookID"]
                self.player.club_low_id = info["clubID"]
                self.player.club_role = info["clubRole"]
                self.player.player_experience = info["playerExp"]
                self.player.solo_wins = info["soloWins"]
                self.player.duo_wins = info["duoWins"]
                self.player.ThreeVSThree_wins = info["3vs3Wins"]
                self.player.gems = info["gems"]
                self.player.gold = info["gold"]
                self.player.star_points = info["starpoints"]
                self.player.tickets = info["tickets"]
                self.player.tokensdoubler = info["tokensdoubler"]
                self.player.battle_tokens = info["battleTokens"]
                self.player.brawler_id = info["brawlerID"]
                self.player.skin_id = info["skinID"]
                self.player.profile_icon = info["profileIcon"]
                self.player.brawl_boxes = info["brawlBoxes"]
                self.player.big_boxes = info["bigBoxes"]
                self.player.brawlers_skins = info["brawlersSkins"]
                self.player.name_color = info["namecolor"]
                self.player.winstreak = info["winstreak"]
                self.player.admin = info["admin"]
                self.player.vip = info["vip"]
                self.player.viptime = info["viptime"]
                self.player.ban = info["ban"]
                self.player.bantime = info["bantime"]
                self.player.baninfo = info["baninfo"]
                self.player.title = info["title"]
                self.player.questBPvin = info["questBPvin"]
                self.player.questBPvininfo = info["questBPvininfo"]
                self.player.questBP = info["questBP"]
                self.player.questBPtime = info["questBPtime"]
                self.player.questBPinfo = info["questBPinfo"]
                self.player.sbros = info["sbros"]
                self.player.sbroscost = info["sbroscost"]
                self.player.sbrosinfo = info["sbrosinfo"]
                self.player.last_seen_message_id = info["last_seen_message_id"]
                self.player.online = info["online"]
                self.player.gadget = info["gadget"]
                self.player.starpower = info["starpower"]
                self.player.DoNotDistrubMessage = info["DoNotDistrub"]
                self.player.room_id = info["roomID"]
                self.player.brawlers_trophies_in_rank = info["brawlersTrophiesForRank"]
                self.player.brawlers_upgradium = info["brawlersUpgradePoints"]
                self.player.Brawler_level = info["brawlerPowerLevel"]
                self.player.brawlers_trophies = info["brawlersTrophies"]
                self.player.UnlockedSkins = info["UnlockedSkins"]

                if hasattr(self.player, 'UnlockType') and self.player.UnlockType == "Off":
                    self.player.BrawlersUnlockedState = info["UnlockedBrawlers"]

                player_total_trophies = 0
                for BrawlerID in self.player.brawlers_trophies.keys():
                    player_total_trophies += self.player.brawlers_trophies[BrawlerID]
                self.player.trophies = player_total_trophies
                self.replaceValue('trophies', self.player.trophies)

                if self.player.trophies < info["highesttrophies"]:
                    self.player.highest_trophies = info["highesttrophies"]
                else:
                    self.player.highest_trophies = self.player.trophies
                    
                self.replaceValue('highesttrophies', self.player.highest_trophies)
            else:
                conn.close()
                self.createAccount()
                return
                
            conn.close()
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в loadAccount: {e}")
            try:
                self.createAccount()
            except Exception as create_error:
                print(f"[ОШИБКА] Ошибка при создании аккаунта: {create_error}")

    def createAccount(self):
        try:
            DataBase.createDatabaseFolders()
            
            from Logic.Player import Players
            Players.CreateNewBrawlersList()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='players'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE players (token TEXT PRIMARY KEY, info TEXT)''')
            
            cursor.execute("SELECT token FROM players WHERE token=?", (str(self.player.token),))
            if cursor.fetchone():
                print()
                conn.close()
                return
            
            cursor.execute("SELECT info FROM players")
            all_players = cursor.fetchall()
            for player_data in all_players:
                try:
                    player_info = json.loads(player_data[0], object_pairs_hook=OrderedDict)
                    if player_info.get('lowID') == self.player.low_id:
                        print()
                        conn.close()
                        return
                except:
                    continue

            # ГАРАНТИРОВАННОЕ создание значений по умолчанию
            data = OrderedDict([
                ("name", self.player.name),
                ("lowID", self.player.low_id),
                ("clubID", 0),
                ("clubRole", 0),
                ("isFBLinked", 0),
                ("facebookID", self.player.FacebookID),
                ("tutorial", 2),
                ("leagueReward", 1),
                ("playerExp", 0),
                ("soloWins", 0),
                ("duoWins", 0),
                ("3vs3Wins", 0),
                ("gems", 0),
                ("gold", 0),
                ("starpoints", 0),
                ("tokensdoubler", 0),
                ("battleTokens", 200),
                ("tickets", 0),
                ("UnlockedSkins", []),
                ("brawlerID", 0),
                ("skinID", 0),
                ("trophies", 0),
                ("highesttrophies", 0),
                ("profileIcon", 0),
                ("namecolor", 0),
                ("brawlBoxes", 0),
                ("bigBoxes", 0),
                ("winstreak", 0),
                ("admin", 0),
                ("vip", 0),
                ("viptime", "0"),
                ("ban", 0),
                ("bantime", "0"),
                ("baninfo", "ОТСУТСТВУЕТ"),
                ("title", "ОТСУТСТВУЕТ"),
                ("questBPvin", 0),
                ("questBPvininfo", 0),
                ("questBP", 0),
                ("questBPtime", 0),
                ("questBPinfo", 0),
                ("sbros", 0),
                ("sbroscost", 0),
                ("sbrosinfo", 0),
                ("last_seen_message_id", 0),
                ("online", 0),
                ("gadget", None),
                ("starpower", None),
                ("DoNotDistrub", 0),
                ("roomID", 0),
                ("brawlersSkins", OrderedDict([(str(i), 0) for i in range(27)])),
                ("brawlersTrophies", OrderedDict([(str(i), 0) for i in range(27)])),
                ("brawlersTrophiesForRank", OrderedDict([(str(i), 0) for i in range(27)])),
                ("brawlersUpgradePoints", OrderedDict([(str(i), 0) for i in range(27)])),
                ("brawlerPowerLevel", OrderedDict([(str(i), 0) for i in range(27)])),
                ("UnlockedBrawlers", OrderedDict([(str(i), 1 if i == 0 else 0) for i in range(27)])),
                ("brawlerStarPower", OrderedDict([(str(i), 0) for i in range(27)])),
                ("wiver", 2)
            ])

            # Принудительная валидация данных
            data = DataBase.validateAndFixPlayerData({'info': data})['info']
            
            cursor.execute("INSERT INTO players (token, info) VALUES (?, ?)",
                         (str(self.player.token), json.dumps(data)))
            conn.commit()
            conn.close()
            
            print(f"[INFO] Создан новый аккаунт: {self.player.name} (ID: {self.player.low_id})")
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в createAccount: {e}")

    def getAllPlayers(self):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='players'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE players (token TEXT PRIMARY KEY, info TEXT)''')
                conn.commit()
                conn.close()
                return []
            
            name_list = []
            cursor.execute("SELECT token, info FROM players")
            for row in cursor.fetchall():
                token, info_json = row
                user_data = {'token': token, 'info': json.loads(info_json, object_pairs_hook=OrderedDict)}
                fixed_data = DataBase.validateAndFixPlayerData(user_data)
                
                if fixed_data != user_data:
                    cursor.execute("UPDATE players SET info=? WHERE token=?", (json.dumps(fixed_data['info']), token))
                
                name_list.append(fixed_data['info'])

            conn.commit()
            conn.close()
            return name_list
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в getAllPlayers: {e}")
            return []

    def getSpecifiedValue(self, value_name):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM players WHERE token=?", (str(self.player.token),))
            result = cursor.fetchone()
            
            if result:
                user_data = {'token': str(self.player.token), 'info': json.loads(result[0], object_pairs_hook=OrderedDict)}
                user_data = DataBase.validateAndFixPlayerData(user_data)
                
                cursor.execute("UPDATE players SET info=? WHERE token=?", (json.dumps(user_data['info']), str(self.player.token)))
                conn.commit()
                
                self.requested_val = user_data['info'].get(value_name, None)
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в getSpecifiedValue: {e}")

    def replaceValue(self, value_name, new_value):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM players WHERE token=?", (str(self.player.token),))
            result = cursor.fetchone()
            
            if result:
                user_data = {'token': str(self.player.token), 'info': json.loads(result[0], object_pairs_hook=OrderedDict)}
                user_data = DataBase.validateAndFixPlayerData(user_data)
                user_data["info"][str(value_name)] = new_value
                
                cursor.execute("UPDATE players SET info=? WHERE token=?", (json.dumps(user_data['info']), str(self.player.token)))
                conn.commit()
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в replaceValue: {e}")

    def createGameroomDB(self):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Gameroom/gameroom.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='gamerooms'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE gamerooms (room_id INTEGER PRIMARY KEY, info TEXT)''')
            
            data = {
                "roomType": self.roomType,
                "mapID": self.player.map_id,
                "PlayerCount": 1,
                self.player.low_id: {
                    "host": 1,
                    "lowID": self.player.low_id,
                    "name": self.player.name,
                    "Team": self.player.team,
                    "Ready": self.player.isReady,
                    "brawlerID": self.player.brawler_id,
                    "skinID": self.player.skin_id,
                    "starpower": self.player.starpower,
                    "profileIcon": self.player.profile_icon
                }
            }
            
            cursor.execute("INSERT INTO gamerooms (room_id, info) VALUES (?, ?)",
                         (self.player.room_id, json.dumps(data)))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в createGameroomDB: {e}")

    def loadGameroom(self):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Gameroom/gameroom.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='gamerooms'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE gamerooms (room_id INTEGER PRIMARY KEY, info TEXT)''')
                conn.commit()
                conn.close()
                return
            
            cursor.execute("SELECT info FROM gamerooms WHERE room_id=?", (self.player.room_id,))
            result = cursor.fetchone()
            
            self.playersdata = {}
            if result:
                gameroom_info = json.loads(result[0])
                self.roomType = gameroom_info["roomType"]
                self.mapID = gameroom_info["mapID"]
                self.playerCount = gameroom_info["PlayerCount"]
                
                for player_key, info in gameroom_info.items():
                    if player_key not in ["PlayerCount", "mapID", "roomType"]:
                        self.playersdata[player_key] = {
                            "IsHost": info["host"],
                            "name": info["name"],
                            "Team": info["Team"],
                            "Ready": info["Ready"],
                            "LowID": player_key,
                            "profileIcon": info["profileIcon"],
                            "brawlerID": info["brawlerID"],
                            "skinID": info["skinID"],
                            "starpower": info["starpower"]
                        }
            else:
                conn_player = sqlite3.connect('Database/Player/data.db')
                cursor_player = conn_player.cursor()
                
                cursor_player.execute("SELECT info FROM players WHERE token=?", (str(self.player.token),))
                result_player = cursor_player.fetchone()
                
                if result_player:
                    user_data = json.loads(result_player[0], object_pairs_hook=OrderedDict)
                    user_data["roomID"] = 0
                    self.player.room_id = 0
                    
                    cursor_player.execute("UPDATE players SET info=? WHERE token=?", 
                                        (json.dumps(user_data), str(self.player.token)))
                    conn_player.commit()
                
                conn_player.close()
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в loadGameroom: {e}")

    def replaceGameroomValue(self, value_name, new_value, type):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Gameroom/gameroom.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM gamerooms WHERE room_id=?", (self.player.room_id,))
            result = cursor.fetchone()
            
            if result:
                gameroom_info = json.loads(result[0])
                
                if type == "room":
                    gameroom_info[str(value_name)] = new_value
                elif type == "player":
                    gameroom_info[str(value_name)] = new_value
                elif type == "removePlayer":
                    if str(new_value) in gameroom_info and gameroom_info[str(new_value)].get("host", 0) == 1:
                        cursor.execute("DELETE FROM gamerooms WHERE room_id=?", (self.player.room_id,))
                    else:
                        if str(new_value) in gameroom_info:
                            del gameroom_info[str(new_value)]
                            gameroom_info["PlayerCount"] = max(0, gameroom_info["PlayerCount"] - 1)
                else:
                    cursor.execute("DELETE FROM gamerooms WHERE room_id=?", (self.player.room_id,))
                
                if type != "removePlayer" and type != "else":
                    cursor.execute("UPDATE gamerooms SET info=? WHERE room_id=?", 
                                 (json.dumps(gameroom_info), self.player.room_id))
                
                conn.commit()
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в replaceGameroomValue: {e}")
    
    def UpdateGameroomPlayerInfo(self, low_id):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Gameroom/gameroom.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM gamerooms WHERE room_id=?", (self.player.room_id,))
            result = cursor.fetchone()
            
            if result and str(low_id) in json.loads(result[0]):
                gameroom_info = json.loads(result[0])
                
                gameroom_info[str(low_id)]["Team"] = self.player.team
                gameroom_info[str(low_id)]["Ready"] = self.player.isReady
                gameroom_info[str(low_id)]["brawlerID"] = self.player.brawler_id
                gameroom_info[str(low_id)]["skinID"] = self.player.skin_id
                gameroom_info[str(low_id)]["profileIcon"] = self.player.profile_icon
                gameroom_info[str(low_id)]["starpower"] = self.player.starpower
                
                cursor.execute("UPDATE gamerooms SET info=? WHERE room_id=?", (json.dumps(gameroom_info), self.player.room_id))
                conn.commit()
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в UpdateGameroomPlayerInfo: {e}")

    def createClub(self, clubid):
        try:
            DataBase.createDatabaseFolders()
            
            conn_club = sqlite3.connect('Database/Club/club.db')
            conn_chat = sqlite3.connect('Database/Club/chat.db')
            cursor_club = conn_club.cursor()
            cursor_chat = conn_chat.cursor()

            cursor_club.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='clubs'")
            if not cursor_club.fetchone():
                cursor_club.execute('''CREATE TABLE clubs (clubID INTEGER PRIMARY KEY, info TEXT)''')
            
            cursor_chat.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='chats'")
            if not cursor_chat.fetchone():
                cursor_chat.execute('''CREATE TABLE chats (clubID INTEGER PRIMARY KEY, info TEXT)''')

            club_data = {
                "clubID": clubid,
                "name": self.clubName,                          
                "description": self.clubdescription,
                "region": "RU",
                "badgeID": self.clubbadgeID,
                "type": self.clubtype,
                "trophiesneeded": self.clubtrophiesneeded,
                "friendlyfamily": self.clubfriendlyfamily,
                "trophies": self.player.trophies,
                "members": {
                    "totalmembers": 1,
                    str(self.player.low_id): {
                        "name": self.player.name,
                        "role": 2,
                        "trophies": self.player.trophies
                    }
                }
            }
            
            cursor_club.execute("INSERT INTO clubs (clubID, info) VALUES (?, ?)", (clubid, json.dumps(club_data)))
            
            msg_data = {
                "Total": 1,
                "1": {
                    "Event": 2,
                    "Tick": 1,
                    "PlayerID": self.player.low_id,
                    "PlayerName": self.player.name,
                    "PlayerRole": 2,
                    "Message": "Используй /help чтобы узнать доступные команды"
                }
            }
            
            cursor_chat.execute("INSERT INTO chats (clubID, info) VALUES (?, ?)", (clubid, json.dumps(msg_data)))
            
            conn_club.commit()
            conn_chat.commit()
            conn_club.close()
            conn_chat.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в createClub: {e}")

    def CountClub(self, minMembers, maxMembers, clubType, maxListLength):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Club/club.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='clubs'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE clubs (clubID INTEGER PRIMARY KEY, info TEXT)''')
                conn.commit()
                conn.close()
                return
            
            self.club_list = []
            self.club_data = []
            self.AllianceCount = 0
            
            cursor.execute("SELECT clubID, info FROM clubs")
            all_clubs = cursor.fetchall()
            
            filtered_clubs = []
            
            for club_id, info_json in all_clubs:
                try:
                    clubInfo = json.loads(info_json)
                    
                    member_count = clubInfo.get('members', {}).get('totalmembers', 0)
                    club_type = clubInfo.get('type', 0)
                    
                    if (member_count >= minMembers and 
                        member_count <= maxMembers and
                        club_type <= clubType):
                        
                        filtered_clubs.append((club_id, clubInfo))
                        
                except Exception as e:
                    print(f"[ОШИБКА] Ошибка при обработке клуба {club_id}: {e}")
                    continue
            
            filtered_clubs.sort(key=lambda x: x[1].get('trophies', 0), reverse=True)
            
            for club_id, clubInfo in filtered_clubs[:maxListLength]:
                self.club_list.append(club_id)
                self.club_data.append(clubInfo)
                self.AllianceCount += 1
            
            print()
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в CountClub: {e}")
            self.club_list = []
            self.club_data = []
            self.AllianceCount = 0

    def loadClub(self, clubid):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Club/club.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='clubs'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE clubs (clubID INTEGER PRIMARY KEY, info TEXT)''')
                conn.commit()
                conn.close()
                return None
            
            cursor.execute("SELECT info FROM clubs WHERE clubID=?", (clubid,))
            result = cursor.fetchone()
            
            club_data = None
            if result:
                club_data = json.loads(result[0])
                self.plrids = []
                self.clubName = club_data["name"]
                self.clubdescription = club_data["description"]
                self.clubregion = club_data["region"]
                self.clubbadgeID = club_data["badgeID"]
                self.clubtype = club_data["type"]
                self.clubtrophiesneeded = club_data["trophiesneeded"]
                self.clubfriendlyfamily = club_data["friendlyfamily"]
                self.clubtrophies = club_data["trophies"]
                self.clubmembercount = club_data["members"]["totalmembers"]
                
                for plridentifier, data in club_data["members"].items():
                    if plridentifier != "totalmembers":
                        self.plrids.append(int(plridentifier))
                
                print()
            else:
                pass
            
            conn.close()
            return club_data
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в loadClub: {e}")
            return None

    def checkClubExists(self, clubid):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Club/club.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='clubs'")
            if not cursor.fetchone():
                conn.close()
                return False
            
            cursor.execute("SELECT clubID FROM clubs WHERE clubID=?", (clubid,))
            result = cursor.fetchone()
            
            conn.close()
            return result is not None
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в checkClubExists: {e}")
            return False
                
    def AddMember(self, AllianceID, PlayerID, PlayerName, Action):
        try:
            DataBase.createDatabaseFolders()
            
            conn_club = sqlite3.connect('Database/Club/club.db')
            conn_chat = sqlite3.connect('Database/Club/chat.db')
            cursor_club = conn_club.cursor()
            cursor_chat = conn_chat.cursor()
            
            cursor_club.execute("SELECT info FROM clubs WHERE clubID=?", (AllianceID,))
            result = cursor_club.fetchone()
            
            if result:
                club_data = json.loads(result[0])

                if Action == 0:
                    cursor_club.execute("DELETE FROM clubs WHERE clubID=?", (AllianceID,))
                    cursor_chat.execute("DELETE FROM chats WHERE clubID=?", (AllianceID,))

                elif Action == 1:
                    club_data['members']['totalmembers'] += 1
                    club_data['members'][str(PlayerID)] = {
                        "name": PlayerName,
                        "role": 1,
                        "trophies": 0
                    }
                    
                    player_trophies = 0
                    try:
                        conn_player = sqlite3.connect('Database/Player/data.db')
                        cursor_player = conn_player.cursor()
                        cursor_player.execute("SELECT info FROM players WHERE token IN (SELECT token FROM players WHERE info LIKE ?)", (f'%"lowID":{PlayerID}%',))
                        player_result = cursor_player.fetchone()
                        if player_result:
                            player_info = json.loads(player_result[0])
                            player_trophies = player_info.get('trophies', 0)
                        conn_player.close()
                    except:
                        pass
                    
                    club_data['trophies'] += player_trophies
                    club_data['members'][str(PlayerID)]["trophies"] = player_trophies
                    
                    cursor_club.execute("UPDATE clubs SET info=? WHERE clubID=?", (json.dumps(club_data), AllianceID))

                elif Action == 2:
                    try:
                        if str(PlayerID) in club_data['members']:
                            player_trophies = club_data['members'][str(PlayerID)].get("trophies", 0)
                            club_data['trophies'] = max(0, club_data['trophies'] - player_trophies)
                        
                        club_data['members']['totalmembers'] -= 1
                        club_data['members'].pop(str(PlayerID))
                        cursor_club.execute("UPDATE clubs SET info=? WHERE clubID=?", (json.dumps(club_data), AllianceID))
                    except:
                        pass

                conn_club.commit()
                conn_chat.commit()
            
            conn_club.close()
            conn_chat.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в AddMember: {e}")

    def GetMemberData(self, Low_id):
        try:
            self.players = DataBase.getAllPlayers(self)
            if self.players:
                for player_info in self.players:
                    if player_info['lowID'] == int(Low_id):
                        self.lowplrid = player_info['lowID']
                        self.plrrole = player_info["clubRole"]
                        self.plrtrophies = player_info["trophies"]
                        self.plrname = player_info["name"]
                        self.plricon = player_info["profileIcon"]
                        self.plrnamecolor = player_info["namecolor"]
                        self.plronline = player_info["online"]
                        self.plrban = player_info["ban"]
                        self.plrvip = player_info["vip"]
                        self.plradmin = player_info["admin"]
                        break
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в GetMemberData: {e}")
            self.lowplrid = 1
            self.plrrole = 2
            self.plrtrophies = 0
            self.plrname = "Bot"
            self.plricon = 1
            self.plrnamecolor = 2
            self.plronline = 0
            self.plrban = 0
            self.plrvip = 0
            self.plradmin = 0

    def replaceClubValue(self, target, inf1, inf2, inf3, inf4, inf5):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Club/club.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM clubs WHERE clubID=?", (self.player.club_low_id,))
            result = cursor.fetchone()
            
            if result:
                club_data = json.loads(result[0])
                club_data['description'] = inf1
                club_data['badgeID'] = inf2
                club_data['type'] = inf3
                club_data['trophiesneeded'] = inf4
                club_data['friendlyfamily'] = inf5
                
                cursor.execute("UPDATE clubs SET info=? WHERE clubID=?", 
                             (json.dumps(club_data), self.player.club_low_id))
                conn.commit()
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в replaceClubValue: {e}")

    def GetmsgCount(self, clubID):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Club/chat.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='chats'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE chats (clubID INTEGER PRIMARY KEY, info TEXT)''')
                conn.commit()
                conn.close()
                self.MessageCount = 0
                return
                
            cursor.execute("SELECT info FROM chats WHERE clubID=?", (clubID,))
            result = cursor.fetchone()
            
            if result:
                data = json.loads(result[0])
                self.MessageCount = data['Total']
            else:
                self.MessageCount = 0
                
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в GetmsgCount: {e}")
            self.MessageCount = 0

    def AddMessage(self, clubID, msgID, event, tick, playerID, playerName, playerRole, message):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Club/chat.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM chats WHERE clubID=?", (clubID,))
            result = cursor.fetchone()
            
            if result:
                data = json.loads(result[0])
                
                new_message_id = data['Total'] + 1
                data['Total'] = new_message_id
                
                data[str(new_message_id)] = {
                    "Event": event,
                    "Tick": new_message_id,
                    "PlayerID": playerID,
                    "PlayerName": playerName,
                    "PlayerRole": playerRole,
                    "Message": message
                }
                
                cursor.execute("UPDATE chats SET info=? WHERE clubID=?", (json.dumps(data), clubID))
                conn.commit()
                
                self.MessageCount = new_message_id
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в AddMessage: {e}")

    def DeleteMessage(self, clubID, msgID):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Club/chat.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM chats WHERE clubID=?", (clubID,))
            result = cursor.fetchone()
            
            if result:
                data = json.loads(result[0])
                if str(msgID) in data:
                    del data[str(msgID)]
                    data['Total'] -= 1
                    
                    cursor.execute("UPDATE chats SET info=? WHERE clubID=?", 
                                 (json.dumps(data), clubID))
                    conn.commit()
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в DeleteMessage: {e}")

    def loadmsg(self, clubID, msgID):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Club/chat.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT info FROM chats WHERE clubID=?", (clubID,))
            result = cursor.fetchone()
            
            if result:
                data = json.loads(result[0])
                if str(msgID) in data:
                    msg_data = data[str(msgID)]
                    self.lowplrid = msg_data["PlayerID"]
                    self.plrname = msg_data["PlayerName"]
                    self.plrrole = msg_data["PlayerRole"]
                    self.plrtrophies = 0
                    self.plricon = 0
                    self.plrnamecolor = 0
            
            conn.close()
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в loadmsg: {e}")

    def GetLeaderboardByBrawler(self, ID):
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='players'")
            if not cursor.fetchone():
                cursor.execute('''CREATE TABLE players (token TEXT PRIMARY KEY, info TEXT)''')
                conn.commit()
                conn.close()
                return []
            
            leaderboard_data = []
            cursor.execute("SELECT token, info FROM players")
            for row in cursor.fetchall():
                token, info_json = row
                user_data = {'token': token, 'info': json.loads(info_json, object_pairs_hook=OrderedDict)}
                fixed_data = DataBase.validateAndFixPlayerData(user_data)
                
                if fixed_data != user_data:
                    cursor.execute("UPDATE players SET info=? WHERE token=?", (json.dumps(fixed_data['info']), token))
                
                info = fixed_data['info']
                leaderboard_data.append([
                    info['lowID'],
                    info['name'],
                    info,
                    info['profileIcon'],
                    info['namecolor'],
                    info['clubID']
                ])
            
            conn.commit()
            conn.close()
            return leaderboard_data[:100]
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в GetLeaderboardByBrawler: {e}")
            return []

    def GetLeaderboardByRegionBrawler(self, brawler_id, region):
        try:
            all_players = self.GetLeaderboardByBrawler(brawler_id)
            return all_players
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в GetLeaderboardByRegionBrawler: {e}")
            return []

    def GetLeaderboardByBrawlerID(self, brawler_id):
        return self.GetLeaderboardByBrawler(brawler_id)

    def getPlayerBrawlerTrophies(self, player_info, brawler_id):
        try:
            brawler_trophies = player_info.get('brawlersTrophies', {})
            return brawler_trophies.get(str(brawler_id), 0)
        except:
            return 0

    def joinClub(self, clubID):
        try:
            
            self.player.club_low_id = clubID
            self.player.club_role = 1
            
            self.replaceValue('clubID', clubID)
            self.replaceValue('clubRole', 1)
            
            self.AddMember(clubID, self.player.low_id, self.player.name, 1)            
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка при присоединении к клубу: {e}")

    def leaveClub(self):
        try:
            clubID = self.player.club_low_id
            
            self.AddMember(clubID, self.player.low_id, self.player.name, 2)
            
            self.player.club_low_id = 0
            self.player.club_role = 0
            
            self.replaceValue('clubID', 0)
            self.replaceValue('clubRole', 0)            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка при выходе из клуба: {e}")

    @staticmethod
    def cleanupInvalidAccounts():
        try:
            DataBase.createDatabaseFolders()
            
            conn = sqlite3.connect('Database/Player/data.db')
            cursor = conn.cursor()
            
            cursor.execute("SELECT token, info FROM players")
            accounts_to_delete = []
            
            for row in cursor.fetchall():
                token, info_json = row
                try:
                    user_data = json.loads(info_json, object_pairs_hook=OrderedDict)
                    
                    player_name = user_data.get('name', '')
                    player_low_id = user_data.get('lowID', 0)
                    
                    if player_name == "Guest" or player_low_id == 0:
                        accounts_to_delete.append(token)
                        print(f"[CLEANUP] Найден невалидный аккаунт для удаления: {player_name} (ID: {player_low_id})")
                        
                except Exception as e:
                    print(f"[CLEANUP] Ошибка при обработке аккаунта {token}: {e}")
                    continue
            
            if accounts_to_delete:
                placeholders = ','.join('?' for _ in accounts_to_delete)
                cursor.execute(f"DELETE FROM players WHERE token IN ({placeholders})", accounts_to_delete)
                conn.commit()
                print(f"[CLEANUP] Удалено {len(accounts_to_delete)} невалидных аккаунтов")
            else:
                print("[CLEANUP] Невалидные аккаунты не найдены")
            
            conn.close()
            
        except Exception as e:
            print(f"[ОШИБКА] Ошибка в cleanupInvalidAccounts: {e}")

    @staticmethod
    def startCleanupScheduler():
        def cleanup_worker():
            while True:
                try:
                    time.sleep(300)  # 5 минут
                    DataBase.cleanupInvalidAccounts()
                except Exception as e:
                    print(f"[ОШИБКА] Ошибка в cleanup_worker: {e}")
        
        cleanup_thread = threading.Thread(target=cleanup_worker, daemon=True)
        cleanup_thread.start()