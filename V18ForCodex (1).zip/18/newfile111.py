import logging
import socket
import time
import os
import json
import hashlib
import secrets
import struct
import psutil
from threading import Thread, Lock
from collections import defaultdict, deque

logging.basicConfig(filename="security.log", level=logging.INFO, filemode='w',
                   format='%(asctime)s - %(levelname)s - %(message)s')

def security_log(message, level="INFO", ip=None):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    ip_info = f" [{ip}]" if ip else ""
    
    if level == "CRITICAL":
        color = '\033[91m'
        logging.critical(f"{ip_info} {message}")
    elif level == "WARNING":
        color = '\033[93m'
        logging.warning(f"{ip_info} {message}")
    else:
        color = '\033[92m'
        logging.info(f"{ip_info} {message}")
    
    print(f"{color}[{level}] {timestamp}{ip_info} {message}\033[0m")

class SystemMonitor:
    def __init__(self):
        self.last_check = time.time()
        
    def get_system_status(self):
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            net_io = psutil.net_io_counters()
            
            status = {
                'cpu': cpu_percent,
                'memory_used': memory.percent,
                'memory_available': memory.available // (1024 * 1024),
                'disk_used': disk.percent,
                'network_sent': net_io.bytes_sent // (1024 * 1024),
                'network_recv': net_io.bytes_recv // (1024 * 1024),
                'connections': len(psutil.net_connections()),
                'timestamp': time.time()
            }
            
            if cpu_percent > 80 or memory.percent > 85:
                security_log(f"High system load - CPU: {cpu_percent}% RAM: {memory.percent}%", "WARNING")
                
            return status
        except Exception as e:
            return {'error': str(e)}

class RateLimiter:
    def __init__(self):
        self.buckets = defaultdict(dict)
        self.limits = {
            'CONNECTION': {'tokens': 10, 'refill': 1, 'max': 10},
            'LOGIN': {'tokens': 3, 'refill': 0.3, 'max': 3},
            'CHAT': {'tokens': 20, 'refill': 5, 'max': 20},
            'GAME_ACTION': {'tokens': 50, 'refill': 10, 'max': 50},
            'PACKET': {'tokens': 100, 'refill': 20, 'max': 100}
        }
    
    def is_allowed(self, ip, action_type):
        bucket_key = f"{ip}_{action_type}"
        now = time.time()
        
        if bucket_key not in self.buckets:
            self.buckets[bucket_key] = {
                'tokens': self.limits[action_type]['tokens'],
                'last_refill': now
            }
        
        bucket = self.buckets[bucket_key]
        time_passed = now - bucket['last_refill']
        
        bucket['tokens'] = min(
            self.limits[action_type]['max'],
            bucket['tokens'] + time_passed * self.limits[action_type]['refill']
        )
        bucket['last_refill'] = now
        
        if bucket['tokens'] >= 1:
            bucket['tokens'] -= 1
            return True
        else:
            return False

class PacketValidator:
    def __init__(self):
        self.packet_history = defaultdict(lambda: deque(maxlen=50))
        self.packet_timing = defaultdict(lambda: deque(maxlen=20))
        
    def validate_packet(self, ip, packet_id, data, packet_size):
        current_time = time.time()
        
        if packet_size > 1000000:
            return False, "packet_size_exceeded"
            
        if packet_id == 0 or packet_id > 20000:
            return False, "invalid_packet_id"
        
        timing_data = self.packet_timing[ip]
        timing_data.append(current_time)
        
        if len(timing_data) > 10:
            time_diffs = [timing_data[i+1] - timing_data[i] for i in range(len(timing_data)-1)]
            avg_diff = sum(time_diffs) / len(time_diffs)
            if avg_diff < 0.01:
                return False, "packet_flood"
        
        history = self.packet_history[ip]
        
        if packet_id == 10110 and 10101 not in history:
            return False, "invalid_sequence"
            
        history.append(packet_id)
        
        if len(data) > 0:
            null_bytes = data.count(b'\x00')
            if null_bytes > len(data) * 0.3:
                return False, "suspicious_content"
                
            if data[:4] == b'\x00\x00\x00\x00':
                return False, "null_packet"
        
        return True, "valid"

class SpoofingProtection:
    def __init__(self):
        self.tcp_signatures = defaultdict(lambda: deque(maxlen=100))
        self.connection_patterns = defaultdict(dict)
        
    def analyze_connection_pattern(self, ip, initial_data):
        if len(initial_data) < 7:
            return False, "invalid_handshake"
            
        try:
            packet_id = int.from_bytes(initial_data[:2], 'big')
            length = int.from_bytes(initial_data[2:5], 'big')
            
            if packet_id not in [10101, 10100, 10108]:
                return False, "unexpected_initial_packet"
                
            signature = hashlib.md5(initial_data).hexdigest()
            self.tcp_signatures[ip].append(signature)
            
            signatures = self.tcp_signatures[ip]
            if len(signatures) > 5:
                unique_signatures = len(set(signatures))
                if unique_signatures > 3:
                    return False, "connection_spoofing"
                    
        except Exception:
            return False, "malformed_handshake"
            
        return True, "legitimate"

class ProxyDetection:
    def __init__(self):
        self.known_proxy_ports = {8080, 3128, 8081, 1080, 8888, 8118, 443}
        self.suspicious_headers = [
            'X-Forwarded-For', 'X-Real-IP', 'X-ProxyUser', 
            'Proxy-Connection', 'Client-IP', 'Via'
        ]
        
    def detect_proxy(self, ip, port, initial_data):
        if port in self.known_proxy_ports:
            return True, "known_proxy_port"
            
        try:
            data_str = initial_data.decode('latin-1', errors='ignore').lower()
            for header in self.suspicious_headers:
                if header.lower() in data_str:
                    return True, "proxy_headers_detected"
                    
            if 'squid' in data_str or 'proxy' in data_str:
                return True, "proxy_software_detected"
                
        except:
            pass
            
        return False, "clean"

class AntiDDoS:
    def __init__(self):
        self.connection_attempts = defaultdict(lambda: deque(maxlen=15))
        self.suspected_ips = defaultdict(int)
        self.banned_ips = set()
        self.lock = Lock()
        self.temp_bans = {}
        self.valid_tokens = set()
        self.token_to_ip = {}
        self.ip_sessions = defaultdict(set)
        self.quick_disconnects = defaultdict(lambda: deque(maxlen=5))
        
        self.packet_validator = PacketValidator()
        self.spoofing_protection = SpoofingProtection()
        self.proxy_detection = ProxyDetection()
        self.rate_limiter = RateLimiter()
        self.system_monitor = SystemMonitor()
        
        self.token_secret = secrets.token_hex(32)
        
        self.settings = {
            'max_connections_per_interval': 10,
            'interval_seconds': 20,
            'temp_ban_duration': 300,
            'max_suspicions': 3,
            'max_invalid_packets': 5,
            'quick_disconnect_threshold': 3,
            'quick_disconnect_time': 5,
            'max_sessions_per_ip': 2
        }

    def is_banned(self, ip):
        current_time = time.time()
        
        if ip in self.banned_ips:
            return True
        
        if ip in self.temp_bans:
            if current_time < self.temp_bans[ip]:
                return True
            else:
                with self.lock:
                    del self.temp_bans[ip]
                return False
        return False

    def check_connection(self, ip, port, initial_data):
        if self.is_banned(ip):
            return False
            
        if not self.rate_limiter.is_allowed(ip, 'CONNECTION'):
            security_log("Rate limit exceeded", "WARNING", ip)
            return False
            
        proxy_detected, proxy_reason = self.proxy_detection.detect_proxy(ip, port, initial_data)
        if proxy_detected:
            security_log(f"Proxy detected: {proxy_reason}", "WARNING", ip)
            self._handle_suspicious_connection(ip, f"proxy_{proxy_reason}")
            return False
            
        spoofing_check, spoofing_reason = self.spoofing_protection.analyze_connection_pattern(ip, initial_data)
        if not spoofing_check:
            security_log(f"Spoofing detected: {spoofing_reason}", "WARNING", ip)
            self._handle_suspicious_connection(ip, f"spoofing_{spoofing_reason}")
            return False
            
        current_time = time.time()
        
        with self.lock:
            while (self.connection_attempts[ip] and 
                   current_time - self.connection_attempts[ip][0] > self.settings['interval_seconds']):
                self.connection_attempts[ip].popleft()
            
            self.connection_attempts[ip].append(current_time)
            
            if len(self.connection_attempts[ip]) > self.settings['max_connections_per_interval']:
                self._handle_suspicious_connection(ip, "connection_flood")
                return False
            
            return True

    def validate_packet(self, ip, packet_id, data, packet_size):
        if self.is_banned(ip):
            return False
            
        if not self.rate_limiter.is_allowed(ip, 'PACKET'):
            security_log("Packet rate limit exceeded", "WARNING", ip)
            return False
            
        is_valid, reason = self.packet_validator.validate_packet(ip, packet_id, data, packet_size)
        
        if not is_valid:
            security_log(f"Invalid packet: {reason}", "WARNING", ip)
            self._handle_suspicious_connection(ip, f"invalid_packet_{reason}")
            return False
            
        return True

    def generate_client_token(self, ip, player_low_id):
        if not self.rate_limiter.is_allowed(ip, 'LOGIN'):
            return None
            
        timestamp = int(time.time())
        data = f"{ip}:{player_low_id}:{timestamp}:{self.token_secret}"
        token = hashlib.sha256(data.encode()).hexdigest()
        
        with self.lock:
            self.valid_tokens.add(token)
            self.token_to_ip[token] = ip
            
        return token

    def validate_client_token(self, token, ip):
        with self.lock:
            if token not in self.valid_tokens:
                return False
            
            expected_ip = self.token_to_ip.get(token)
            if expected_ip and expected_ip != ip:
                security_log(f"Token IP mismatch", "CRITICAL", ip)
                return False
            
            return True

    def register_session(self, ip, session_id):
        with self.lock:
            sessions = self.ip_sessions[ip]
            
            if len(sessions) >= self.settings['max_sessions_per_ip']:
                oldest_session = next(iter(sessions))
                sessions.remove(oldest_session)
                security_log("Evicted old session", "WARNING", ip)
            
            sessions.add(session_id)
            return True

    def unregister_session(self, ip, session_id):
        with self.lock:
            if ip in self.ip_sessions:
                self.ip_sessions[ip].discard(session_id)
                if not self.ip_sessions[ip]:
                    del self.ip_sessions[ip]

    def track_disconnect(self, ip, connect_time):
        current_time = time.time()
        session_duration = current_time - connect_time
        
        if session_duration < self.settings['quick_disconnect_time']:
            with self.lock:
                self.quick_disconnects[ip].append(current_time)
                
                while (self.quick_disconnects[ip] and 
                       current_time - self.quick_disconnects[ip][0] > self.settings['quick_disconnect_time']):
                    self.quick_disconnects[ip].popleft()
                
                if len(self.quick_disconnects[ip]) >= self.settings['quick_disconnect_threshold']:
                    security_log("Rapid disconnects detected", "CRITICAL", ip)
                    self._temp_ban_ip(ip, 600)
                    return False
        
        return True

    def _handle_suspicious_connection(self, ip, reason):
        self.suspected_ips[ip] += 1
        suspicion_count = self.suspected_ips[ip]
        
        if suspicion_count >= self.settings['max_suspicions']:
            self.banned_ips.add(ip)
            security_log("Permanent ban applied", "CRITICAL", ip)
        else:
            ban_duration = self.settings['temp_ban_duration'] * suspicion_count
            self._temp_ban_ip(ip, ban_duration)

    def _temp_ban_ip(self, ip, duration):
        with self.lock:
            self.temp_bans[ip] = time.time() + duration

    def cleanup_old_data(self):
        current_time = time.time()
        with self.lock:
            import random
            tokens_to_remove = [token for token in self.valid_tokens if random.random() < 0.01]
            for token in tokens_to_remove:
                self.valid_tokens.remove(token)
                if token in self.token_to_ip:
                    del self.token_to_ip[token]
            
            for ip in list(self.temp_bans.keys()):
                if current_time >= self.temp_bans[ip]:
                    del self.temp_bans[ip]

    def get_security_status(self):
        with self.lock:
            system_status = self.system_monitor.get_system_status()
            return {
                'total_banned': len(self.banned_ips),
                'temp_banned': len(self.temp_bans),
                'suspected_ips': len(self.suspected_ips),
                'active_sessions': sum(len(sessions) for sessions in self.ip_sessions.values()),
                'system_status': system_status
            }

class ClientThread(Thread):
    def __init__(self, client, address):
        super().__init__()
        self.client = client
        self.address = address
        self.device = Device(self.client)
        self.player = Players(self.device)
        self.client.settimeout(30.0)
        self.ip = address[0]
        self.port = address[1]
        self.connection_time = time.time()
        self.session_id = secrets.token_hex(16)
        self.authenticated = False

    def initialize_connection(self, initial_data):
        if not Server.anti_ddos.check_connection(self.ip, self.port, initial_data):
            return False
            
        if not Server.anti_ddos.register_session(self.ip, self.session_id):
            return False
            
        return True

    def run(self):
        try:
            initial_data = self.client.recv(1024, socket.MSG_PEEK)
            if not self.initialize_connection(initial_data):
                self.client.close()
                return

            while True:
                header = self.client.recv(7)
                if not header:
                    break
                    
                packet_id = int.from_bytes(header[:2], 'big')
                length = int.from_bytes(header[2:5], 'big')
                
                if not Server.anti_ddos.validate_packet(self.ip, packet_id, b'', length):
                    break
                
                if length > 1000000:
                    security_log("Oversized packet", "WARNING", self.ip)
                    break
                
                data = self.recvall(length)

                if not Server.anti_ddos.validate_packet(self.ip, packet_id, data, length):
                    break

                if packet_id in packets:
                    message = packets[packet_id](self.client, self.player, data)
                    message.decode()
                    message.process()

                    if packet_id == 10101 and not self.authenticated:
                        self._handle_authentication()

        except (socket.timeout, ConnectionAbortedError, ConnectionResetError, ConnectionError) as e:
            security_log(f"Client disconnect: {type(e).__name__}", "INFO", self.ip)
        except Exception as e:
            security_log(f"Client error: {str(e)}", "ERROR", self.ip)
        finally:
            self._cleanup_connection()

    def _handle_authentication(self):
        client_token = Server.anti_ddos.generate_client_token(self.ip, self.player.low_id)
        if client_token:
            self.authenticated = True
            security_log(f"Player authenticated: {self.player.name}", "INFO", self.ip)
        else:
            security_log("Login rate limit exceeded", "WARNING", self.ip)

    def _cleanup_connection(self):
        Server.anti_ddos.track_disconnect(self.ip, self.connection_time)
        Server.anti_ddos.unregister_session(self.ip, self.session_id)
        
        if self.ip in Server.ConnectedIPs:
            Server.Online -= 1
            Server.ConnectedIPs.remove(self.ip)
            update_config_online(Server.Online)
        
        try:
            self.client.close()
        except:
            pass

    def recvall(self, length):
        data = b''
        while len(data) < length:
            try:
                s = self.client.recv(length - len(data))
                if not s:
                    raise ConnectionError("Connection closed")
                data += s
            except:
                raise ConnectionError("Data receive error")
        return data

class Server:
    Clients = {"ClientCounts": 0, "Clients": {}, "Online": 0}
    ThreadCount = 0
    ConnectedIPs = set()
    anti_ddos = AntiDDoS()

    def __init__(self, ip, port):
        self.server = socket.socket()
        self.port = port
        self.ip = ip
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.settimeout(1.0)

    def start(self):
        print_banner()
        
        Server.Online = 0
        Server.ConnectedIPs.clear()
        update_config_online(0)
        
        if not os.path.exists('./config.json'):
            Config.create_config(self)

        self.server.bind((self.ip, self.port))
        security_log(f'Server started: {self.ip}:{self.port}', "INFO")
        
        self._start_maintenance_task()
        
        while True:
            try:
                self.server.listen()
                client, address = self.server.accept()
                ip = address[0]
                
                if ip not in Server.ConnectedIPs:
                    Server.Online += 1
                    Server.ConnectedIPs.add(ip)
                    update_config_online(Server.Online)
                
                security_log(f'New connection: {ip}', "INFO", ip)
                ClientThread(client, address).start()
                Server.ThreadCount += 1
                
            except socket.timeout:
                continue
            except Exception as e:
                security_log(f"Accept error: {str(e)}", "ERROR")

    def _start_maintenance_task(self):
        def maintenance():
            while True:
                time.sleep(60)
                Server.anti_ddos.cleanup_old_data()
                
                status = Server.anti_ddos.get_security_status()
                sys_status = status['system_status']
                if 'error' not in sys_status:
                    security_log(f"System: CPU {sys_status['cpu']}% RAM {sys_status['memory_used']}% "
                               f"Connections: {status['active_sessions']} Banned: {status['total_banned']}", "INFO")
        
        Thread(target=maintenance, daemon=True).start()

def print_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    print("       NovaTime – NovaBrawl Private Server")
    print("          Version: 18.104 | Brawl Stars")
    print("\n")

def update_config_online(count):
    try:
        with open('config.json', 'r+') as f:
            config = json.load(f)
            config['Online'] = count
            f.seek(0)
            json.dump(config, f, indent=4)
            f.truncate()
    except Exception as e:
        security_log(f"Config update error: {e}", "ERROR")

if __name__ == '__main__':
    try:
        server = Server('127.0.0.1', 9339)
        server.start()
    except KeyboardInterrupt:
        security_log("Server stopped by admin", "INFO")
        update_config_online(0)
    except Exception as e:
        security_log(f"Critical error: {str(e)}", "CRITICAL")
        update_config_online(0)