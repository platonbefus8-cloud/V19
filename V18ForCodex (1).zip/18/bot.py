import telebot
import re
import json
import sqlite3
import subprocess
import os
from datetime import datetime, timedelta
from telebot import types

BOT_TOKEN = '8689710588:AAHuMT6_keR-YDzSIO7vu8gnT7MZ36MpfVU'
ADMIN_IDS = [7514546127, 8303106685]
NL = chr(10)
DB_PATH = 'Database/Player/data.db'
OFFERS_JSON_PATH = 'JSON/offers.json'
CONFIG_PATH = 'config.json'

bot = telebot.TeleBot(BOT_TOKEN)

pending_offers = {}
user_states = {}

BRAWLERS = {
    0: 'Шелли', 1: 'Кольт', 2: 'Булл', 3: 'Брок', 4: 'Рико',
    5: 'Спайк', 6: 'Барли', 7: 'Джесси', 8: 'Нита', 9: 'Динамайк',
    10: 'Эль Примо', 11: 'Мортис', 12: 'Ворон', 13: 'Поко', 14: 'Бо',
    15: 'Пайпер', 16: 'Пэм', 17: 'Тара', 18: 'Дэррил', 19: 'Пенни',
    20: 'Фрэнк', 21: 'Джин', 23: 'Леон', 24: 'Роза', 25: 'Карл'
}

SKINS = {
    2: 'Рок-Звезда Кольт', 5: 'Пляжный Брок', 11: 'Сакура Спайк',
    15: 'Панда Нита', 20: 'Белый Ворон', 25: 'Викинг Булл',
    26: 'Мажор Рико', 27: 'Золотой Барли', 28: 'Эль Рудо Примо',
    29: 'Бандитка Шелли', 30: 'Эль Рей Примо', 44: 'Драконоборец Джесси',
    45: 'Пещерный Фрэнк', 47: 'Летняя Джесси', 49: 'Ворон Фенкис',
    50: 'Рокабильщик Мортис', 52: 'Звёздная Шелли', 56: 'Сантамайк',
    57: 'Майк-повар', 58: 'Брейк-дансер Брок', 59: 'Волшебник Барли',
    60: 'Нита Красный Нос', 61: 'Помощница Пенни', 63: 'Мортис в Цилиндре',
    64: 'Тачдаун Булл', 68: 'Попкорн Рико', 69: 'Гвардеец Кольт',
    70: 'Соевый Дэррил', 71: 'Менестрель Поко', 72: 'Кунг-фу Брок',
    75: 'Ночная Ведьма Мортис', 79: 'Сиба-Ину Нита', 88: 'Зайка Пенни',
    90: 'Барли с плюшками', 91: 'Стритрейсер Брок', 92: 'Кленовый Барли',
    93: 'Безумный Карл', 94: 'Индиго Тара', 95: 'Серебряный Кольт',
    96: 'Золотой Кольт', 97: 'Серебряная Шелли', 98: 'Золотая Шелли',
    99: 'Серебряный Бо', 100: 'Золотой Бо', 101: 'Серебряный Спайк',
    102: 'Золотой Спайк', 103: 'Серебряный Булл', 104: 'Золотой Булл',
    105: 'Серебряный Рико', 106: 'Золотой Рико', 107: 'Серебряный Поко',
    108: 'Золотой Поко', 109: 'Серебряный Леон', 110: 'Золотой Леон',
    111: 'Серебряный Джин', 112: 'Золотой Джин', 113: 'Серебряный Динамайк',
    114: 'Золотой Динамайк', 115: 'Серебряный Карл', 116: 'Золотой Карл',
    117: 'Обезьянка Джин'
}


def is_admin(user_id):
    return user_id in ADMIN_IDS


def get_player(low_id):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT token, info FROM players WHERE json_extract(info, '$.lowID') = ?", (int(low_id),))
        row = cursor.fetchone()
        conn.close()
        if row:
            return {'token': row[0], 'info': json.loads(row[1])}
        return None
    except Exception as e:
        print(f"get_player error: {e}")
        return None


def update_player(low_id, field, value):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT token, info FROM players WHERE json_extract(info, '$.lowID') = ?", (int(low_id),))
        row = cursor.fetchone()
        if not row:
            conn.close()
            return False
        token = row[0]
        info = json.loads(row[1])
        info[field] = value
        cursor.execute("UPDATE players SET info = ? WHERE token = ?", (json.dumps(info, ensure_ascii=False), token))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"update_player error: {e}")
        return False


def main_menu_markup():
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton('💎 Гемы', callback_data='menu_gems'),
        types.InlineKeyboardButton('🪙 Монеты', callback_data='menu_gold'),
        types.InlineKeyboardButton('🎟 Билеты', callback_data='menu_tickets'),
        types.InlineKeyboardButton('✖ Удвоители', callback_data='menu_tokensdoubler'),
        types.InlineKeyboardButton('🔥 Винстрик', callback_data='menu_winstreak'),
        types.InlineKeyboardButton('🎁 Мал. ящики', callback_data='menu_brawlBoxes'),
        types.InlineKeyboardButton('🏆 Бол. ящики', callback_data='menu_bigBoxes'),
        types.InlineKeyboardButton('👑 VIP', callback_data='menu_vip'),
        types.InlineKeyboardButton('🚫 BAN', callback_data='menu_ban'),
        types.InlineKeyboardButton('🛒 Автошоп', callback_data='action_auto_shop'),
        types.InlineKeyboardButton('🔄 Сброс сезона', callback_data='action_sbros'),
        types.InlineKeyboardButton('🆕 Создать акцию', callback_data='offer_start'),
        types.InlineKeyboardButton('📋 Все акции', callback_data='offer_list'),
        types.InlineKeyboardButton('🎁 Промокоды', callback_data='promo_menu'),
        types.InlineKeyboardButton('🎨 Префиксы', callback_data='prefix_menu'),
        types.InlineKeyboardButton('📊 Статистика', callback_data='action_statistics'),
        types.InlineKeyboardButton('👤 Инфо игрока', callback_data='action_player_info'),
    )
    return kb


def resource_action_markup(resource):
    kb = types.InlineKeyboardMarkup(row_width=3)
    kb.add(
        types.InlineKeyboardButton('➕ Добавить', callback_data=f'res_{resource}_add'),
        types.InlineKeyboardButton('➖ Забрать', callback_data=f'res_{resource}_take'),
        types.InlineKeyboardButton('🔧 Установить', callback_data=f'res_{resource}_set'),
        types.InlineKeyboardButton('🔙 Назад', callback_data='back_main'),
    )
    return kb


def vip_ban_markup(kind):
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton('✅ Выдать навсегда', callback_data=f'{kind}_give_perm'),
        types.InlineKeyboardButton('⏳ Выдать временно', callback_data=f'{kind}_give_temp'),
        types.InlineKeyboardButton('❌ Забрать', callback_data=f'{kind}_remove'),
        types.InlineKeyboardButton('🔙 Назад', callback_data='back_main'),
    )
    return kb


def offer_type_markup():
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton('💎 Гемы', callback_data='otype_gems'),
        types.InlineKeyboardButton('🪙 Монеты', callback_data='otype_gold'),
        types.InlineKeyboardButton('⭐ Очки силы', callback_data='otype_powerpoints'),
        types.InlineKeyboardButton('✖ Удвоители', callback_data='otype_tokensdoubler'),
        types.InlineKeyboardButton('📦 Ящики', callback_data='otype_boxes'),
        types.InlineKeyboardButton('🥊 Боец', callback_data='otype_brawler'),
        types.InlineKeyboardButton('🎨 Скин', callback_data='otype_skin'),
        types.InlineKeyboardButton('🎨 Смешать несколько', callback_data='offer_mix'),
        types.InlineKeyboardButton('🔙 Отмена', callback_data='back_main'),
    )
    return kb


def brawler_select_markup(page=0):
    brawler_list = list(BRAWLERS.items())
    per_page = 10
    start = page * per_page
    chunk = brawler_list[start:start + per_page]
    kb = types.InlineKeyboardMarkup(row_width=2)
    for bid, bname in chunk:
        kb.add(types.InlineKeyboardButton(bname, callback_data=f'brawler_{bid}'))
    nav = []
    if page > 0:
        nav.append(types.InlineKeyboardButton('◀', callback_data=f'brawler_page_{page-1}'))
    if start + per_page < len(brawler_list):
        nav.append(types.InlineKeyboardButton('▶', callback_data=f'brawler_page_{page+1}'))
    if nav:
        kb.row(*nav)
    kb.add(types.InlineKeyboardButton('🔙 Отмена', callback_data='back_main'))
    return kb


def skin_select_markup(page=0):
    skin_list = list(SKINS.items())
    per_page = 10
    start = page * per_page
    chunk = skin_list[start:start + per_page]
    kb = types.InlineKeyboardMarkup(row_width=2)
    for sid, sname in chunk:
        kb.add(types.InlineKeyboardButton(sname, callback_data=f'skin_{sid}'))
    nav = []
    if page > 0:
        nav.append(types.InlineKeyboardButton('◀', callback_data=f'skin_page_{page-1}'))
    if start + per_page < len(skin_list):
        nav.append(types.InlineKeyboardButton('▶', callback_data=f'skin_page_{page+1}'))
    if nav:
        kb.row(*nav)
    kb.add(types.InlineKeyboardButton('🔙 Отмена', callback_data='back_main'))
    return kb


def cancel_markup():
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton('🔙 Отмена', callback_data='back_main'))
    return kb


@bot.message_handler(commands=['start', 'menu'])
def cmd_start(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    bot.send_message(
        message.chat.id,
        '<b>🤖 Angel Brawl — Панель управления</b>\n\nВыберите раздел:',
        parse_mode='HTML',
        reply_markup=main_menu_markup()
    )


@bot.callback_query_handler(func=lambda c: c.data == 'back_main')
def back_main(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    pending_offers.pop(uid, None)
    user_states.pop(uid, None)
    bot.edit_message_text(
        '<b>🤖 Angel Brawl — Панель управления</b>\n\nВыберите раздел:',
        call.message.chat.id,
        call.message.message_id,
        parse_mode='HTML',
        reply_markup=main_menu_markup()
    )


@bot.callback_query_handler(func=lambda c: c.data.startswith('menu_'))
def menu_section(call):
    if not is_admin(call.from_user.id):
        return
    section = call.data[5:]
    labels = {
        'gems': '💎 Гемы', 'gold': '🪙 Монеты', 'tickets': '🎟 Билеты',
        'tokensdoubler': '✖ Удвоители жетонов', 'winstreak': '🔥 Винстрик',
        'brawlBoxes': '🎁 Маленькие ящики', 'bigBoxes': '🏆 Большие ящики',
    }
    if section in labels:
        bot.edit_message_text(
            f'<b>{labels[section]}</b>\n\nВыберите действие:',
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=resource_action_markup(section)
        )
    elif section == 'vip':
        bot.edit_message_text(
            '<b>👑 VIP-статус</b>\n\nВыберите действие:',
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=vip_ban_markup('vip')
        )
    elif section == 'ban':
        bot.edit_message_text(
            '<b>🚫 BAN</b>\n\nВыберите действие:',
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=vip_ban_markup('ban')
        )


@bot.callback_query_handler(func=lambda c: c.data.startswith('res_'))
def res_action(call):
    if not is_admin(call.from_user.id):
        return
    parts = call.data.split('_')
    resource = parts[1]
    action = parts[2]
    user_states[call.from_user.id] = {'type': 'resource', 'resource': resource, 'action': action}
    bot.edit_message_text(
        'Введите <b>low_id</b> и <b>количество</b> через пробел:',
        call.message.chat.id, call.message.message_id,
        parse_mode='HTML', reply_markup=cancel_markup()
    )


@bot.callback_query_handler(func=lambda c: '_give_perm' in c.data or '_give_temp' in c.data or '_remove' in c.data)
def vip_ban_action(call):
    if not is_admin(call.from_user.id):
        return
    data = call.data
    if data.startswith('vip'):
        kind = 'vip'
    else:
        kind = 'ban'
    if '_give_perm' in data:
        action = 'give_perm'
        prompt = 'Введите <b>low_id</b>:'
    elif '_give_temp' in data:
        action = 'give_temp'
        prompt = 'Введите <b>low_id</b> и <b>кол-во дней</b> через пробел:'
    else:
        action = 'remove'
        prompt = 'Введите <b>low_id</b>:'
    user_states[call.from_user.id] = {'type': kind, 'action': action}
    bot.edit_message_text(prompt, call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=cancel_markup())


@bot.callback_query_handler(func=lambda c: c.data == 'action_player_info')
def action_player_info(call):
    if not is_admin(call.from_user.id):
        return
    user_states[call.from_user.id] = {'type': 'player_info'}
    bot.edit_message_text(
        'Введите <b>low_id</b> игрока:',
        call.message.chat.id, call.message.message_id,
        parse_mode='HTML', reply_markup=cancel_markup()
    )


@bot.callback_query_handler(func=lambda c: c.data == 'offer_start')
def offer_start(call):
    if not is_admin(call.from_user.id):
        return
    bot.edit_message_text(
        '🆕 <b>Создание акции</b>\n\nВыберите тип содержимого:',
        call.message.chat.id, call.message.message_id,
        parse_mode='HTML', reply_markup=offer_type_markup()
    )


@bot.callback_query_handler(func=lambda c: c.data.startswith('otype_'))
def offer_type_selected(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    otype = call.data[6:]
    pending_offers[uid] = {'otype': otype}

    if otype == 'brawler':
        bot.edit_message_text('🥊 Выберите <b>бойца</b>:', call.message.chat.id, call.message.message_id,
                               parse_mode='HTML', reply_markup=brawler_select_markup(0))
    elif otype == 'skin':
        bot.edit_message_text('🎨 Выберите <b>скин</b>:', call.message.chat.id, call.message.message_id,
                               parse_mode='HTML', reply_markup=skin_select_markup(0))
    else:
        user_states[uid] = {'type': 'offer_title'}
        bot.edit_message_text('📝 Введите <b>название акции</b>:', call.message.chat.id, call.message.message_id,
                               parse_mode='HTML', reply_markup=cancel_markup())


@bot.callback_query_handler(func=lambda c: c.data.startswith('brawler_page_'))
def brawler_page(call):
    if not is_admin(call.from_user.id):
        return
    page = int(call.data.split('_')[-1])
    bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                   reply_markup=brawler_select_markup(page))


@bot.callback_query_handler(func=lambda c: c.data.startswith('skin_page_'))
def skin_page(call):
    if not is_admin(call.from_user.id):
        return
    page = int(call.data.split('_')[-1])
    bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                   reply_markup=skin_select_markup(page))


@bot.callback_query_handler(func=lambda c: c.data.startswith('brawler_') and not c.data.startswith('brawler_page_'))
def brawler_selected(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    bid = int(call.data.split('_')[1])
    if uid not in pending_offers:
        pending_offers[uid] = {}
    pending_offers[uid]['brawler_id'] = bid
    user_states[uid] = {'type': 'offer_title'}
    bot.edit_message_text(
        f'🥊 Боец: <b>{BRAWLERS.get(bid, bid)}</b>\n\n📝 Введите <b>название акции</b>:',
        call.message.chat.id, call.message.message_id,
        parse_mode='HTML', reply_markup=cancel_markup()
    )


@bot.callback_query_handler(func=lambda c: c.data.startswith('skin_') and not c.data.startswith('skin_page_'))
def skin_selected(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    sid = int(call.data.split('_')[1])
    if uid not in pending_offers:
        pending_offers[uid] = {}
    pending_offers[uid]['skin_id'] = sid
    user_states[uid] = {'type': 'offer_title'}
    bot.edit_message_text(
        f'🎨 Скин: <b>{SKINS.get(sid, sid)}</b>\n\n📝 Введите <b>название акции</b>:',
        call.message.chat.id, call.message.message_id,
        parse_mode='HTML', reply_markup=cancel_markup()
    )


@bot.callback_query_handler(func=lambda c: c.data.startswith('brawler_') and not c.data.startswith('brawler_page_'))
def promo_brawler_hook(call):
    uid = call.from_user.id
    if uid in user_states and user_states[uid].get('type') == 'promo_brawler_pick':
        if not is_admin(uid):
            return
        bid = int(call.data.split('_')[1])
        cart = pending_offers.setdefault(uid, {}).setdefault('promo_items', [])
        if any(i['type'] == 'brawler' for i in cart):
            bot.answer_callback_query(call.id, 'Боец уже добавлен', show_alert=True)
            return
        cart.append({'type': 'brawler', 'amount': 1, 'brawler_id': bid})
        user_states.pop(uid, None)
        bot.answer_callback_query(call.id, 'Добавлен: ' + BRAWLERS.get(bid, str(bid)))
        _show_promo_items(call.message.chat.id, call.message.message_id, uid, edit=True)
        raise Exception('handled')
    return


@bot.callback_query_handler(func=lambda c: c.data.startswith('skin_') and not c.data.startswith('skin_page_'))
def promo_skin_hook(call):
    uid = call.from_user.id
    if uid in user_states and user_states[uid].get('type') == 'promo_skin_pick':
        if not is_admin(uid):
            return
        sid = int(call.data.split('_')[1])
        cart = pending_offers.setdefault(uid, {}).setdefault('promo_items', [])
        if any(i['type'] == 'skin' for i in cart):
            bot.answer_callback_query(call.id, 'Скин уже добавлен', show_alert=True)
            return
        cart.append({'type': 'skin', 'amount': 1, 'skin_id': sid})
        user_states.pop(uid, None)
        bot.answer_callback_query(call.id, 'Добавлен: ' + SKINS.get(sid, str(sid)))
        _show_promo_items(call.message.chat.id, call.message.message_id, uid, edit=True)
        raise Exception('handled')
    return


PREFIXES_JSON_PATH = 'JSON/titles.json'


def load_prefixes():
    try:
        with open(PREFIXES_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get('titles', [])
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def save_prefixes(titles):
    with open(PREFIXES_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump({'titles': titles}, f, ensure_ascii=False, indent=4)


def make_gradient(text, palette):
    out = []
    for i, ch in enumerate(text):
        color = palette[i % len(palette)]
        out.append('<c' + color + '>' + ch)
    return ''.join(out) + '</c>'


def prefix_select_markup(page=0, cb_prefix='prefix_pick_'):
    titles = load_prefixes()
    per_page = 10
    start = page * per_page
    kb = types.InlineKeyboardMarkup(row_width=1)
    for idx in range(start, min(start + per_page, len(titles))):
        t = titles[idx]
        kb.add(types.InlineKeyboardButton(t.get('name', '?') + ' — #' + str(idx), callback_data=cb_prefix + str(idx)))
    nav = []
    if page > 0:
        nav.append(types.InlineKeyboardButton('◀', callback_data=cb_prefix + 'page_' + str(page-1)))
    if start + per_page < len(titles):
        nav.append(types.InlineKeyboardButton('▶', callback_data=cb_prefix + 'page_' + str(page+1)))
    if nav:
        kb.row(*nav)
    kb.add(types.InlineKeyboardButton('🔙 Отмена', callback_data='prefix_menu'))
    return kb


def prefix_menu_markup():
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton('➕ Добавить новый', callback_data='prefix_add'),
        types.InlineKeyboardButton('✅ Выдать', callback_data='prefix_give'),
        types.InlineKeyboardButton('❌ Забрать', callback_data='prefix_take'),
        types.InlineKeyboardButton('📋 Список', callback_data='prefix_list'),
    )
    kb.add(types.InlineKeyboardButton('🔙 Назад', callback_data='back_main'))
    return kb


def gradient_select_markup(page=0):
    titles = load_prefixes()
    per_page = 10
    start = page * per_page
    kb = types.InlineKeyboardMarkup(row_width=1)
    for idx in range(start, min(start + per_page, len(titles))):
        t = titles[idx]
        kb.add(types.InlineKeyboardButton(t.get('name', '?') + ' — шаблон', callback_data='prefix_grad_' + str(idx)))
    nav = []
    if page > 0:
        nav.append(types.InlineKeyboardButton('◀', callback_data='prefix_gradpage_' + str(page-1)))
    if start + per_page < len(titles):
        nav.append(types.InlineKeyboardButton('▶', callback_data='prefix_gradpage_' + str(page+1)))
    if nav:
        kb.row(*nav)
    kb.add(types.InlineKeyboardButton('🔙 Отмена', callback_data='prefix_menu'))
    return kb


@bot.callback_query_handler(func=lambda c: c.data == 'prefix_menu')
def prefix_menu(call):
    if not is_admin(call.from_user.id):
        return
    bot.edit_message_text('🎨 <b>Префиксы</b>' + NL + NL + 'Выберите действие:',
                          call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=prefix_menu_markup())


@bot.callback_query_handler(func=lambda c: c.data.startswith('prefix_pick_'))
def prefix_pick_for_promo(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    st = user_states.get(uid)
    if not st or st.get('type') != 'promo_prefix_pick':
        return
    tail = call.data[len('prefix_pick_'):]
    if tail.startswith('page_'):
        page = int(tail[5:])
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                       reply_markup=prefix_select_markup(page, 'prefix_pick_'))
        return
    idx = int(tail)
    titles = load_prefixes()
    if idx < 0 or idx >= len(titles):
        bot.answer_callback_query(call.id, 'Не найден')
        return
    cart = pending_offers.setdefault(uid, {}).setdefault('promo_items', [])
    if any(i['type'] == 'prefix' for i in cart):
        bot.answer_callback_query(call.id, 'Префикс уже добавлен', show_alert=True)
        return
    cart.append({'type': 'prefix', 'amount': 1, 'title_index': idx})
    user_states.pop(uid, None)
    bot.answer_callback_query(call.id, 'Добавлен префикс #' + str(idx))
    _show_promo_items(call.message.chat.id, call.message.message_id, uid, edit=True)


@bot.callback_query_handler(func=lambda c: c.data == 'prefix_add')
def prefix_add(call):
    if not is_admin(call.from_user.id):
        return
    user_states[call.from_user.id] = {'type': 'prefix_new_text'}
    bot.edit_message_text('📝 Введите <b>текст префикса</b> (латиница, до 9 символов):',
                          call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=cancel_markup())


@bot.callback_query_handler(func=lambda c: c.data.startswith('prefix_gradpage_'))
def prefix_grad_page(call):
    if not is_admin(call.from_user.id):
        return
    page = int(call.data[len('prefix_gradpage_'):])
    bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                   reply_markup=gradient_select_markup(page))


@bot.callback_query_handler(func=lambda c: c.data.startswith('prefix_grad_'))
def prefix_grad_pick(call):
    try:
        if not is_admin(call.from_user.id):
            return
        uid = call.from_user.id
        st = user_states.get(uid)
        if not st or st.get('type') != 'prefix_new_grad':
            bot.answer_callback_query(call.id, 'Стейт потерян, начните заново')
            return
        idx = int(call.data[len('prefix_grad_'):])
        titles = load_prefixes()
        if idx < 0 or idx >= len(titles):
            bot.answer_callback_query(call.id, 'Не найден')
            return
        palette = []
        for m in re.findall(r'<c([0-9A-Fa-f]{6})>', titles[idx].get('gradient', '')):
            palette.append(m.upper())
        if not palette:
            palette = ['FFFFFF']
        text = st.get('text', 'TAG')
        grad = make_gradient(text, palette)
        titles.append({'name': text, 'gradient': grad})
        save_prefixes(titles)
        user_states.pop(uid, None)
        bot.answer_callback_query(call.id, 'Готово!')
        bot.edit_message_text('✅ Префикс <b>' + text + '</b> добавлен!' + NL + NL + 'Превью: ' + grad,
                              call.message.chat.id, call.message.message_id,
                              parse_mode='HTML',
                              reply_markup=types.InlineKeyboardMarkup().add(
                                  types.InlineKeyboardButton('🔙 К префиксам', callback_data='prefix_menu')))
    except Exception as e:
        print('PREFIX GRAD FAIL:', repr(e))
        try:
            bot.answer_callback_query(call.id, 'Ошибка: ' + str(e), show_alert=True)
        except Exception:
            pass


@bot.callback_query_handler(func=lambda c: c.data == 'prefix_give')
def prefix_give(call):
    if not is_admin(call.from_user.id):
        return
    user_states[call.from_user.id] = {'type': 'prefix_give_lowid'}
    bot.edit_message_text('🆔 Введите <b>low_id</b> игрока:',
                          call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=cancel_markup())


@bot.callback_query_handler(func=lambda c: c.data == 'prefix_take')
def prefix_take(call):
    if not is_admin(call.from_user.id):
        return
    user_states[call.from_user.id] = {'type': 'prefix_take_lowid'}
    bot.edit_message_text('🆔 Введите <b>low_id</b> игрока (забрать префикс):',
                          call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=cancel_markup())


@bot.callback_query_handler(func=lambda c: c.data.startswith('prefix_apply_'))
def prefix_apply(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    st = user_states.get(uid)
    if not st or st.get('type') != 'prefix_give_pick':
        return
    tail = call.data[len('prefix_apply_'):]
    if tail.startswith('page_'):
        page = int(tail[5:])
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                       reply_markup=prefix_select_markup(page, 'prefix_apply_'))
        return
    idx = int(tail)
    titles = load_prefixes()
    if idx < 0 or idx >= len(titles):
        bot.answer_callback_query(call.id, 'Не найден')
        return
    grad = titles[idx].get('gradient', '')
    low_id = st.get('low_id')
    user_states.pop(uid, None)
    if update_player(low_id, 'title', grad):
        bot.edit_message_text('✅ Префикс <b>' + titles[idx].get('name', '?') + '</b> выдан игроку ' + str(low_id),
                              call.message.chat.id, call.message.message_id,
                              parse_mode='HTML',
                              reply_markup=types.InlineKeyboardMarkup().add(
                                  types.InlineKeyboardButton('🔙 К префиксам', callback_data='prefix_menu')))
    else:
        bot.edit_message_text('❌ Игрок не найден.',
                              call.message.chat.id, call.message.message_id,
                              reply_markup=types.InlineKeyboardMarkup().add(
                                  types.InlineKeyboardButton('🔙 К префиксам', callback_data='prefix_menu')))


@bot.callback_query_handler(func=lambda c: c.data == 'prefix_list')
def prefix_list(call):
    if not is_admin(call.from_user.id):
        return
    titles = load_prefixes()
    if not titles:
        bot.edit_message_text('📋 <b>Список префиксов пуст.</b>',
                              call.message.chat.id, call.message.message_id,
                              parse_mode='HTML',
                              reply_markup=types.InlineKeyboardMarkup().add(
                                  types.InlineKeyboardButton('🔙 К префиксам', callback_data='prefix_menu')))
        return
    lines = ['📋 <b>Все префиксы:</b>', '']
    kb = types.InlineKeyboardMarkup(row_width=3)
    del_btns = []
    for i, t in enumerate(titles):
        lines.append('#' + str(i) + ' — <b>' + str(t.get('name', '?')) + '</b>')
        del_btns.append(types.InlineKeyboardButton('🗑 #' + str(i), callback_data='prefix_del_' + str(i)))
    if del_btns:
        kb.add(*del_btns)
    kb.add(types.InlineKeyboardButton('🔙 К префиксам', callback_data='prefix_menu'))
    bot.edit_message_text(NL.join(lines), call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data.startswith('prefix_del_'))
def prefix_del(call):
    if not is_admin(call.from_user.id):
        return
    idx = int(call.data[len('prefix_del_'):])
    titles = load_prefixes()
    if 0 <= idx < len(titles):
        removed = titles.pop(idx)
        save_prefixes(titles)
        bot.answer_callback_query(call.id, '✅ Удалён ' + str(removed.get('name', '?')))
        prefix_list(call)
    else:
        bot.answer_callback_query(call.id, '❌ Не найден')


MIX_ITEMS = {
    'gems':          {'id': 16, 'name': '💎 Гемы'},
    'gold':          {'id': 1,  'name': '🪙 Монеты'},
    'tickets':       {'id': 7,  'name': '🎟 Билеты'},
    'tokensdoubler': {'id': 9,  'name': '✖ Удвоители'},
    'brawlBoxes':    {'id': 6,  'name': '📦 Мал. ящики'},
    'bigBoxes':      {'id': 14, 'name': '🏆 Бол. ящики'},
    'megabox':       {'id': 10, 'name': '🎁 Мегаящики'},
    'powerpoints':   {'id': 12, 'name': '⭐ Очки силы'},
}


def mix_select_markup(uid):
    kb = types.InlineKeyboardMarkup(row_width=2)
    cart = pending_offers.get(uid, {}).get('mix_items', [])
    used_types = [it['type'] for it in cart]
    for key, meta in MIX_ITEMS.items():
        if key in used_types:
            continue
        kb.add(types.InlineKeyboardButton(meta['name'], callback_data='mix_add_' + key))
    if cart:
        kb.add(types.InlineKeyboardButton('✅ Готово', callback_data='mix_done'))
    kb.add(types.InlineKeyboardButton('🔙 Отмена', callback_data='back_main'))
    return kb


def _show_mix_menu(chat_id, message_id, uid, edit=True):
    cart = pending_offers.get(uid, {}).get('mix_items', [])
    lines = ['🎨 <b>Смешанная акция</b>', '']
    if cart:
        lines.append('📋 <b>В акции:</b>')
        for it in cart:
            meta = MIX_ITEMS.get(it['type'], {})
            lines.append('  • ' + meta.get('name', it['type']) + ' × <b>' + str(it['amount']) + '</b>')
    else:
        lines.append('📋 <i>Пока ничего не выбрано (макс. 3 предмета)</i>')
    lines.append('')
    if len(cart) >= 3:
        lines.append('Достигнут лимит 3 предмета. Нажмите «✅ Готово».')
    else:
        lines.append('Выберите предмет:')
    text = NL.join(lines)
    kb = mix_select_markup(uid)
    try:
        if edit:
            bot.edit_message_text(text, chat_id, message_id, parse_mode='HTML', reply_markup=kb)
        else:
            bot.send_message(chat_id, text, parse_mode='HTML', reply_markup=kb)
    except Exception as e:
        print('MIX MENU FAIL:', repr(e))
        try:
            bot.send_message(chat_id, text, parse_mode='HTML', reply_markup=kb)
        except Exception as e2:
            print('MIX SEND FAIL:', repr(e2))


@bot.callback_query_handler(func=lambda c: c.data == 'offer_mix')
def offer_mix(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    pending_offers[uid] = {'mix_items': []}
    _show_mix_menu(call.message.chat.id, call.message.message_id, uid, edit=True)


@bot.callback_query_handler(func=lambda c: c.data.startswith('mix_add_'))
def mix_add(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    key = call.data[8:]
    if key not in MIX_ITEMS:
        bot.answer_callback_query(call.id, 'Неизвестный предмет')
        return
    cart = pending_offers.setdefault(uid, {}).setdefault('mix_items', [])
    if len(cart) >= 3:
        bot.answer_callback_query(call.id, 'Максимум 3 предмета', show_alert=True)
        return
    if any(i['type'] == key for i in cart):
        bot.answer_callback_query(call.id, 'Уже добавлено', show_alert=True)
        return
    user_states[uid] = {'type': 'mix_item_amount', 'item_type': key}
    meta = MIX_ITEMS[key]
    bot.edit_message_text(meta['name'] + NL + NL + 'Введите <b>количество</b>:',
                          call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=cancel_markup())


@bot.callback_query_handler(func=lambda c: c.data == 'mix_done')
def mix_done(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    cart = pending_offers.get(uid, {}).get('mix_items', [])
    if not cart:
        bot.answer_callback_query(call.id, 'Добавьте хотя бы один предмет', show_alert=True)
        return
    user_states[uid] = {'type': 'mix_title'}
    bot.edit_message_text('📝 Введите <b>название акции</b>:',
                          call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=cancel_markup())


PROMO_JSON_PATH = 'JSON/promocode.json'

# ID для промокодов (серверная логика Alliance_Chat_Message.py):
# 0=gems, 1=gold, 2=tickets, 3=tokensdoubler, 4=brawlBoxes(×100), 5=bigBoxes(×10),
# 6=brawler, 7=skin, 8=title(рандом), 9=vip(days)
PROMO_ITEMS = {
    'gems':          {'id': 0, 'name': '💎 Гемы'},
    'gold':          {'id': 1, 'name': '🪙 Монеты'},
    'tickets':       {'id': 2, 'name': '🎟 Билеты'},
    'tokensdoubler': {'id': 3, 'name': '✖ Удвоители'},
    'brawlBoxes':    {'id': 4, 'name': '📦 Мал. ящики'},
    'bigBoxes':      {'id': 5, 'name': '🏆 Бол. ящики'},
    'brawler':       {'id': 6, 'name': '🥊 Боец'},
    'skin':          {'id': 7, 'name': '🎨 Скин'},
    'prefix':        {'id': 8, 'name': '🏷 Префикс'},
    'vip':           {'id': 9, 'name': '👑 VIP (дни)'},
}

PROMO_BRAWLERS = {}


def promo_menu_markup():
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton('🆕 Создать промокод', callback_data='promo_start'),
        types.InlineKeyboardButton('📋 Все промокоды', callback_data='promo_list'),
    )
    kb.add(types.InlineKeyboardButton('🔙 Назад', callback_data='back_main'))
    return kb


def promo_items_markup(uid):
    kb = types.InlineKeyboardMarkup(row_width=2)
    cart = pending_offers.get(uid, {}).get('promo_items', [])
    used = [it['type'] for it in cart]
    for key, meta in PROMO_ITEMS.items():
        if key in used:
            continue
        kb.add(types.InlineKeyboardButton(meta['name'], callback_data='promo_add_' + key))
    if cart:
        kb.add(types.InlineKeyboardButton('✅ Готово', callback_data='promo_done'))
    kb.add(types.InlineKeyboardButton('🔙 Отмена', callback_data='promo_menu'))
    return kb


def _show_promo_items(chat_id, message_id, uid, edit=True):
    cart = pending_offers.get(uid, {}).get('promo_items', [])
    lines = ['🆕 <b>Создание промокода</b>', '']
    if cart:
        lines.append('📋 <b>В промокоде:</b>')
        for it in cart:
            meta = PROMO_ITEMS.get(it['type'], {})
            lines.append('  • ' + meta.get('name', it['type']) + ' × <b>' + str(it['amount']) + '</b>')
    else:
        lines.append('📋 <i>Пока ничего не выбрано (макс. 10 предметов)</i>')
    lines.append('')
    lines.append('Выберите предмет:')
    text = NL.join(lines)
    kb = promo_items_markup(uid)
    try:
        if edit:
            bot.edit_message_text(text, chat_id, message_id, parse_mode='HTML', reply_markup=kb)
        else:
            bot.send_message(chat_id, text, parse_mode='HTML', reply_markup=kb)
    except Exception as e:
        print('PROMO MENU FAIL:', repr(e))
        try:
            bot.send_message(chat_id, text, parse_mode='HTML', reply_markup=kb)
        except Exception as e2:
            print('PROMO SEND FAIL:', repr(e2))


@bot.callback_query_handler(func=lambda c: c.data == 'promo_menu')
def promo_menu(call):
    if not is_admin(call.from_user.id):
        return
    bot.edit_message_text(
        '🎁 <b>Промокоды</b>' + NL + NL + 'Выберите действие:',
        call.message.chat.id, call.message.message_id,
        parse_mode='HTML', reply_markup=promo_menu_markup()
    )


@bot.callback_query_handler(func=lambda c: c.data == 'promo_start')
def promo_start(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    pending_offers[uid] = {'promo_items': []}
    _show_promo_items(call.message.chat.id, call.message.message_id, uid, edit=True)


@bot.callback_query_handler(func=lambda c: c.data.startswith('promo_add_'))
def promo_add(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    key = call.data[10:]
    if key not in PROMO_ITEMS:
        bot.answer_callback_query(call.id, 'Неизвестный предмет')
        return
    cart = pending_offers.setdefault(uid, {}).setdefault('promo_items', [])
    if len(cart) >= 10:
        bot.answer_callback_query(call.id, 'Максимум 10 предметов', show_alert=True)
        return
    if any(i['type'] == key for i in cart):
        bot.answer_callback_query(call.id, 'Уже добавлено', show_alert=True)
        return
    if key == 'brawler':
        user_states[uid] = {'type': 'promo_brawler_pick'}
        bot.edit_message_text('🥊 Выберите <b>бойца</b>:',
                              call.message.chat.id, call.message.message_id,
                              parse_mode='HTML', reply_markup=brawler_select_markup(0))
        return
    if key == 'skin':
        user_states[uid] = {'type': 'promo_skin_pick'}
        bot.edit_message_text('🎨 Выберите <b>скин</b>:',
                              call.message.chat.id, call.message.message_id,
                              parse_mode='HTML', reply_markup=skin_select_markup(0))
        return
    if key == 'prefix':
        user_states[uid] = {'type': 'promo_prefix_pick'}
        bot.edit_message_text('🏷 Выберите <b>префикс</b>:',
                              call.message.chat.id, call.message.message_id,
                              parse_mode='HTML', reply_markup=prefix_select_markup(0, 'prefix_pick_'))
        return
    user_states[uid] = {'type': 'promo_item_amount', 'item_type': key}
    meta = PROMO_ITEMS[key]
    bot.edit_message_text(meta['name'] + NL + NL + 'Введите <b>количество</b>:',
                          call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=cancel_markup())


@bot.callback_query_handler(func=lambda c: c.data == 'promo_done')
def promo_done(call):
    if not is_admin(call.from_user.id):
        return
    uid = call.from_user.id
    cart = pending_offers.get(uid, {}).get('promo_items', [])
    if not cart:
        bot.answer_callback_query(call.id, 'Добавьте хотя бы один предмет', show_alert=True)
        return
    user_states[uid] = {'type': 'promo_name'}
    bot.edit_message_text('📝 Введите <b>название промокода</b> (латиница, без пробелов):',
                          call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=cancel_markup())


@bot.callback_query_handler(func=lambda c: c.data == 'promo_list')
def promo_list(call):
    if not is_admin(call.from_user.id):
        return
    try:
        with open(PROMO_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}

    if not data:
        bot.edit_message_text('📋 <b>Список промокодов пуст.</b>',
                              call.message.chat.id, call.message.message_id,
                              parse_mode='HTML',
                              reply_markup=types.InlineKeyboardMarkup().add(
                                  types.InlineKeyboardButton('🔙 Назад', callback_data='promo_menu')))
        return

    lines = ['🎁 <b>Промокоды:</b>', '']
    for k, v in data.items():
        code = v.get('Promo', '?')
        used = len(v.get('WhoBuyed', []))
        mx = v.get('MaxUses', 0)
        ids = v.get('ID', [])
        muls = v.get('Multiplier', [])
        items_str = []
        for i, iid in enumerate(ids):
            name = '?'
            for key, meta in PROMO_ITEMS.items():
                if meta['id'] == iid:
                    name = meta['name']
                    break
            m = muls[i] if i < len(muls) else 0
            if iid in (6, 7):
                items_str.append(name)
            elif iid == 9:
                items_str.append(name + ' ' + str(m) + 'д')
            else:
                items_str.append(name + '×' + str(m))
        lines.append('<b>#' + str(k) + '</b> — <code>' + str(code) + '</code>')
        lines.append('   Использован: ' + str(used) + '/' + str(mx))
        if items_str:
            lines.append('   ' + ' '.join(items_str))
        lines.append('')

    kb = types.InlineKeyboardMarkup(row_width=4)
    del_btns = [types.InlineKeyboardButton('🗑 #' + str(k), callback_data='promo_del_' + str(k)) for k in data.keys()]
    if del_btns:
        kb.add(*del_btns)
    kb.add(types.InlineKeyboardButton('🔙 Назад', callback_data='promo_menu'))

    bot.edit_message_text(NL.join(lines), call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data.startswith('promo_del_'))
def promo_delete(call):
    if not is_admin(call.from_user.id):
        return
    key = call.data[10:]
    try:
        with open(PROMO_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if key in data:
            del data[key]
            with open(PROMO_JSON_PATH, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            bot.answer_callback_query(call.id, '✅ Промокод #' + key + ' удалён')
            promo_list(call)
        else:
            bot.answer_callback_query(call.id, '❌ Промокод не найден')
    except Exception as e:
        bot.answer_callback_query(call.id, '❌ Ошибка: ' + str(e))


@bot.callback_query_handler(func=lambda c: c.data == 'offer_list')
def offer_list(call):
    if not is_admin(call.from_user.id):
        return
    try:
        with open(OFFERS_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}

    if not data:
        bot.edit_message_text('📋 <b>Список акций пуст.</b>', call.message.chat.id, call.message.message_id,
                               parse_mode='HTML',
                               reply_markup=types.InlineKeyboardMarkup().add(
                                   types.InlineKeyboardButton('🔙 Назад', callback_data='back_main')))
        return

    lines = ['📋 <b>Текущие акции:</b>\n']
    for k, v in data.items():
        title = v.get('OfferTitle', '?')
        cost = v.get('Cost', 0)
        until = v.get('Until', '')
        lines.append(f'<b>#{k}</b> — {title} | 💎{cost}' + (f' | до {until}' if until else ''))

    kb = types.InlineKeyboardMarkup(row_width=4)
    del_btns = [types.InlineKeyboardButton(f'🗑 #{k}', callback_data=f'offer_del_{k}') for k in data.keys()]
    if del_btns:
        kb.add(*del_btns)
    kb.add(types.InlineKeyboardButton('🔙 Назад', callback_data='back_main'))

    bot.edit_message_text('\n'.join(lines), call.message.chat.id, call.message.message_id,
                          parse_mode='HTML', reply_markup=kb)


@bot.callback_query_handler(func=lambda c: c.data.startswith('offer_del_'))
def offer_delete(call):
    if not is_admin(call.from_user.id):
        return
    key = call.data[10:]
    try:
        with open(OFFERS_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if key in data:
            del data[key]
            with open(OFFERS_JSON_PATH, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            bot.answer_callback_query(call.id, f'✅ Акция #{key} удалена')
            offer_list(call)
        else:
            bot.answer_callback_query(call.id, '❌ Акция не найдена')
    except Exception as e:
        bot.answer_callback_query(call.id, f'❌ Ошибка: {e}')


@bot.callback_query_handler(func=lambda c: c.data == 'action_auto_shop')
def action_auto_shop(call):
    if not is_admin(call.from_user.id):
        return
    bot.edit_message_text('🔄 <b>Обновляю магазин...</b>', call.message.chat.id, call.message.message_id,
                          parse_mode='HTML')
    try:
        process = subprocess.Popen(['python3', 'autoshop.py'],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate(timeout=30)
        if process.returncode == 0:
            lines = [l.strip() for l in stdout.split('\n') if l.strip()]
            response = '✅ <b>Магазин успешно обновлён!</b>\n\n' + '\n'.join(lines[:15])
        else:
            response = f'❌ <b>Ошибка:</b>\n<code>{stderr[:500]}</code>'
    except subprocess.TimeoutExpired:
        response = '❌ Превышено время ожидания.'
    except Exception as e:
        response = f'❌ <b>Ошибка:</b> {e}'
    bot.edit_message_text(response, call.message.chat.id, call.message.message_id, parse_mode='HTML',
                          reply_markup=types.InlineKeyboardMarkup().add(
                              types.InlineKeyboardButton('🔙 Назад', callback_data='back_main')))


@bot.callback_query_handler(func=lambda c: c.data == 'action_sbros')
def action_sbros(call):
    if not is_admin(call.from_user.id):
        return
    bot.edit_message_text('🔄 <b>Сбрасываю сезон...</b>', call.message.chat.id, call.message.message_id,
                          parse_mode='HTML')
    try:
        process = subprocess.Popen(['python3', 'sbros.py'],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate(timeout=60)
        if process.returncode == 0:
            lines = [l.strip() for l in stdout.split('\n') if l.strip()]
            response = '✅ <b>Сезон сброшен!</b>\n\n' + '\n'.join(lines[:20])
        else:
            response = f'❌ <b>Ошибка:</b>\n<code>{stderr[:500]}</code>'
    except subprocess.TimeoutExpired:
        response = '❌ Превышено время ожидания.'
    except Exception as e:
        response = f'❌ <b>Ошибка:</b> {e}'
    bot.edit_message_text(response, call.message.chat.id, call.message.message_id, parse_mode='HTML',
                          reply_markup=types.InlineKeyboardMarkup().add(
                              types.InlineKeyboardButton('🔙 Назад', callback_data='back_main')))


@bot.callback_query_handler(func=lambda c: c.data == 'action_statistics')
def action_statistics(call):
    if not is_admin(call.from_user.id):
        return
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            config = json.load(f)
        online = config.get('Online', 0)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT info FROM players')
        rows = cursor.fetchall()
        conn.close()
        total = len(rows)
        vip_count = ban_count = total_trophies = total_gems = total_gold = 0
        for row in rows:
            info = json.loads(row[0])
            if info.get('vip', 0) > 0:
                vip_count += 1
            if info.get('ban', 0) > 0:
                ban_count += 1
            total_trophies += info.get('trophies', 0)
            total_gems += info.get('gems', 0)
            total_gold += info.get('gold', 0)
        text = (
            f'<b>📊 Статистика Angel Brawl:</b>\n\n'
            f'👥 Аккаунтов: <b>{total}</b>\n'
            f'👑 VIP: <b>{vip_count}</b>\n'
            f'🚫 BAN: <b>{ban_count}</b>\n'
            f'🟢 Онлайн: <b>{online}</b>\n\n'
            f'🏆 Трофеев: <b>{total_trophies}</b>\n'
            f'💎 Гемов: <b>{total_gems}</b>\n'
            f'🪙 Монет: <b>{total_gold}</b>'
        )
    except Exception as e:
        text = f'❌ Ошибка: {e}'
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode='HTML',
                          reply_markup=types.InlineKeyboardMarkup().add(
                              types.InlineKeyboardButton('🔙 Назад', callback_data='back_main')))


@bot.message_handler(func=lambda m: m.from_user.id in user_states and not m.text.startswith('/'))
def handle_state_input(message):
    if not is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    state = user_states.get(uid)
    if not state:
        return

    text = message.text.strip()
    parts = text.split()
    stype = state['type']

    if stype == 'resource':
        resource = state['resource']
        action = state['action']
        user_states.pop(uid, None)
        if len(parts) != 2:
            bot.reply_to(message, '❌ Введите: <b>low_id количество</b>', parse_mode='HTML',
                         reply_markup=main_menu_markup())
            return
        low_id, amount_str = parts
        try:
            amount = int(amount_str)
        except ValueError:
            bot.reply_to(message, '❌ Количество должно быть числом.', reply_markup=main_menu_markup())
            return
        player = get_player(low_id)
        if not player:
            bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.', reply_markup=main_menu_markup())
            return
        info = player['info']
        box_mult = 100 if resource == 'brawlBoxes' else (10 if resource == 'bigBoxes' else 1)
        cur = info.get(resource, 0)
        if action == 'add':
            new_val = cur + amount * box_mult
        elif action == 'take':
            new_val = max(0, cur - amount * box_mult)
        else:
            new_val = max(0, amount * box_mult)
        if update_player(low_id, resource, new_val):
            emoji_map = {'gems': '💎', 'gold': '🪙', 'tickets': '🎟', 'tokensdoubler': '✖',
                         'winstreak': '🔥', 'brawlBoxes': '🎁', 'bigBoxes': '🏆'}
            e = emoji_map.get(resource, '🔢')
            bot.reply_to(message,
                         f'{e} <b>Готово!</b>\nИгрок: <b>{info["name"]}</b> (ID: {low_id})\nНовое значение: <b>{new_val}</b>',
                         parse_mode='HTML', reply_markup=main_menu_markup())
        else:
            bot.reply_to(message, '🔴 Ошибка при обновлении данных.', reply_markup=main_menu_markup())

    elif stype in ('vip', 'ban'):
        action = state['action']
        user_states.pop(uid, None)
        kind = stype
        if action == 'give_temp':
            if len(parts) != 2:
                bot.reply_to(message, '❌ Введите: <b>low_id дней</b>', parse_mode='HTML',
                             reply_markup=main_menu_markup())
                return
            low_id, days_str = parts
            try:
                days = int(days_str)
            except ValueError:
                bot.reply_to(message, '❌ Дней должно быть числом.', reply_markup=main_menu_markup())
                return
            player = get_player(low_id)
            if not player:
                bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.', reply_markup=main_menu_markup())
                return
            expire = (datetime.now() + timedelta(days=days)).strftime('%d.%m.%Y')
            update_player(low_id, kind, 1)
            update_player(low_id, f'{kind}time', expire)
            icon = '👑' if kind == 'vip' else '🚫'
            bot.reply_to(message,
                         f'{icon} <b>{kind.upper()}</b> выдан игроку <b>{player["info"]["name"]}</b> до <b>{expire}</b>',
                         parse_mode='HTML', reply_markup=main_menu_markup())
        elif action == 'give_perm':
            if not parts:
                bot.reply_to(message, '❌ Введите low_id.', reply_markup=main_menu_markup())
                return
            low_id = parts[0]
            player = get_player(low_id)
            if not player:
                bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.', reply_markup=main_menu_markup())
                return
            update_player(low_id, kind, 2)
            update_player(low_id, f'{kind}time', '0')
            icon = '👑' if kind == 'vip' else '🚫'
            bot.reply_to(message,
                         f'{icon} <b>{kind.upper()} навсегда</b> выдан игроку <b>{player["info"]["name"]}</b>',
                         parse_mode='HTML', reply_markup=main_menu_markup())
        else:
            if not parts:
                bot.reply_to(message, '❌ Введите low_id.', reply_markup=main_menu_markup())
                return
            low_id = parts[0]
            player = get_player(low_id)
            if not player:
                bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.', reply_markup=main_menu_markup())
                return
            update_player(low_id, kind, 0)
            update_player(low_id, f'{kind}time', '0')
            bot.reply_to(message,
                         f'✅ <b>{kind.upper()}</b> снят с игрока <b>{player["info"]["name"]}</b>',
                         parse_mode='HTML', reply_markup=main_menu_markup())

    elif stype == 'player_info':
        user_states.pop(uid, None)
        low_id = parts[0] if parts else ''
        _do_player_info(message, low_id)

    elif stype == 'mix_item_amount':
        if not parts:
            bot.reply_to(message, 'Введите число.')
            return
        try:
            amount = int(parts[0])
            if amount <= 0:
                raise ValueError
        except ValueError:
            bot.reply_to(message, 'Введите положительное число.')
            return
        item_type = state.get('item_type')
        cart = pending_offers.setdefault(uid, {}).setdefault('mix_items', [])
        cart.append({'type': item_type, 'amount': amount})
        user_states.pop(uid, None)
        meta = MIX_ITEMS.get(item_type, {})
        bot.reply_to(message, 'Добавлено: ' + meta.get('name', item_type) + ' × <b>' + str(amount) + '</b>', parse_mode='HTML')
        _show_mix_menu(message.chat.id, None, uid, edit=False)

    elif stype == 'mix_title':
        pending_offers.setdefault(uid, {})['mix_title'] = text
        user_states[uid] = {'type': 'mix_cost'}
        bot.reply_to(message, '💎 Введите <b>цену в гемах</b>:', parse_mode='HTML', reply_markup=cancel_markup())

    elif stype == 'mix_cost':
        try:
            cost = int(text)
        except ValueError:
            bot.reply_to(message, 'Введите число.')
            return
        pending_offers.setdefault(uid, {})['mix_cost'] = cost
        user_states[uid] = {'type': 'mix_date'}
        bot.reply_to(message, '📅 До какой даты действует акция? (ДД.ММ.ГГГГ):', reply_markup=cancel_markup())

    elif stype == 'mix_date':
        try:
            datetime.strptime(text, '%d.%m.%Y')
        except ValueError:
            bot.reply_to(message, 'Формат: <b>ДД.ММ.ГГГГ</b>', parse_mode='HTML')
            return
        user_states.pop(uid, None)
        pending_offers.setdefault(uid, {})['mix_until'] = text
        _finalize_mix(uid, message)

    elif stype == 'promo_prefix_pick':
        user_states.pop(uid, None)
        bot.reply_to(message, 'Выберите префикс кнопкой.')

    elif stype == 'prefix_new_text':
        txt = text.strip().upper().replace(' ', '')
        if not txt or not txt.isascii() or len(txt) > 9:
            bot.reply_to(message, 'Только латиница, до 9 символов.')
            return
        user_states[uid] = {'type': 'prefix_new_grad', 'text': txt}
        bot.reply_to(message, '🎨 Выберите <b>шаблон градиента</b>:', parse_mode='HTML',
                     reply_markup=gradient_select_markup(0))

    elif stype == 'prefix_new_grad':
        bot.reply_to(message, 'Выберите градиент кнопкой.')

    elif stype == 'prefix_give_lowid':
        if not parts:
            bot.reply_to(message, 'Введите low_id.')
            return
        low_id = parts[0]
        player = get_player(low_id)
        if not player:
            bot.reply_to(message, '🔍 Игрок не найден.', reply_markup=main_menu_markup())
            user_states.pop(uid, None)
            return
        user_states[uid] = {'type': 'prefix_give_pick', 'low_id': low_id}
        bot.reply_to(message, '🎨 Выберите префикс:',
                     reply_markup=prefix_select_markup(0, 'prefix_apply_'))

    elif stype == 'prefix_give_pick':
        bot.reply_to(message, 'Выберите префикс кнопкой.')

    elif stype == 'prefix_take_lowid':
        if not parts:
            bot.reply_to(message, 'Введите low_id.')
            return
        low_id = parts[0]
        user_states.pop(uid, None)
        if update_player(low_id, 'title', ''):
            bot.reply_to(message, '✅ Префикс снят с игрока ' + str(low_id),
                         parse_mode='HTML', reply_markup=main_menu_markup())
        else:
            bot.reply_to(message, '❌ Игрок не найден.', reply_markup=main_menu_markup())

    elif stype == 'promo_item_amount':
        if not parts:
            bot.reply_to(message, 'Введите число.')
            return
        try:
            amount = int(parts[0])
            if amount <= 0:
                raise ValueError
        except ValueError:
            bot.reply_to(message, 'Введите положительное число.')
            return
        item_type = state.get('item_type')
        cart = pending_offers.setdefault(uid, {}).setdefault('promo_items', [])
        cart.append({'type': item_type, 'amount': amount})
        user_states.pop(uid, None)
        meta = PROMO_ITEMS.get(item_type, {})
        bot.reply_to(message, 'Добавлено: ' + meta.get('name', item_type) + ' × <b>' + str(amount) + '</b>', parse_mode='HTML')
        _show_promo_items(message.chat.id, None, uid, edit=False)

    elif stype == 'promo_brawler_pick':
        user_states.pop(uid, None)
        bot.reply_to(message, 'Выберите бойца кнопкой, а не текстом.')

    elif stype == 'promo_skin_pick':
        user_states.pop(uid, None)
        bot.reply_to(message, 'Выберите скин кнопкой, а не текстом.')

    elif stype == 'promo_name':
        code = text.strip().upper().replace(' ', '')
        if not code:
            bot.reply_to(message, 'Введите название.')
            return
        if not code.isascii():
            bot.reply_to(message, 'Только латиница, цифры и _ ')
            return
        pending_offers.setdefault(uid, {})['promo_name'] = code
        user_states[uid] = {'type': 'promo_maxuses'}
        bot.reply_to(message, '🔢 Введите <b>максимум активаций</b> (0 = безлимит):',
                     parse_mode='HTML', reply_markup=cancel_markup())

    elif stype == 'promo_maxuses':
        try:
            mx = int(text)
            if mx < 0:
                raise ValueError
        except ValueError:
            bot.reply_to(message, 'Введите число >= 0.')
            return
        if mx == 0:
            mx = 999999
        user_states.pop(uid, None)
        pending_offers.setdefault(uid, {})['promo_maxuses'] = mx
        _finalize_promo(uid, message)

    elif stype == 'offer_title':
        pending_offers.setdefault(uid, {})['title'] = text
        user_states[uid] = {'type': 'offer_cost'}
        bot.reply_to(message, '💎 Введите <b>цену в гемах</b>:', parse_mode='HTML', reply_markup=cancel_markup())

    elif stype == 'offer_cost':
        try:
            cost = int(text)
        except ValueError:
            bot.reply_to(message, '❌ Введите число.')
            return
        pending_offers.setdefault(uid, {})['cost'] = cost
        otype = pending_offers[uid].get('otype', 'gems')
        if otype == 'gems':
            user_states[uid] = {'type': 'offer_amount_simple', 'label': 'гемов', 'emj': '💎'}
            bot.reply_to(message, '💎 Сколько <b>гемов</b> в акции:', parse_mode='HTML', reply_markup=cancel_markup())
        elif otype == 'gold':
            user_states[uid] = {'type': 'offer_amount_simple', 'label': 'монет', 'emj': '🪙'}
            bot.reply_to(message, '🪙 Сколько <b>монет</b> в акции:', parse_mode='HTML', reply_markup=cancel_markup())
        elif otype == 'powerpoints':
            user_states[uid] = {'type': 'offer_amount_simple', 'label': 'очков силы', 'emj': '⭐'}
            bot.reply_to(message, '⭐ Сколько <b>очков силы</b> в акции:', parse_mode='HTML', reply_markup=cancel_markup())
        elif otype == 'tokensdoubler':
            user_states[uid] = {'type': 'offer_amount_simple', 'label': 'удвоителей', 'emj': '✖'}
            bot.reply_to(message, '✖ Сколько <b>удвоителей жетонов</b> в акции:', parse_mode='HTML', reply_markup=cancel_markup())
        elif otype == 'boxes':
            user_states[uid] = {'type': 'offer_amount_boxes'}
            bot.reply_to(message,
                         '📦 Сколько ящиков?\nВведите через пробел: <code>маленьких больших мега</code>\n(пример: <b>5 2 1</b>)',
                         parse_mode='HTML', reply_markup=cancel_markup())
        elif otype in ('brawler', 'skin'):
            user_states[uid] = {'type': 'offer_date'}
            bot.reply_to(message, '📅 До какой даты действует акция? (ДД.ММ.ГГГГ):', reply_markup=cancel_markup())

    elif stype == 'offer_amount_simple':
        try:
            amount = int(text)
        except ValueError:
            bot.reply_to(message, '❌ Введите число.')
            return
        pending_offers.setdefault(uid, {})['amount_simple'] = amount
        user_states[uid] = {'type': 'offer_date'}
        bot.reply_to(message, '📅 До какой даты действует акция? (ДД.ММ.ГГГГ):', reply_markup=cancel_markup())

    elif stype == 'offer_amount_boxes':
        nums = [w for w in text.split() if w.isdigit()]
        if not nums:
            bot.reply_to(message, '❌ Введите числа через пробел.\nПример: <b>5 1 0</b>', parse_mode='HTML')
            return
        small = int(nums[0]) if len(nums) > 0 else 0
        big = int(nums[1]) if len(nums) > 1 else 0
        mega = int(nums[2]) if len(nums) > 2 else 0
        pending_offers.setdefault(uid, {})['multiplier'] = [small, big, mega]
        user_states[uid] = {'type': 'offer_date'}
        bot.reply_to(message, '📅 До какой даты действует акция? (ДД.ММ.ГГГГ):', reply_markup=cancel_markup())

    elif stype == 'offer_date':
        try:
            datetime.strptime(text, '%d.%m.%Y')
        except ValueError:
            bot.reply_to(message, '❌ Формат: <b>ДД.ММ.ГГГГ</b>', parse_mode='HTML')
            return
        user_states.pop(uid, None)
        pending_offers.setdefault(uid, {})['until'] = text
        _finalize_offer(uid, message)


def _finalize_offer(uid, message):
    offer_data = pending_offers.pop(uid, {})
    if not offer_data:
        bot.reply_to(message, '❌ Данные акции потеряны.')
        return

    otype = offer_data.get('otype', 'gems')
    title = offer_data.get('title', 'АКЦИЯ')
    cost = offer_data.get('cost', 0)
    until = offer_data.get('until', '')
    brawler_id = offer_data.get('brawler_id', 0)
    skin_id = offer_data.get('skin_id', 0)
    multiplier = offer_data.get('multiplier', [1, 0, 0])
    amount_simple = offer_data.get('amount_simple', 0)

    if otype == 'gems':
        item_id = [16, 0, 0]
        multiplier = [amount_simple, 0, 0]
        brawler_ids = [0, 0, 0]
        skin_ids = [0, 0, 0]
    elif otype == 'gold':
        item_id = [1, 0, 0]
        multiplier = [amount_simple, 0, 0]
        brawler_ids = [0, 0, 0]
        skin_ids = [0, 0, 0]
    elif otype == 'powerpoints':
        item_id = [12, 0, 0]
        multiplier = [amount_simple, 0, 0]
        brawler_ids = [0, 0, 0]
        skin_ids = [0, 0, 0]
    elif otype == 'tokensdoubler':
        item_id = [9, 0, 0]
        multiplier = [amount_simple, 0, 0]
        brawler_ids = [0, 0, 0]
        skin_ids = [0, 0, 0]
    elif otype == 'boxes':
        small = multiplier[0] if len(multiplier) > 0 else 0
        big = multiplier[1] if len(multiplier) > 1 else 0
        mega = multiplier[2] if len(multiplier) > 2 else 0
        ids = []
        muls = []
        if small > 0:
            ids.append(6); muls.append(small)
        if big > 0:
            ids.append(14); muls.append(big)
        if mega > 0:
            ids.append(10); muls.append(mega)
        while len(ids) < 3:
            ids.append(0); muls.append(0)
        item_id = ids[:3]
        multiplier = muls[:3]
        brawler_ids = [0, 0, 0]
        skin_ids = [0, 0, 0]
    elif otype == 'brawler':
        item_id = [3, 0, 0]
        multiplier = [1, 0, 0]
        brawler_ids = [brawler_id, 0, 0]
        skin_ids = [0, 0, 0]
    elif otype == 'skin':
        item_id = [4, 0, 0]
        multiplier = [1, 0, 0]
        brawler_ids = [0, 0, 0]
        skin_ids = [skin_id, 0, 0]
    else:
        item_id = [1, 0, 0]
        brawler_ids = [0, 0, 0]
        skin_ids = [0, 0, 0]

    new_offer = {
        'ID': item_id,
        'OfferTitle': title,
        'Cost': cost,
        'OldCost': 0,
        'Multiplier': multiplier,
        'BrawlerID': brawler_ids,
        'SkinID': skin_ids,
        'WhoBuyed': [],
        'ShopType': 0,
        'ShopDisplay': False,
        'ShopDonat': 0,
        'WhoBuyedDonat': [],
        'Until': until,
    }

    try:
        with open(OFFERS_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            data = {}
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}

    next_key = str(max((int(k) for k in data.keys()), default=-1) + 1)
    data[next_key] = new_offer

    with open(OFFERS_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    type_names = {'gems': '💎 Гемы', 'gold': '🪙 Монеты', 'powerpoints': '⭐ Очки силы',
                  'tokensdoubler': '✖ Удвоители жетонов', 'boxes': '📦 Ящики',
                  'brawler': '🥊 Боец', 'skin': '🎨 Скин'}
    extra = ''
    if otype == 'brawler':
        extra = f'\n🥊 Боец: <b>{BRAWLERS.get(brawler_id, brawler_id)}</b>'
    elif otype == 'skin':
        extra = f'\n🎨 Скин: <b>{SKINS.get(skin_id, skin_id)}</b>'

    bot.reply_to(
        message,
        f'✅ <b>Акция создана!</b>\n\n'
        f'📌 Название: <b>{title}</b>\n'
        f'💎 Цена: <b>{cost} гем</b>\n'
        f'🏷 Тип: {type_names.get(otype, otype)}{extra}\n'
        f'📅 До: <b>{until}</b>',
        parse_mode='HTML',
        reply_markup=main_menu_markup()
    )


def _finalize_mix(uid, message):
    data_offer = pending_offers.pop(uid, {})
    if not data_offer:
        bot.reply_to(message, 'Данные акции потеряны.')
        return

    items = data_offer.get('mix_items', [])
    title = data_offer.get('mix_title', 'АКЦИЯ')
    cost = data_offer.get('mix_cost', 0)
    until = data_offer.get('mix_until', '')

    id_arr = [0, 0, 0]
    mul_arr = [0, 0, 0]
    for idx, it in enumerate(items[:3]):
        meta = MIX_ITEMS.get(it['type'], {})
        id_arr[idx] = meta.get('id', 0)
        mul_arr[idx] = it['amount']

    new_offer = {
        'ID': id_arr,
        'OfferTitle': title,
        'Cost': cost,
        'OldCost': 0,
        'Multiplier': mul_arr,
        'BrawlerID': [0, 0, 0],
        'SkinID': [0, 0, 0],
        'WhoBuyed': [],
        'ShopType': 0,
        'ShopDisplay': False,
        'ShopDonat': 0,
        'WhoBuyedDonat': [],
        'Until': until,
    }

    try:
        with open(OFFERS_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            data = {}
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}

    next_key = str(max((int(k) for k in data.keys()), default=-1) + 1)
    data[next_key] = new_offer

    with open(OFFERS_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    summary = []
    for it in items:
        meta = MIX_ITEMS.get(it['type'], {})
        summary.append('  • ' + meta.get('name', it['type']) + ' × ' + str(it['amount']))

    bot.reply_to(message,
                 '✅ <b>Акция создана!</b>' + NL + NL +
                 '📌 Название: <b>' + str(title) + '</b>' + NL +
                 '💎 Цена: <b>' + str(cost) + ' гем</b>' + NL +
                 '📅 До: <b>' + str(until) + '</b>' + NL + NL +
                 '📦 <b>Содержимое:</b>' + NL + NL.join(summary),
                 parse_mode='HTML', reply_markup=main_menu_markup())


def _finalize_promo(uid, message):
    data_offer = pending_offers.pop(uid, {})
    if not data_offer:
        bot.reply_to(message, 'Данные промокода потеряны.')
        return

    items = data_offer.get('promo_items', [])
    code = data_offer.get('promo_name', 'PROMO')
    mx = data_offer.get('promo_maxuses', 999999)

    id_arr = []
    mul_arr = []
    brawler_arr = []
    skin_arr = []
    for it in items:
        meta = PROMO_ITEMS.get(it['type'], {})
        id_arr.append(meta.get('id', 0))
        if it['type'] in ('brawler', 'skin', 'prefix'):
            mul_arr.append(1)
        else:
            mul_arr.append(it.get('amount', 1))
        if it['type'] == 'brawler':
            brawler_arr.append(it.get('brawler_id', 0))
        elif it['type'] == 'prefix':
            brawler_arr.append(it.get('title_index', 0))
        else:
            brawler_arr.append(0)
        if it['type'] == 'skin':
            skin_arr.append(it.get('skin_id', 0))
        else:
            skin_arr.append(0)

    new_promo = {
        'Promo': code,
        'ID': id_arr,
        'Multiplier': mul_arr,
        'BrawlerID': brawler_arr,
        'SkinID': skin_arr,
        'WhoBuyed': [],
        'MaxUses': mx,
    }

    try:
        with open(PROMO_JSON_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            data = {}
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}

    for k, v in data.items():
        if v.get('Promo', '').upper() == code:
            bot.reply_to(message, '❌ Промокод с таким названием уже существует.')
            return

    next_key = str(max((int(k) for k in data.keys()), default=-1) + 1)
    data[next_key] = new_promo

    with open(PROMO_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    summary = []
    for it in items:
        meta = PROMO_ITEMS.get(it['type'], {})
        name = meta.get('name', it['type'])
        if it['type'] == 'brawler':
            name += ' ' + BRAWLERS.get(it.get('brawler_id', 0), '')
            summary.append('  • ' + name)
        elif it['type'] == 'skin':
            name += ' ' + SKINS.get(it.get('skin_id', 0), '')
            summary.append('  • ' + name)
        elif it['type'] == 'prefix':
            summary.append('  • ' + name + ' (индекс ' + str(it.get('title_index', 0)) + ')')
        else:
            summary.append('  • ' + name + ' × ' + str(it['amount']))

    mx_str = 'безлимит' if mx == 999999 else str(mx)

    bot.reply_to(message,
                 '✅ <b>Промокод создан!</b>' + NL + NL +
                 '🎁 Код: <code>' + str(code) + '</code>' + NL +
                 '🔢 Активаций: <b>' + mx_str + '</b>' + NL + NL +
                 '📦 <b>Содержимое:</b>' + NL + NL.join(summary) + NL + NL +
                 'Игроки активируют: <code>/promo ' + str(code) + '</code>',
                 parse_mode='HTML', reply_markup=main_menu_markup())


def _do_player_info(message, low_id):
    if not low_id:
        bot.reply_to(message, '❌ Укажите low_id.', reply_markup=main_menu_markup())
        return
    player = get_player(low_id)
    if not player:
        bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.', reply_markup=main_menu_markup())
        return
    info = player['info']

    if info.get('vip', 0) == 2:
        vip_status = '👑 ЕСТЬ | ♾ НАВСЕГДА'
    elif info.get('vip', 0) == 1 and info.get('viptime', '0') != '0':
        try:
            vd = datetime.strptime(info['viptime'], '%d.%m.%Y')
            days_left = (vd - datetime.now()).days + 1
            vip_status = f'👑 ЕСТЬ | ⏳ {days_left} дн.'
        except ValueError:
            vip_status = '👑 ЕСТЬ'
    else:
        vip_status = '❌ НЕТУ'

    if info.get('ban', 0) == 2:
        ban_status = '🚫 ЕСТЬ | ♾ НАВСЕГДА'
    elif info.get('ban', 0) == 1 and info.get('bantime', '0') != '0':
        try:
            bd = datetime.strptime(info['bantime'], '%d.%m.%Y')
            days_left = (bd - datetime.now()).days + 1
            ban_status = f'🚫 ЕСТЬ | ⏳ {days_left} дн.'
        except ValueError:
            ban_status = '🚫 ЕСТЬ'
    else:
        ban_status = '✅ НЕТУ'

    text = (
        f'<b>📋 Аккаунт игрока:</b>\n'
        f'👤 Имя: <b>{info.get("name", "?")}</b>\n'
        f'🆔 ID: <b>{info.get("lowID", "?")}</b>\n'
        f'🔑 Token: <code>{player["token"]}</code>\n'
        f'👑 VIP: {vip_status}\n'
        f'🚫 BAN: {ban_status}\n\n'
        f'<b>💰 Ресурсы:</b>\n'
        f'🏆 Трофеи: <b>{info.get("trophies", 0)}</b>\n'
        f'💎 Гемы: <b>{info.get("gems", 0)}</b>\n'
        f'🪙 Монеты: <b>{info.get("gold", 0)}</b>\n'
        f'🎟 Билеты: <b>{info.get("tickets", 0)}</b>\n'
        f'✖ Удвоители: <b>{info.get("tokensdoubler", 0)}</b>\n'
        f'🎁 Мал. ящики: <b>{info.get("brawlBoxes", 0)}</b>\n'
        f'🏆 Бол. ящики: <b>{info.get("bigBoxes", 0)}</b>'
    )
    bot.reply_to(message, text, parse_mode='HTML', reply_markup=main_menu_markup())


@bot.message_handler(commands=['player_info'])
def cmd_player_info(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    args = message.text.split()
    if len(args) == 2:
        _do_player_info(message, args[1])
    else:
        user_states[message.from_user.id] = {'type': 'player_info'}
        bot.reply_to(message, 'Введите <b>low_id</b> игрока:', parse_mode='HTML')


@bot.message_handler(commands=['add_gems', 'take_gems', 'set_gems'])
def cmd_gems(message):
    _cmd_resource(message, 'gems')


@bot.message_handler(commands=['add_gold', 'take_gold', 'set_gold'])
def cmd_gold(message):
    _cmd_resource(message, 'gold')


@bot.message_handler(commands=['add_tickets', 'take_tickets', 'set_tickets'])
def cmd_tickets(message):
    _cmd_resource(message, 'tickets')


@bot.message_handler(commands=['add_tokensdoubler', 'take_tokensdoubler', 'set_tokensdoubler'])
def cmd_tokensdoubler(message):
    _cmd_resource(message, 'tokensdoubler')


@bot.message_handler(commands=['add_winstreak', 'take_winstreak', 'set_winstreak'])
def cmd_winstreak(message):
    _cmd_resource(message, 'winstreak')


@bot.message_handler(commands=['add_brawlBoxes', 'take_brawlBoxes', 'set_brawlBoxes'])
def cmd_brawlBoxes(message):
    _cmd_resource(message, 'brawlBoxes')


@bot.message_handler(commands=['add_bigBoxes', 'take_bigBoxes', 'set_bigBoxes'])
def cmd_bigBoxes(message):
    _cmd_resource(message, 'bigBoxes')


def _cmd_resource(message, resource):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    args = message.text.split()
    cmd = args[0].lstrip('/')
    action = 'add' if 'add' in cmd else ('take' if 'take' in cmd else 'set')
    if len(args) != 3:
        bot.reply_to(message, f'ℹ Использование: /{cmd} <low_id> <сумма>')
        return
    low_id, amount_str = args[1], args[2]
    try:
        amount = int(amount_str)
    except ValueError:
        bot.reply_to(message, '❌ Сумма должна быть числом.')
        return
    player = get_player(low_id)
    if not player:
        bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.')
        return
    info = player['info']
    box_mult = 100 if resource == 'brawlBoxes' else (10 if resource == 'bigBoxes' else 1)
    cur = info.get(resource, 0)
    if action == 'add':
        new_val = cur + amount * box_mult
    elif action == 'take':
        new_val = max(0, cur - amount * box_mult)
    else:
        new_val = max(0, amount * box_mult)
    if update_player(low_id, resource, new_val):
        bot.reply_to(message, f'✅ Готово! Новое значение {resource}: <b>{new_val}</b>', parse_mode='HTML')
    else:
        bot.reply_to(message, '🔴 Ошибка при обновлении данных.')


@bot.message_handler(commands=['add_vip'])
def cmd_add_vip(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    args = message.text.split()
    if len(args) == 2:
        low_id = args[1]
        player = get_player(low_id)
        if not player:
            bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.')
            return
        update_player(low_id, 'vip', 2)
        update_player(low_id, 'viptime', '0')
        bot.reply_to(message, f'👑 VIP навсегда выдан игроку <b>{player["info"]["name"]}</b>', parse_mode='HTML')
    elif len(args) == 3:
        low_id, days_str = args[1], args[2]
        try:
            days = int(days_str)
        except ValueError:
            bot.reply_to(message, '❌ Дней должно быть числом.')
            return
        player = get_player(low_id)
        if not player:
            bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.')
            return
        expire = (datetime.now() + timedelta(days=days)).strftime('%d.%m.%Y')
        update_player(low_id, 'vip', 1)
        update_player(low_id, 'viptime', expire)
        bot.reply_to(message, f'👑 VIP до {expire} выдан игроку <b>{player["info"]["name"]}</b>', parse_mode='HTML')
    else:
        bot.reply_to(message, 'ℹ /add_vip <low_id> [дни]')


@bot.message_handler(commands=['take_vip'])
def cmd_take_vip(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    args = message.text.split()
    if len(args) != 2:
        bot.reply_to(message, 'ℹ /take_vip <low_id>')
        return
    low_id = args[1]
    player = get_player(low_id)
    if not player:
        bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.')
        return
    update_player(low_id, 'vip', 0)
    update_player(low_id, 'viptime', '0')
    bot.reply_to(message, f'✅ VIP снят с игрока <b>{player["info"]["name"]}</b>', parse_mode='HTML')


@bot.message_handler(commands=['add_ban'])
def cmd_add_ban(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    args = message.text.split()
    if len(args) == 2:
        low_id = args[1]
        player = get_player(low_id)
        if not player:
            bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.')
            return
        update_player(low_id, 'ban', 2)
        update_player(low_id, 'bantime', '0')
        bot.reply_to(message, f'🚫 BAN навсегда выдан игроку <b>{player["info"]["name"]}</b>', parse_mode='HTML')
    elif len(args) == 3:
        low_id, days_str = args[1], args[2]
        try:
            days = int(days_str)
        except ValueError:
            bot.reply_to(message, '❌ Дней должно быть числом.')
            return
        player = get_player(low_id)
        if not player:
            bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.')
            return
        expire = (datetime.now() + timedelta(days=days)).strftime('%d.%m.%Y')
        update_player(low_id, 'ban', 1)
        update_player(low_id, 'bantime', expire)
        bot.reply_to(message, f'🚫 BAN до {expire} выдан игроку <b>{player["info"]["name"]}</b>', parse_mode='HTML')
    else:
        bot.reply_to(message, 'ℹ /add_ban <low_id> [дни]')


@bot.message_handler(commands=['take_ban'])
def cmd_take_ban(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    args = message.text.split()
    if len(args) != 2:
        bot.reply_to(message, 'ℹ /take_ban <low_id>')
        return
    low_id = args[1]
    player = get_player(low_id)
    if not player:
        bot.reply_to(message, f'🔍 Игрок с ID {low_id} не найден.')
        return
    update_player(low_id, 'ban', 0)
    update_player(low_id, 'bantime', '0')
    bot.reply_to(message, f'✅ BAN снят с игрока <b>{player["info"]["name"]}</b>', parse_mode='HTML')


@bot.message_handler(commands=['auto_shop'])
def cmd_auto_shop(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    msg = bot.reply_to(message, '🔄 Обновляю магазин...')
    try:
        process = subprocess.Popen(['python3', 'autoshop.py'],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate(timeout=30)
        if process.returncode == 0:
            lines = [l.strip() for l in stdout.split('\n') if l.strip()]
            response = '✅ <b>Магазин обновлён!</b>\n\n' + '\n'.join(lines[:15])
        else:
            response = f'❌ <b>Ошибка:</b>\n<code>{stderr[:500]}</code>'
    except Exception as e:
        response = f'❌ Ошибка: {e}'
    bot.edit_message_text(response, message.chat.id, msg.message_id, parse_mode='HTML')


@bot.message_handler(commands=['sbros'])
def cmd_sbros(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    msg = bot.reply_to(message, '🔄 Сбрасываю сезон...')
    try:
        process = subprocess.Popen(['python3', 'sbros.py'],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate(timeout=60)
        if process.returncode == 0:
            lines = [l.strip() for l in stdout.split('\n') if l.strip()]
            response = '✅ <b>Сезон сброшен!</b>\n\n' + '\n'.join(lines[:20])
        else:
            response = f'❌ <b>Ошибка:</b>\n<code>{stderr[:500]}</code>'
    except Exception as e:
        response = f'❌ Ошибка: {e}'
    bot.edit_message_text(response, message.chat.id, msg.message_id, parse_mode='HTML')


@bot.message_handler(commands=['statistics'])
def cmd_statistics(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, '🔒 Вы не являетесь администратором!')
        return
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            config = json.load(f)
        online = config.get('Online', 0)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT info FROM players')
        rows = cursor.fetchall()
        conn.close()
        total = len(rows)
        vip_count = ban_count = total_trophies = total_gems = total_gold = 0
        for row in rows:
            info = json.loads(row[0])
            if info.get('vip', 0) > 0:
                vip_count += 1
            if info.get('ban', 0) > 0:
                ban_count += 1
            total_trophies += info.get('trophies', 0)
            total_gems += info.get('gems', 0)
            total_gold += info.get('gold', 0)
        text = (
            f'<b>📊 Статистика Angel Brawl:</b>\n\n'
            f'👥 Аккаунтов: <b>{total}</b>\n'
            f'👑 VIP: <b>{vip_count}</b>\n'
            f'🚫 BAN: <b>{ban_count}</b>\n'
            f'🟢 Онлайн: <b>{online}</b>\n\n'
            f'🏆 Трофеев: <b>{total_trophies}</b>\n'
            f'💎 Гемов: <b>{total_gems}</b>\n'
            f'🪙 Монет: <b>{total_gold}</b>'
        )
    except Exception as e:
        text = f'🔴 Ошибка: {e}'
    bot.reply_to(message, text, parse_mode='HTML')


if __name__ == '__main__':
    print('🤖 Angel Brawl Bot запущен...')
    bot.infinity_polling()