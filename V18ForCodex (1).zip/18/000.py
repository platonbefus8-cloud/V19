import sqlite3
import json
from collections import OrderedDict
import os
import shutil
import datetime

def create_default_data():
    """Создает полный набор данных по умолчанию"""
    data = OrderedDict([
        ("name", "Player"),
        ("lowID", 0),
        ("clubID", 0),
        ("clubRole", 0),
        ("isFBLinked", 0),
        ("facebookID", "None"),
        ("tutorial", 2),
        ("leagueReward", 1),
        ("playerExp", 0),
        ("soloWins", 0),
        ("duoWins", 0),
        ("3vs3Wins", 0),
        ("gems", 0),
        ("gold", 0),
        ("starpoints", 0),
        ("tokensdoubler", 0),
        ("battleTokens", 200),
        ("tickets", 0),
        ("UnlockedSkins", []),
        ("brawlerID", 0),
        ("skinID", 0),
        ("trophies", 0),
        ("highesttrophies", 0),
        ("profileIcon", 0),
        ("namecolor", 0),
        ("brawlBoxes", 0),
        ("bigBoxes", 0),
        ("winstreak", 0),
        ("admin", 0),
        ("vip", 0),
        ("viptime", "0"),
        ("ban", 0),
        ("bantime", "0"),
        ("baninfo", "ОТСУТСТВУЕТ"),
        ("title", "ОТСУТСТВУЕТ"),
        ("questBPvin", 0),
        ("questBPvininfo", 0),
        ("questBP", 0),
        ("questBPtime", 0),
        ("questBPinfo", 0),
        ("sbros", 0),
        ("sbroscost", 0),
        ("sbrosinfo", 0),
        ("last_seen_message_id", 0),
        ("online", 0),
        ("gadget", None),
        ("starpower", None),
        ("DoNotDistrub", 0),
        ("roomID", 0),
        ("wiver", 2)
    ])
    
    # Добавляем словари бравлеров
    for i in range(27):
        data["brawlersSkins"] = OrderedDict([(str(j), 0) for j in range(27)])
        data["brawlersTrophies"] = OrderedDict([(str(j), 0) for j in range(27)])
        data["brawlersTrophiesForRank"] = OrderedDict([(str(j), 0) for j in range(27)])
        data["brawlersUpgradePoints"] = OrderedDict([(str(j), 0) for j in range(27)])
        data["brawlerPowerLevel"] = OrderedDict([(str(j), 0) for j in range(27)])
        data["UnlockedBrawlers"] = OrderedDict([(str(j), 1 if j == 0 else 0) for j in range(27)])
        data["brawlerStarPower"] = OrderedDict([(str(j), 0) for j in range(27)])
    
    return data

def update_player_data(current_data):
    """Обновляет данные игрока, добавляя все поля"""
    # Создаем полный набор данных по умолчанию
    default_data = create_default_data()
    
    # Если current_data пустой или не словарь, возвращаем дефолтные данные
    if not current_data or not isinstance(current_data, dict):
        return default_data
    
    # Создаем новый OrderedDict в правильном порядке
    updated_data = OrderedDict()
    
    # Порядок полей из DatabaseManager.py
    field_order = [
        "name", "lowID", "clubID", "clubRole", "isFBLinked", "facebookID", 
        "tutorial", "leagueReward", "playerExp", "soloWins", "duoWins", 
        "3vs3Wins", "gems", "gold", "starpoints", "tokensdoubler", 
        "battleTokens", "tickets", "UnlockedSkins", "brawlerID", "skinID", 
        "trophies", "highesttrophies", "profileIcon", "namecolor", 
        "brawlBoxes", "bigBoxes", "winstreak", "admin", "vip", "viptime", 
        "ban", "bantime", "baninfo", "title", "questBPvin", "questBPvininfo", 
        "questBP", "questBPtime", "questBPinfo", "sbros", "sbroscost", 
        "sbrosinfo", "last_seen_message_id", "online", "gadget", "starpower", 
        "DoNotDistrub", "roomID", "brawlersSkins", "brawlersTrophies", 
        "brawlersTrophiesForRank", "brawlersUpgradePoints", "brawlerPowerLevel", 
        "UnlockedBrawlers", "brawlerStarPower", "wiver"
    ]
    
    # Добавляем ВСЕ поля в правильном порядке
    for field in field_order:
        if field in current_data:
            # Берем значение из текущих данных
            updated_data[field] = current_data[field]
        else:
            # Берем значение по умолчанию
            updated_data[field] = default_data[field]
    
    # Обновляем trophies до highesttrophies
    if updated_data['highesttrophies'] > 0:
        updated_data['trophies'] = updated_data['highesttrophies']
    
    # Исправляем отрицательные значения
    if updated_data['trophies'] < 0:
        updated_data['trophies'] = 0
    if updated_data['highesttrophies'] < updated_data['trophies']:
        updated_data['highesttrophies'] = updated_data['trophies']
    if updated_data['gems'] < 0:
        updated_data['gems'] = 0
    if updated_data['gold'] < 0:
        updated_data['gold'] = 0
    
    return updated_data

def fix_all_players():
    """Основная функция исправления всех игроков"""
    db_path = 'Database/Player/data.db'
    
    # Проверяем базу данных
    if not os.path.exists(db_path):
        print("База данных не найдена")
        return False
    
    # Создаем резервную копию
    backup_dir = 'Database/Player/backups'
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = os.path.join(backup_dir, f'data_backup_{timestamp}.db')
    shutil.copy2(db_path, backup_path)
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Проверяем таблицу
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='players'")
        if not cursor.fetchone():
            cursor.execute('''CREATE TABLE players (token TEXT PRIMARY KEY, info TEXT)''')
            conn.commit()
            conn.close()
            return True
        
        # Получаем всех игроков
        cursor.execute("SELECT token, info FROM players")
        players = cursor.fetchall()
        
        if not players:
            conn.close()
            return True
        
        total_players = len(players)
        fixed_count = 0
        
        print(f"Найдено игроков: {total_players}")
        print("Начинаю исправление...")
        
        # ОБРАБАТЫВАЕМ КАЖДОГО ИГРОКА
        for token, info_json in players:
            try:
                # Если данные пустые - создаем новые
                if not info_json or info_json.strip() == '' or info_json == 'null':
                    default_data = create_default_data()
                    new_json = json.dumps(default_data, ensure_ascii=False)
                    cursor.execute("UPDATE players SET info=? WHERE token=?", (new_json, token))
                    fixed_count += 1
                    continue
                
                # Пытаемся распарсить JSON
                try:
                    current_data = json.loads(info_json, object_pairs_hook=OrderedDict)
                except:
                    # Если не парсится - создаем новые данные
                    default_data = create_default_data()
                    new_json = json.dumps(default_data, ensure_ascii=False)
                    cursor.execute("UPDATE players SET info=? WHERE token=?", (new_json, token))
                    fixed_count += 1
                    continue
                
                # ОБНОВЛЯЕМ ДАННЫЕ - ВСЕ ПОЛЯ БУДУТ ДОБАВЛЕНЫ
                updated_data = update_player_data(current_data)
                new_json = json.dumps(updated_data, ensure_ascii=False)
                
                # Всегда обновляем данные, даже если кажется что не изменились
                cursor.execute("UPDATE players SET info=? WHERE token=?", (new_json, token))
                fixed_count += 1
                
            except Exception as e:
                # При любой ошибке создаем новый профиль
                default_data = create_default_data()
                new_json = json.dumps(default_data, ensure_ascii=False)
                cursor.execute("UPDATE players SET info=? WHERE token=?", (new_json, token))
                fixed_count += 1
        
        # Удаляем пустые записи
        cursor.execute("DELETE FROM players WHERE info IS NULL OR info = '' OR info = 'null'")
        
        conn.commit()
        conn.close()
        
        print(f"Исправлено игроков: {fixed_count}")
        print(f"Резервная копия: {backup_path}")
        
        # Проверяем результат
        verify_fix()
        
        return True
        
    except Exception as e:
        print(f"Ошибка: {e}")
        return False

def verify_fix():
    """Проверяет что все игроки имеют полный набор полей"""
    db_path = 'Database/Player/data.db'
    
    if not os.path.exists(db_path):
        return
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT token, info FROM players LIMIT 5")
        sample_players = cursor.fetchall()
        
        expected_fields = 56  # Общее количество полей
        
        print("\nПроверка результата:")
        print("-" * 40)
        
        for token, info_json in sample_players:
            try:
                player_data = json.loads(info_json, object_pairs_hook=OrderedDict)
                field_count = len(player_data)
                
                if field_count == expected_fields:
                    print(f"{name}: ✓ Все {field_count} полей на месте")
                else:
                    print(f"{name}: ✗ Только {field_count} из {expected_fields} полей")
                    
                    # Проверяем наличие ключевых полей
                    key_fields = ['name', 'lowID', 'trophies', 'highesttrophies', 'brawlersTrophies', 'UnlockedBrawlers']
                    missing = [f for f in key_fields if f not in player_data]
                    if missing:
                        print(f"  Отсутствуют: {', '.join(missing)}")
            except:
                print(f"{token}: Ошибка при проверке")
        
        conn.close()
        
    except Exception as e:
        print(f"Ошибка при проверке: {e}")

if __name__ == "__main__":
    print("=" * 50)
    print("Исправление базы данных игроков")
    print("=" * 50)
    
    # Создаем папки если их нет
    folders = ['Database/Player', 'Database/Gameroom', 'Database/Club']
    for folder in folders:
        if not os.path.exists(folder):
            os.makedirs(folder)
    
    # Запускаем исправление
    success = fix_all_players()
    
    if success:
        print("\n✅ Исправление завершено успешно!")
        print("\nУ ВСЕХ игроков теперь:")
        print("- Все 56 полей добавлены")
        print("- Trophies обновлены до highesttrophies")
        print("- Отрицательные значения исправлены")
        print("- Пустые записи удалены")
    else:
        print("\n❌ Возникли ошибки при исправлении")